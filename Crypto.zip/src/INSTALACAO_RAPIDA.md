# 🚀 INSTALAÇÃO RÁPIDA - CryptoSell

## ⚡ **INÍCIO RÁPIDO (3 MINUTOS)**

### **Passo 1: Instalar Dependências**
```bash
npm install stripe @stripe/stripe-js @stripe/react-stripe-js
```

### **Passo 2: Rodar o Projeto**
```bash
npm run dev
```

### **Passo 3: Acessar**
```
http://localhost:3000
```

---

## 💳 **TESTAR PAGAMENTO**

### **1. Ir para "Comprar Cripto"**
- Escolha uma criptomoeda (ex: Bitcoin)
- Digite valor: R$ 1000
- Método: PIX ou Cartão

### **2. Preencher Dados**
- Email: `teste@email.com` (opcional)
- Endereço da carteira: `1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa`
- Ou marque "Informar depois"

### **3. Usar Cartão de Teste**
```
Número: 4242 4242 4242 4242
Validade: 12/34
CVV: 123
Nome: TESTE
```

### **4. Confirmar**
✅ Pagamento aprovado em 2-3 segundos!

---

## 🎯 **STATUS ATUAL**

| Funcionalidade | Status |
|----------------|--------|
| Interface Premium | ✅ 100% |
| 500+ Criptomoedas | ✅ 100% |
| Cotação Tempo Real | ✅ 100% |
| Stripe Integrado | ✅ 100% |
| PIX | ✅ Funcional |
| Cartão | ✅ Funcional |
| Campo Carteira | ✅ 100% |
| Chaves LIVE | ⚠️ Ativas |
| Banco de Dados | ❌ Não implementado |
| Envio Cripto Real | ❌ Não implementado |

---

## ⚠️ **IMPORTANTE**

🔴 **MODO PRODUÇÃO ATIVO**
- Chaves Stripe LIVE configuradas
- Pagamentos REAIS serão processados
- Leia `/ATENCAO_SEGURANCA_PRODUCAO.md`

🟡 **FALTA IMPLEMENTAR**
- Banco de dados
- Envio automático de cripto
- KYC/AML
- Dashboard admin

---

## 📁 **ARQUIVOS PRINCIPAIS**

```
/components/BuyCryptoPage.tsx     # Interface principal
/components/StripeCheckout.tsx    # Checkout Stripe
/pages/api/pagamento.js           # Criar pagamento
/pages/api/confirm-payment.js     # Confirmar pagamento
```

---

## 🐛 **PROBLEMAS COMUNS**

### **Erro: Module not found**
```bash
npm install stripe @stripe/stripe-js @stripe/react-stripe-js
```

### **Erro: Cannot find module 'stripe'**
```bash
npm install --force
```

### **API não responde**
- Verifique se o servidor está rodando
- Terminal deve mostrar: `Ready on http://localhost:3000`

---

## ✅ **PRONTO!**

Seu sistema está configurado e funcionando com pagamentos reais via Stripe!

**Próximos passos:**
1. ✅ Testar pagamentos
2. 📊 Implementar banco de dados (Supabase)
3. 🔐 Adicionar KYC/AML
4. ⚖️ Obter licenças legais
