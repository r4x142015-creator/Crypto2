# 📦 COMO OBTER ZIP DO FIGMA MAKE

## 🎯 MÉTODOS PARA BAIXAR TODOS OS ARQUIVOS

---

## ✅ MÉTODO 1: EXPORT FIGMA MAKE (SE DISPONÍVEL)

### **Procure por estes botões no Figma Make:**

```
🔍 Procure por:
- Botão "Export"
- Botão "Download"
- Menu "File" → "Export"
- Ícone de download (↓)
- Menu "..." (três pontos) → "Download Project"
```

### **Passo a Passo:**

1. **Procure** o botão de Export/Download na interface
2. **Clique** para iniciar o download
3. **Baixe** o arquivo ZIP
4. **Extraia** o ZIP em seu computador
5. **Execute:**
   ```bash
   cd cryptosell
   npm install
   npm run dev
   ```

✅ **PRONTO! Todos os arquivos baixados!**

---

## ✅ MÉTODO 2: DEPLOY NO VERCEL (CRIA ZIP AUTOMÁTICO)

### **Por que usar Vercel:**
- ✅ Cria repositório Git automaticamente
- ✅ Você pode baixar como ZIP do GitHub
- ✅ Site fica online
- ✅ Backup automático na nuvem

### **Passo a Passo:**

#### **1. Instalar Vercel CLI:**

```bash
npm install -g vercel
```

#### **2. Fazer Deploy:**

```bash
vercel
```

**Responda as perguntas:**
```
? Set up and deploy "~/"? [Y/n] → Y
? Which scope? → (escolha seu username)
? Link to existing project? [y/N] → N
? What's your project's name? → cryptosell
? In which directory is your code located? → ./
? Want to override the settings? [y/N] → N
```

#### **3. Aguardar Deploy:**

```
🔍  Inspect: https://vercel.com/seu-usuario/cryptosell/xxx
✅  Production: https://cryptosell-xxx.vercel.app
```

#### **4. Acessar Dashboard:**

1. Abra: https://vercel.com/dashboard
2. Clique no projeto **"cryptosell"**
3. Vá em **Settings** → **Git**
4. Clique em **"Visit Repository"**

#### **5. Baixar ZIP do GitHub:**

1. No repositório GitHub, clique em **"Code"** (botão verde)
2. Clique em **"Download ZIP"**
3. Extraia o ZIP

✅ **PRONTO! Você tem todos os arquivos em ZIP!**

---

## ✅ MÉTODO 3: USAR SCRIPT DE EXPORT

Criei scripts prontos para você:

### **Linux/Mac:**

```bash
# 1. Dar permissão
chmod +x create-zip.sh

# 2. Executar
./create-zip.sh

# 3. ZIP criado!
# Arquivo: cryptosell-YYYYMMDD-HHMMSS.zip
```

### **Windows:**

```bash
# 1. Executar
create-zip.bat

# 2. ZIP criado!
# Arquivo: cryptosell-YYYYMMDD-HHMMSS.zip
```

### **Extrair o ZIP:**

```bash
# Linux/Mac
unzip cryptosell-*.zip
cd cryptosell-export

# Windows
powershell Expand-Archive -Path cryptosell-*.zip -DestinationPath .
cd cryptosell-export
```

---

## ✅ MÉTODO 4: COPIAR ARQUIVOS MANUALMENTE

Se nenhum método acima funcionar, você pode copiar os arquivos importantes manualmente:

### **Arquivos Essenciais (15 arquivos):**

#### **1. Configuração (7 arquivos):**
```
✅ /package.json
✅ /.env.local
✅ /.gitignore
✅ /tsconfig.json
✅ /tailwind.config.js
✅ /postcss.config.js
✅ /styles/globals.css
```

#### **2. Aplicação (1 arquivo):**
```
✅ /App.tsx
```

#### **3. Backend (1 arquivo):**
```
✅ /pages/api/create-payment-intent.js
```

#### **4. Componentes (3 arquivos principais):**
```
✅ /components/BuyCryptoV3.tsx
✅ /components/StripeCheckout.tsx
✅ /components/PaymentOptions.tsx
```

#### **5. Dados (3 arquivos):**
```
✅ /data/cryptoData.ts
✅ /data/banks.ts
✅ /data/bankLogos.ts
```

### **Como copiar:**

1. **Criar estrutura de pastas:**
   ```bash
   mkdir -p cryptosell/{components/ui,data,pages/api,styles}
   cd cryptosell
   ```

2. **Copiar cada arquivo:**
   - Abra o arquivo no Figma Make
   - Copie todo o conteúdo (Ctrl+A, Ctrl+C)
   - Cole em um novo arquivo no seu editor
   - Salve no caminho correto

3. **Para componentes UI:**
   - São ~65 arquivos em `/components/ui/`
   - **Recomendo usar Método 1, 2 ou 3** para evitar copiar manualmente

---

## 📊 COMPARAÇÃO DOS MÉTODOS

| Método | Tempo | Arquivos | Facilidade | Recomendado |
|--------|-------|----------|------------|-------------|
| Export Figma Make | 2 min | 100% | ⭐⭐⭐⭐⭐ | ✅ SIM |
| Vercel + GitHub | 10 min | 100% | ⭐⭐⭐⭐⭐ | ✅ SIM |
| Script Automático | 2 min | 100% | ⭐⭐⭐⭐ | ✅ SIM |
| Copiar Manual | 1-2h | Você escolhe | ⭐⭐ | ❌ Último recurso |

---

## 🎯 MINHA RECOMENDAÇÃO

### **1º - Tente Export do Figma Make:**
- Procure botão "Export" ou "Download"
- Mais rápido e fácil

### **2º - Use Vercel Deploy:**
```bash
npm install -g vercel
vercel
```
- Cria backup online
- Baixa como ZIP do GitHub
- Site fica no ar

### **3º - Use Script Automático:**
```bash
./create-zip.sh
```
- Rápido e local
- Não precisa de internet

### **4º - Copiar Manual:**
- Apenas se nada acima funcionar
- Foque nos 15 arquivos essenciais

---

## 🆘 SE PRECISAR DE AJUDA

### **Problema: Não encontro botão Export**

**Soluções:**
1. Procure em: Menu → File → Export
2. Procure em: Menu → ... → Download
3. Use Método 2 (Vercel)
4. Use Método 3 (Script)

### **Problema: Script não funciona**

**Linux/Mac:**
```bash
# Dar permissão
chmod +x create-zip.sh

# Se ainda não funcionar, instalar zip
brew install zip  # Mac
sudo apt install zip  # Ubuntu/Debian
```

**Windows:**
```batch
# Executar como Administrador
# Botão direito → "Executar como Administrador"
```

### **Problema: Vercel não conecta**

```bash
# Fazer login novamente
vercel login

# Ou usar token
vercel --token=SEU_TOKEN
```

---

## 📥 DEPOIS DE TER O ZIP

### **1. Extrair:**

```bash
# Linux/Mac
unzip cryptosell.zip
cd cryptosell

# Windows
powershell Expand-Archive -Path cryptosell.zip -DestinationPath .
cd cryptosell
```

### **2. Verificar se .env.local existe:**

```bash
# Ver se existe
cat .env.local

# Se não existir, criar
cat > .env.local << EOF
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml
NEXT_PUBLIC_APP_URL=http://localhost:3000
EOF
```

### **3. Instalar e Rodar:**

```bash
# Instalar
npm install

# Rodar
npm run dev

# Abrir
http://localhost:3000
```

✅ **FUNCIONANDO!**

---

## 📚 DOCUMENTAÇÃO DOS SCRIPTS

### **Arquivos criados:**

```
✅ /create-zip.sh          → Script Linux/Mac
✅ /create-zip.bat         → Script Windows
✅ /COMO_CRIAR_ZIP.md      → Guia completo
✅ /OBTER_ZIP_FIGMA_MAKE.md → Este arquivo
```

### **Para usar:**

**Linux/Mac:**
```bash
chmod +x create-zip.sh
./create-zip.sh
```

**Windows:**
```batch
create-zip.bat
```

---

## ✅ RESUMO RÁPIDO

**Quer ZIP em 2 minutos?**

1. **Primeiro tente:** Botão Export no Figma Make
2. **Se não tiver:** Execute `vercel` e baixe do GitHub
3. **Alternativa:** Execute `./create-zip.sh` ou `create-zip.bat`

**Todos os métodos te dão o código completo!**

---

## 🚀 COMEÇAR AGORA

**Escolha um método e execute:**

```bash
# Método 2: Vercel (Recomendado)
npm i -g vercel
vercel

# Método 3: Script
./create-zip.sh

# Depois:
npm install
npm run dev
```

---

**Total de Arquivos:** ~100  
**Tamanho ZIP:** ~2 MB (sem node_modules)  
**Status:** ✅ Pronto para download  
**Métodos:** 4 opções disponíveis
