import { useState } from 'react';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { EyeOff, Percent, AlertCircle, Globe, Building2, Banknote, User, Phone, Mail, CreditCard, MapPin, Hash, FileCheck, Copy, CheckCircle2, QrCode } from 'lucide-react';
import { brazilianBanks, internationalBanks } from '../data/banks';
import QRCodeGenerator from './QRCodeGenerator';

interface PaymentOptionsProps {
  receiveMethod: string;
  setReceiveMethod: (method: string) => void;
  receiveData: string;
  setReceiveData: (data: string) => void;
  anonymousMode: boolean;
  setAnonymousMode: (mode: boolean) => void;
  selectedBank: string;
  setSelectedBank: (bank: string) => void;
  selectedRegion: string;
  setSelectedRegion: (region: string) => void;
  transactionId: string;
  setTransactionId: (id: string) => void;
}

export default function PaymentOptions({
  receiveMethod,
  setReceiveMethod,
  receiveData,
  setReceiveData,
  anonymousMode,
  setAnonymousMode,
  selectedBank,
  setSelectedBank,
  selectedRegion,
  setSelectedRegion,
  transactionId,
  setTransactionId
}: PaymentOptionsProps) {
  
  const [pixType, setPixType] = useState('cpf');
  const [copied, setCopied] = useState(false);
  const [formData, setFormData] = useState({
    // Dados Banco Nacional
    fullName: '',
    cpf: '',
    agency: '',
    account: '',
    accountType: 'corrente',
    
    // Dados Banco Internacional
    fullNameIntl: '',
    accountNumber: '',
    swift: '',
    iban: '',
    routingNumber: '',
    bsb: '',
    ifsc: '',
    sortCode: '',
    country: '',
    state: '',
    city: '',
    address: '',
    postalCode: ''
  });

  const regions = Object.keys(internationalBanks);
  const banksInRegion = selectedRegion ? internationalBanks[selectedRegion as keyof typeof internationalBanks] : [];

  // Mapeamento de regiões e países para moedas
  const getCurrencyByRegion = (region: string): { code: string; symbol: string; name: string } => {
    const currencyMap: Record<string, { code: string; symbol: string; name: string }> = {
      'América do Norte': { code: 'USD', symbol: '$', name: 'Dólares Americanos' },
      'América do Sul': { code: 'USD', symbol: '$', name: 'Dólares Americanos' },
      'América Central': { code: 'USD', symbol: '$', name: 'Dólares Americanos' },
      'Europa': { code: 'EUR', symbol: '€', name: 'Euros' },
      'Ásia': { code: 'CNY', symbol: '¥', name: 'Yuan Chinês' },
      'Oceania': { code: 'EUR', symbol: '€', name: 'Euros' },
      'África': { code: 'USD', symbol: '$', name: 'Dólares Americanos' },
      'Oriente Médio': { code: 'AED', symbol: 'د.إ', name: 'Dirham' },
    };
    return currencyMap[region] || { code: 'USD', symbol: '$', name: 'Dólares Americanos' };
  };

  // Mapeamento específico por país/banco
  const getCurrencyByCountryBank = (bank: string, region: string): { code: string; symbol: string; name: string } => {
    // Moedas específicas por país
    const specificCurrencies: Record<string, { code: string; symbol: string; name: string }> = {
      // América do Norte
      'Bank of America': { code: 'USD', symbol: '$', name: 'Dólares Americanos' },
      'Wells Fargo': { code: 'USD', symbol: '$', name: 'Dólares Americanos' },
      'JPMorgan Chase': { code: 'USD', symbol: '$', name: 'Dólares Americanos' },
      'Citibank': { code: 'USD', symbol: '$', name: 'Dólares Americanos' },
      'Royal Bank of Canada': { code: 'CAD', symbol: 'C$', name: 'Dólares Canadenses' },
      'TD Bank': { code: 'CAD', symbol: 'C$', name: 'Dólares Canadenses' },
      'Scotiabank': { code: 'CAD', symbol: 'C$', name: 'Dólares Canadenses' },
      'BMO': { code: 'CAD', symbol: 'C$', name: 'Dólares Canadenses' },
      'CIBC': { code: 'CAD', symbol: 'C$', name: 'Dólares Canadenses' },
      'Banamex': { code: 'MXN', symbol: '$', name: 'Pesos Mexicanos' },
      'BBVA México': { code: 'MXN', symbol: '$', name: 'Pesos Mexicanos' },
      
      // Europa
      'HSBC': { code: 'GBP', symbol: '£', name: 'Libras Esterlinas' },
      'Barclays': { code: 'GBP', symbol: '£', name: 'Libras Esterlinas' },
      'Lloyds': { code: 'GBP', symbol: '£', name: 'Libras Esterlinas' },
      'NatWest': { code: 'GBP', symbol: '£', name: 'Libras Esterlinas' },
      'Santander UK': { code: 'GBP', symbol: '£', name: 'Libras Esterlinas' },
      'Deutsche Bank': { code: 'EUR', symbol: '€', name: 'Euros' },
      'Commerzbank': { code: 'EUR', symbol: '€', name: 'Euros' },
      'BNP Paribas': { code: 'EUR', symbol: '€', name: 'Euros' },
      'Crédit Agricole': { code: 'EUR', symbol: '€', name: 'Euros' },
      'Société Générale': { code: 'EUR', symbol: '€', name: 'Euros' },
      'UniCredit': { code: 'EUR', symbol: '€', name: 'Euros' },
      'Intesa Sanpaolo': { code: 'EUR', symbol: '€', name: 'Euros' },
      'ING Bank': { code: 'EUR', symbol: '€', name: 'Euros' },
      'ABN AMRO': { code: 'EUR', symbol: '€', name: 'Euros' },
      'Credit Suisse': { code: 'CHF', symbol: 'Fr', name: 'Francos Suíços' },
      'UBS': { code: 'CHF', symbol: 'Fr', name: 'Francos Suíços' },
      'Nordea': { code: 'SEK', symbol: 'kr', name: 'Coroas Suecas' },
      'SEB': { code: 'SEK', symbol: 'kr', name: 'Coroas Suecas' },
      'Danske Bank': { code: 'DKK', symbol: 'kr', name: 'Coroas Dinamarquesas' },
      'DNB': { code: 'NOK', symbol: 'kr', name: 'Coroas Norueguesas' },
      
      // Ásia
      'ICBC': { code: 'CNY', symbol: '¥', name: 'Yuan Chinês' },
      'China Construction Bank': { code: 'CNY', symbol: '¥', name: 'Yuan Chinês' },
      'Agricultural Bank of China': { code: 'CNY', symbol: '¥', name: 'Yuan Chinês' },
      'Bank of China': { code: 'CNY', symbol: '¥', name: 'Yuan Chinês' },
      'Mitsubishi UFJ': { code: 'JPY', symbol: '¥', name: 'Ienes Japoneses' },
      'Sumitomo Mitsui': { code: 'JPY', symbol: '¥', name: 'Ienes Japoneses' },
      'Mizuho': { code: 'JPY', symbol: '¥', name: 'Ienes Japoneses' },
      'DBS Bank': { code: 'SGD', symbol: 'S$', name: 'Dólares de Singapura' },
      'OCBC': { code: 'SGD', symbol: 'S$', name: 'Dólares de Singapura' },
      'UOB': { code: 'SGD', symbol: 'S$', name: 'Dólares de Singapura' },
      'HDFC Bank': { code: 'INR', symbol: '₹', name: 'Rúpias Indianas' },
      'State Bank of India': { code: 'INR', symbol: '₹', name: 'Rúpias Indianas' },
      'ICICI Bank': { code: 'INR', symbol: '₹', name: 'Rúpias Indianas' },
      'Axis Bank': { code: 'INR', symbol: '₹', name: 'Rúpias Indianas' },
      'Shinhan Bank': { code: 'KRW', symbol: '₩', name: 'Won Sul-Coreano' },
      'KB Kookmin Bank': { code: 'KRW', symbol: '₩', name: 'Won Sul-Coreano' },
      'Woori Bank': { code: 'KRW', symbol: '₩', name: 'Won Sul-Coreano' },
      'Bangkok Bank': { code: 'THB', symbol: '฿', name: 'Baht Tailandês' },
      'Kasikornbank': { code: 'THB', symbol: '฿', name: 'Baht Tailandês' },
      'Siam Commercial Bank': { code: 'THB', symbol: '฿', name: 'Baht Tailandês' },
      
      // Oceania
      'Commonwealth Bank': { code: 'AUD', symbol: 'A$', name: 'Dólares Australianos' },
      'Westpac': { code: 'AUD', symbol: 'A$', name: 'Dólares Australianos' },
      'ANZ': { code: 'AUD', symbol: 'A$', name: 'Dólares Australianos' },
      'NAB': { code: 'AUD', symbol: 'A$', name: 'Dólares Australianos' },
      'ASB Bank': { code: 'NZD', symbol: 'NZ$', name: 'Dólares Neozelandeses' },
      'BNZ': { code: 'NZD', symbol: 'NZ$', name: 'Dólares Neozelandeses' },
      'ANZ New Zealand': { code: 'NZD', symbol: 'NZ$', name: 'Dólares Neozelandeses' },
      
      // Oriente Médio
      'Emirates NBD': { code: 'AED', symbol: 'د.إ', name: 'Dirham dos Emirados' },
      'First Abu Dhabi Bank': { code: 'AED', symbol: 'د.إ', name: 'Dirham dos Emirados' },
      'Mashreq Bank': { code: 'AED', symbol: 'د.إ', name: 'Dirham dos Emirados' },
      'Qatar National Bank': { code: 'QAR', symbol: 'ر.ق', name: 'Riyal do Qatar' },
      'Al Rajhi Bank': { code: 'SAR', symbol: 'ر.س', name: 'Riyal Saudita' },
      'National Bank of Kuwait': { code: 'KWD', symbol: 'د.ك', name: 'Dinar Kuwaitiano' },
    };

    // Se tem moeda específica para o banco, retorna ela
    if (specificCurrencies[bank]) {
      return specificCurrencies[bank];
    }

    // Caso contrário, retorna a moeda da região
    return getCurrencyByRegion(region);
  };

  const currentCurrency = receiveMethod === 'banco_internacional' && selectedBank
    ? getCurrencyByCountryBank(selectedBank, selectedRegion)
    : receiveMethod === 'banco_internacional' && selectedRegion
    ? getCurrencyByRegion(selectedRegion)
    : { code: 'BRL', symbol: 'R$', name: 'Reais' };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Update receiveData for validation
    const allValues = Object.values({ ...formData, [field]: value }).filter(v => v).join(' | ');
    setReceiveData(allValues);
  };

  const PixIcon = () => (
    <svg className="h-5 w-5" viewBox="0 0 512 512" fill="currentColor">
      <path d="M242.4 292.5C247.8 287.1 257.1 287.1 262.5 292.5L339.5 369.5C353.7 383.7 372.6 391.5 392.6 391.5H407.7L310.6 488.6C280.3 518.1 231.1 518.1 200.8 488.6L103.3 391.1H112.6C132.6 391.1 151.5 383.3 165.7 369.1L242.4 292.5zM262.5 218.9C257.1 224.3 247.8 224.3 242.4 218.9L165.7 142.2C151.5 127.1 132.6 120.2 112.6 120.2H103.3L200.7 22.76C231.1-7.586 280.3-7.586 310.6 22.76L407.7 119.9H392.6C372.6 119.9 353.7 127.7 339.5 141.9L262.5 218.9zM112.6 142.7C126.4 142.7 139.1 148.3 149.8 158.1L226.5 235.5C241.1 250.1 270.9 250.1 285.5 235.5L362.5 158.5C373.3 148.7 385.9 143.1 399.7 143.1H412.6L460.8 192.1C491.1 222.5 491.1 270.7 460.8 301.1L412.6 349.3H399.7C385.9 349.3 373.3 343.7 362.5 332.9L285.5 255.9C270.9 241.3 241.1 241.3 226.5 255.9L149.8 332.6C139.1 343.4 126.4 348.0 112.6 348.0H103.3L55.15 300.8C24.85 270.5 24.85 222.3 55.15 191.0L103.3 142.7H112.6z"/>
    </svg>
  );

  const renderPaymentInput = () => {
    // Banco Nacional (Brasil)
    if (receiveMethod === 'banco_brasil') {
      return (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="space-y-3">
            <Label htmlFor="bank-br" className="text-white flex items-center gap-2">
              <Building2 className="h-4 w-4 text-amber-500" />
              Banco Brasileiro
            </Label>
            <Select value={selectedBank} onValueChange={(bank) => {
              setSelectedBank(bank);
              setFormData({
                fullName: '', cpf: '', agency: '', account: '', accountType: 'corrente',
                fullNameIntl: '', accountNumber: '', swift: '', iban: '', routingNumber: '',
                bsb: '', ifsc: '', sortCode: '', country: '', state: '', city: '', address: '', postalCode: ''
              });
              setReceiveData('');
            }}>
              <SelectTrigger id="bank-br" className="bg-gray-950/50 border-gray-700 text-white h-14 hover:border-amber-500/50 transition-colors">
                <SelectValue placeholder="Escolha o banco" />
              </SelectTrigger>
              <SelectContent className="bg-gray-950 border-gray-700 max-h-[300px]">
                {brazilianBanks.map((bank) => (
                  <SelectItem key={bank} value={bank} className="text-white hover:bg-gray-800">
                    🏦 {bank}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {selectedBank && (
            <div className="space-y-4 p-5 bg-gradient-to-br from-amber-500/5 to-orange-500/5 border border-amber-500/20 rounded-xl">
              <h4 className="text-white font-semibold flex items-center gap-2">
                <User className="h-4 w-4 text-amber-500" />
                Dados do Titular da Conta
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="fullname-br" className="text-white text-sm">
                    Nome Completo
                  </Label>
                  <Input
                    id="fullname-br"
                    value={formData.fullName}
                    onChange={(e) => updateFormData('fullName', e.target.value)}
                    placeholder="Nome completo como no documento"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-amber-500/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cpf-br" className="text-white text-sm">
                    CPF
                  </Label>
                  <Input
                    id="cpf-br"
                    value={formData.cpf}
                    onChange={(e) => updateFormData('cpf', e.target.value)}
                    placeholder="000.000.000-00"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-amber-500/50 font-mono"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="account-type" className="text-white text-sm">
                    Tipo de Conta
                  </Label>
                  <Select value={formData.accountType} onValueChange={(value) => updateFormData('accountType', value)}>
                    <SelectTrigger id="account-type" className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-amber-500/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-950 border-gray-700">
                      <SelectItem value="corrente" className="text-white hover:bg-gray-800">
                        Conta Corrente
                      </SelectItem>
                      <SelectItem value="poupanca" className="text-white hover:bg-gray-800">
                        Conta Poupança
                      </SelectItem>
                      <SelectItem value="pagamento" className="text-white hover:bg-gray-800">
                        Conta Pagamento
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="agency-br" className="text-white text-sm">
                    Agência (sem dígito)
                  </Label>
                  <Input
                    id="agency-br"
                    value={formData.agency}
                    onChange={(e) => updateFormData('agency', e.target.value)}
                    placeholder="0000"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-amber-500/50 font-mono"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="account-br" className="text-white text-sm">
                    Conta (com dígito)
                  </Label>
                  <Input
                    id="account-br"
                    value={formData.account}
                    onChange={(e) => updateFormData('account', e.target.value)}
                    placeholder="00000-0"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-amber-500/50 font-mono"
                  />
                </div>
              </div>

              <p className="text-xs text-amber-300/80 flex items-start gap-2">
                <AlertCircle className="h-3 w-3 mt-0.5 flex-shrink-0" />
                <span>Confira todos os dados antes de enviar. Informações incorretas podem atrasar o recebimento.</span>
              </p>
            </div>
          )}
        </div>
      );
    }

    // Banco Internacional
    if (receiveMethod === 'banco_internacional') {
      return (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <Label htmlFor="region" className="text-white flex items-center gap-2">
                <Globe className="h-4 w-4 text-blue-500" />
                Região
              </Label>
              <Select value={selectedRegion} onValueChange={(value) => {
                setSelectedRegion(value);
                setSelectedBank('');
                setFormData({
                  fullName: '', cpf: '', agency: '', account: '', accountType: 'corrente',
                  fullNameIntl: '', accountNumber: '', swift: '', iban: '', routingNumber: '',
                  bsb: '', ifsc: '', sortCode: '', country: '', state: '', city: '', address: '', postalCode: ''
                });
                setReceiveData('');
              }}>
                <SelectTrigger id="region" className="bg-gray-950/50 border-gray-700 text-white h-14 hover:border-blue-500/50 transition-colors">
                  <SelectValue placeholder="Escolha a região" />
                </SelectTrigger>
                <SelectContent className="bg-gray-950 border-gray-700">
                  {regions.map((region) => (
                    <SelectItem key={region} value={region} className="text-white hover:bg-gray-800 h-12">
                      🌍 {region}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedRegion && (
              <div className="space-y-3">
                <Label htmlFor="bank-intl" className="text-white flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-blue-500" />
                  Banco
                </Label>
                <Select value={selectedBank} onValueChange={setSelectedBank}>
                  <SelectTrigger id="bank-intl" className="bg-gray-950/50 border-gray-700 text-white h-14 hover:border-blue-500/50 transition-colors">
                    <SelectValue placeholder="Escolha o banco" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-950 border-gray-700 max-h-[300px]">
                    {banksInRegion.map((bank: string) => (
                      <SelectItem key={bank} value={bank} className="text-white hover:bg-gray-800">
                        🏛️ {bank}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          {selectedBank && (
            <div className="space-y-4 p-5 bg-gradient-to-br from-blue-500/5 to-cyan-500/5 border border-blue-500/20 rounded-xl">
              <h4 className="text-white font-semibold flex items-center gap-2">
                <User className="h-4 w-4 text-blue-500" />
                International Bank Account Details
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="fullname-intl" className="text-white text-sm">
                    Full Name (as in passport/ID)
                  </Label>
                  <Input
                    id="fullname-intl"
                    value={formData.fullNameIntl}
                    onChange={(e) => updateFormData('fullNameIntl', e.target.value)}
                    placeholder="John Michael Smith"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="account-number-intl" className="text-white text-sm">
                    Account Number
                  </Label>
                  <Input
                    id="account-number-intl"
                    value={formData.accountNumber}
                    onChange={(e) => updateFormData('accountNumber', e.target.value)}
                    placeholder="1234567890"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50 font-mono"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="swift-intl" className="text-white text-sm">
                    SWIFT/BIC Code
                  </Label>
                  <Input
                    id="swift-intl"
                    value={formData.swift}
                    onChange={(e) => updateFormData('swift', e.target.value)}
                    placeholder="ABCDUS33XXX"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50 font-mono"
                  />
                </div>

                {(selectedRegion === 'Europa' || selectedRegion === 'Oriente Médio') && (
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="iban-intl" className="text-white text-sm">
                      IBAN (International Bank Account Number)
                    </Label>
                    <Input
                      id="iban-intl"
                      value={formData.iban}
                      onChange={(e) => updateFormData('iban', e.target.value)}
                      placeholder="GB29NWBK60161331926819"
                      className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50 font-mono"
                    />
                  </div>
                )}

                {selectedRegion === 'América do Norte' && (
                  <div className="space-y-2">
                    <Label htmlFor="routing-intl" className="text-white text-sm">
                      Routing Number (USA) / Transit Number (Canada)
                    </Label>
                    <Input
                      id="routing-intl"
                      value={formData.routingNumber}
                      onChange={(e) => updateFormData('routingNumber', e.target.value)}
                      placeholder="021000021"
                      className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50 font-mono"
                    />
                  </div>
                )}

                {selectedRegion === 'Oceania' && (
                  <div className="space-y-2">
                    <Label htmlFor="bsb-intl" className="text-white text-sm">
                      BSB Code (Australia/New Zealand)
                    </Label>
                    <Input
                      id="bsb-intl"
                      value={formData.bsb}
                      onChange={(e) => updateFormData('bsb', e.target.value)}
                      placeholder="123-456"
                      className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50 font-mono"
                    />
                  </div>
                )}

                {selectedRegion === 'Ásia' && (
                  <div className="space-y-2">
                    <Label htmlFor="ifsc-intl" className="text-white text-sm">
                      IFSC Code (India) / Branch Code
                    </Label>
                    <Input
                      id="ifsc-intl"
                      value={formData.ifsc}
                      onChange={(e) => updateFormData('ifsc', e.target.value)}
                      placeholder="HDFC0001234"
                      className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50 font-mono"
                    />
                  </div>
                )}

                {selectedRegion === 'Europa' && (
                  <div className="space-y-2">
                    <Label htmlFor="sortcode-intl" className="text-white text-sm">
                      Sort Code (UK)
                    </Label>
                    <Input
                      id="sortcode-intl"
                      value={formData.sortCode}
                      onChange={(e) => updateFormData('sortCode', e.target.value)}
                      placeholder="12-34-56"
                      className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50 font-mono"
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="country-intl" className="text-white text-sm">
                    Country
                  </Label>
                  <Input
                    id="country-intl"
                    value={formData.country}
                    onChange={(e) => updateFormData('country', e.target.value)}
                    placeholder="United States"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="city-intl" className="text-white text-sm">
                    City
                  </Label>
                  <Input
                    id="city-intl"
                    value={formData.city}
                    onChange={(e) => updateFormData('city', e.target.value)}
                    placeholder="New York"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50"
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="address-intl" className="text-white text-sm">
                    Address
                  </Label>
                  <Input
                    id="address-intl"
                    value={formData.address}
                    onChange={(e) => updateFormData('address', e.target.value)}
                    placeholder="123 Main Street, Apt 4B"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="postal-intl" className="text-white text-sm">
                    Postal/ZIP Code
                  </Label>
                  <Input
                    id="postal-intl"
                    value={formData.postalCode}
                    onChange={(e) => updateFormData('postalCode', e.target.value)}
                    placeholder="10001"
                    className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50 font-mono"
                  />
                </div>
              </div>

              <p className="text-xs text-blue-300/80 flex items-start gap-2">
                <AlertCircle className="h-3 w-3 mt-0.5 flex-shrink-0" />
                <span>Ensure all details match your bank records exactly. International transfers require accurate information.</span>
              </p>
            </div>
          )}
        </div>
      );
    }

    return null;
  };

  const isFormValid = () => {
    if (receiveMethod === 'banco_brasil') {
      return formData.fullName && formData.cpf && formData.agency && formData.account;
    }
    if (receiveMethod === 'banco_internacional') {
      return formData.fullNameIntl && formData.accountNumber && formData.swift && formData.country;
    }
    return false;
  };

  return (
    <div className="space-y-5">
      {/* Anonymous Mode Toggle */}
      <div className="p-4 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 border border-purple-500/30 rounded-xl">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1">
            <div className="h-10 w-10 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
              <EyeOff className="h-5 w-5 text-purple-400" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-white font-semibold">Modo Anônimo</p>
                <Badge variant="outline" className="border-purple-500/50 bg-purple-500/10 text-purple-300 text-xs">
                  <Percent className="h-3 w-3 mr-1" />
                  +5% Taxa
                </Badge>
              </div>
              <p className="text-xs text-purple-200/70 mt-1">
                Dados removidos após transação
              </p>
            </div>
          </div>
          <Switch
            checked={anonymousMode}
            onCheckedChange={setAnonymousMode}
            className="data-[state=checked]:bg-purple-500"
          />
        </div>
      </div>

      {anonymousMode && (
        <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl animate-in fade-in slide-in-from-top-2 duration-300">
          <AlertCircle className="h-5 w-5 text-purple-400 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-purple-300">
            <p className="font-semibold mb-1">🔒 Transação Anônima Ativada</p>
            <p className="text-xs text-purple-200/80">
              Nenhum dado será armazenado. Informações excluídas após confirmação. Taxa adicional de 5% para processamento seguro.
            </p>
          </div>
        </div>
      )}

      {/* Payment Method Selection */}
      <div className="space-y-3">
        <Label htmlFor="method" className="text-white flex items-center gap-2">
          <Banknote className="h-4 w-4 text-amber-500" />
          Método de Recebimento
        </Label>
        <Select value={receiveMethod} onValueChange={(value) => {
          setReceiveMethod(value);
          setReceiveData('');
          setSelectedBank('');
          setSelectedRegion('');
          setFormData({
            fullName: '', cpf: '', agency: '', account: '', accountType: 'corrente',
            fullNameIntl: '', accountNumber: '', swift: '', iban: '', routingNumber: '',
            bsb: '', ifsc: '', sortCode: '', country: '', state: '', city: '', address: '', postalCode: ''
          });
        }}>
          <SelectTrigger id="method" className="bg-gray-950/50 border-gray-700 text-white h-14 hover:border-amber-500/50 transition-colors">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-gray-950 border-gray-700">
            <SelectItem value="banco_brasil" className="text-white hover:bg-gray-800 h-12">
              <div className="flex items-center gap-2">
                🏦 <span>Banco Brasileiro (30 opções)</span>
              </div>
            </SelectItem>
            <SelectItem value="banco_internacional" className="text-white hover:bg-gray-800 h-12">
              <div className="flex items-center gap-2">
                🌍 <span>Banco Internacional (100+ opções)</span>
              </div>
            </SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Render Payment Input based on method */}
      {renderPaymentInput()}

      {/* TRANSACTION ID - OBRIGATÓRIO */}
      {receiveMethod && (
        <div className="p-5 bg-gradient-to-r from-red-500/10 via-orange-500/10 to-amber-500/10 border-2 border-red-500/40 rounded-xl animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
                <FileCheck className="h-5 w-5 text-red-400" />
              </div>
              <div className="flex-1">
                <h4 className="text-white font-bold flex items-center gap-2">
                  ID da Transação - OBRIGATÓRIO
                  <Badge variant="destructive" className="text-xs">REQUERIDO</Badge>
                </h4>
                <p className="text-xs text-red-200/80 mt-1">
                  Hash da transação de depósito na carteira de criptomoeda
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <Label htmlFor="transaction-id" className="text-white flex items-center gap-2">
                <Hash className="h-4 w-4 text-amber-500" />
                Transaction Hash / ID
              </Label>
              <Input
                id="transaction-id"
                value={transactionId}
                onChange={(e) => setTransactionId(e.target.value)}
                placeholder="0xdf92829d5698d44f678c98482c3d629bc0c251ee70f5c1e689c9a3b2f9ff2f24"
                className="bg-gray-950/50 border-red-500/50 text-white h-14 hover:border-red-500 transition-colors font-mono text-sm"
              />
              <div className="flex items-start gap-2 text-xs text-amber-200/90">
                <AlertCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-semibold">⚠️ IMPORTANTE:</p>
                  <ul className="list-disc list-inside space-y-1 text-amber-200/70">
                    <li>Cole o hash completo da transação (TX Hash)</li>
                    <li>Deve começar com "0x" seguido de 64 caracteres</li>
                    <li>Encontre no seu explorador de blockchain (Etherscan, BSCScan, etc)</li>
                    <li>Comprova o depósito realizado na carteira do CryptoSell</li>
                  </ul>
                </div>
              </div>
            </div>

            {transactionId && transactionId.length >= 66 && transactionId.startsWith('0x') && (
              <div className="flex items-center gap-2 p-3 bg-green-500/20 border border-green-500/40 rounded-lg">
                <CheckCircle2 className="h-5 w-5 text-green-400 flex-shrink-0" />
                <p className="text-sm text-green-300 font-semibold">✓ Transaction ID válido</p>
              </div>
            )}

            {transactionId && (!transactionId.startsWith('0x') || transactionId.length < 66) && (
              <div className="flex items-center gap-2 p-3 bg-red-500/20 border border-red-500/40 rounded-lg">
                <AlertCircle className="h-5 w-5 text-red-400 flex-shrink-0" />
                <p className="text-sm text-red-300">
                  ⚠️ Formato inválido. Deve começar com "0x" e ter 66 caracteres no total.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Summary Info */}
      {isFormValid() && (
        <div className="p-4 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-xl animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
              <AlertCircle className="h-4 w-4 text-green-400" />
            </div>
            <div className="text-sm text-green-300">
              <p className="font-semibold mb-1">✓ Formulário Completo</p>
              <div className="text-xs text-green-200/80 space-y-1">
                <p>Método: <span className="font-semibold">
                  {receiveMethod === 'pix' && 'PIX'}
                  {receiveMethod === 'banco_brasil' && `${selectedBank}`}
                  {receiveMethod === 'banco_internacional' && `${selectedBank} (${selectedRegion})`}
                </span></p>
                {anonymousMode && (
                  <p className="text-purple-300">🔒 Modo anônimo ativo (+5% taxa)</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Info Card */}
      <div className="p-4 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-xl">
        <div className="flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-blue-400 flex-shrink-0 mt-0.5" />
          <div className="text-xs text-blue-300">
            <p className="font-semibold mb-1">Informações Importantes:</p>
            <ul className="list-disc list-inside space-y-1 text-blue-200/80">
              <li>Verifique todos os dados antes de finalizar</li>
              <li>Transações processadas em até 24h úteis</li>
              <li>Confirmação será enviada por e-mail</li>
              {anonymousMode && <li className="text-purple-300">Dados excluídos automaticamente após transação</li>}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}