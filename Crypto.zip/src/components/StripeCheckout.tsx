import { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Loader2, CheckCircle2, CreditCard, Smartphone, AlertCircle, Shield } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

// ✅ CHAVE PÚBLICA - Segura para uso no cliente
const STRIPE_PUBLIC_KEY = 'pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml';

const stripePromise = loadStripe(STRIPE_PUBLIC_KEY);

interface CheckoutFormProps {
  clientSecret: string;
  amount: number;
  cryptoSymbol: string;
  tokenAmount: string;
  onSuccess: () => void;
  onCancel: () => void;
}

function CheckoutForm({ clientSecret, amount, cryptoSymbol, tokenAmount, onSuccess, onCancel }: CheckoutFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [declineCode, setDeclineCode] = useState<string | null>(null);

  const getDeclineMessage = (code: string) => {
    const messages: Record<string, string> = {
      'insufficient_funds': 'Saldo ou limite insuficiente. Tente outro cartão.',
      'generic_decline': 'Cartão recusado pelo banco. Entre em contato com seu banco ou tente outro cartão.',
      'do_not_honor': 'Transação não autorizada pelo banco. Entre em contato com seu banco.',
      'card_velocity_exceeded': 'Muitas tentativas. Aguarde alguns minutos e tente novamente.',
      'fraudulent': 'Transação bloqueada por segurança. Entre em contato com seu banco.',
      'lost_card': 'Cartão reportado como perdido. Entre em contato com seu banco.',
      'stolen_card': 'Cartão reportado como roubado. Entre em contato com seu banco.',
      'expired_card': 'Cartão vencido. Verifique a data de validade.',
      'incorrect_cvc': 'CVV incorreto. Verifique o código de segurança.',
      'processing_error': 'Erro no processamento. Tente novamente.',
      'card_not_supported': 'Este tipo de cartão não é aceito.',
      'currency_not_supported': 'Moeda não suportada pelo cartão.',
      'authentication_required': 'Autenticação necessária. Seu banco requer verificação 3D Secure.',
    };
    return messages[code] || 'Cartão recusado. Tente outro cartão ou entre em contato com seu banco.';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);
    setDeclineCode(null);

    try {
      console.log("🔄 Confirmando pagamento...");

      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/pagamento-sucesso`,
        },
        redirect: 'if_required',
      });

      if (error) {
        console.error("❌ Erro:", error);
        
        const code = (error as any).decline_code || error.code;
        setDeclineCode(code);
        
        const message = code ? getDeclineMessage(code) : error.message;
        setErrorMessage(message || 'Erro ao processar pagamento');
        
        toast.error('Pagamento Recusado', {
          description: message,
          duration: 7000,
        });
      } else if (paymentIntent && paymentIntent.status === 'succeeded') {
        console.log("✅ Pagamento aprovado:", paymentIntent.id);
        toast.success('🎉 Pagamento Aprovado!', {
          description: `Você receberá ${tokenAmount} ${cryptoSymbol} em breve.`,
          duration: 5000,
        });
        setTimeout(() => {
          onSuccess();
        }, 2000);
      } else if (paymentIntent && paymentIntent.status === 'requires_action') {
        toast.info('Autenticação Necessária', {
          description: 'Complete a verificação 3D Secure do seu banco.',
          duration: 5000,
        });
      } else if (paymentIntent && paymentIntent.status === 'processing') {
        toast.info('Processando...', {
          description: 'Seu pagamento está sendo processado.',
        });
        setTimeout(() => {
          onSuccess();
        }, 3000);
      }
    } catch (err: any) {
      console.error("❌ Erro:", err);
      setErrorMessage(err.message || 'Erro desconhecido');
      toast.error('Erro', {
        description: 'Ocorreu um erro ao processar o pagamento.',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Resumo da Compra */}
      <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-xl p-6">
        <h3 className="text-green-400 font-bold text-lg mb-4">Resumo da Compra</h3>
        <div className="space-y-3">
          <div className="flex justify-between items-center text-white">
            <span className="text-gray-400">Criptomoeda:</span>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">{cryptoSymbol}</Badge>
          </div>
          <div className="flex justify-between items-center text-white">
            <span className="text-gray-400">Quantidade:</span>
            <span className="font-mono font-bold text-green-400">{tokenAmount} {cryptoSymbol}</span>
          </div>
          <div className="flex justify-between items-center text-white border-t border-green-500/20 pt-3">
            <span className="text-gray-400">Valor Total:</span>
            <span className="font-bold text-xl">R$ {amount.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Payment Element do Stripe */}
      <div className="bg-gray-950/50 border border-gray-700 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <CreditCard className="h-5 w-5 text-blue-500" />
          <h3 className="text-white font-bold">Dados do Cartão</h3>
        </div>
        <PaymentElement 
          options={{
            layout: 'tabs',
            defaultValues: {
              billingDetails: {
                address: {
                  country: 'BR',
                }
              }
            }
          }}
        />
      </div>

      {/* Erro Detalhado */}
      {errorMessage && (
        <Alert className="bg-red-500/10 border-red-500/50">
          <AlertCircle className="h-5 w-5 text-red-500" />
          <AlertDescription className="text-red-400">
            <p className="font-bold mb-2">⚠️ {errorMessage}</p>
            {declineCode === 'generic_decline' && (
              <div className="text-xs text-red-300 mt-3 space-y-2">
                <p className="font-semibold">Possíveis causas:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Banco bloqueou transações online ou internacionais</li>
                  <li>Limite do cartão insuficiente</li>
                  <li>Cartão não habilitado para compras online</li>
                  <li>Seu banco requer aprovação manual</li>
                </ul>
                <p className="font-semibold mt-3">Soluções:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Entre em contato com seu banco e autorize a transação</li>
                  <li>Habilite compras online no app do banco</li>
                  <li>Aumente o limite do cartão</li>
                  <li>Tente outro cartão de crédito/débito</li>
                  <li>Use um cartão virtual do seu banco</li>
                </ul>
              </div>
            )}
            {declineCode === 'insufficient_funds' && (
              <p className="text-xs text-red-300 mt-2">
                Verifique seu saldo ou limite disponível e tente novamente.
              </p>
            )}
          </AlertDescription>
        </Alert>
      )}

      {/* Informações de Segurança */}
      <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Shield className="h-5 w-5 text-blue-400 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-300">
            <p className="font-semibold mb-1">🔒 Pagamento 100% Seguro</p>
            <p className="text-xs text-blue-200/80">
              Processado por Stripe. Seus dados do cartão são criptografados com SSL 256-bit.
              Suporta autenticação 3D Secure para maior segurança.
            </p>
          </div>
        </div>
      </div>

      {/* Dica sobre cartões brasileiros */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-amber-400 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-amber-300">
            <p className="font-semibold mb-1">💡 Dica: Cartões Brasileiros</p>
            <p className="text-xs text-amber-200/80">
              Alguns bancos brasileiros bloqueiam compras online por padrão.
              Se seu cartão for recusado, entre em contato com seu banco e autorize transações com "STRIPE*CRYPTOSELL".
            </p>
          </div>
        </div>
      </div>

      {/* Botões */}
      <div className="flex gap-3">
        <Button
          type="button"
          onClick={onCancel}
          variant="outline"
          className="flex-1 h-14 border-gray-700 text-gray-400 hover:bg-gray-800"
          disabled={isProcessing}
        >
          Cancelar
        </Button>
        <Button
          type="submit"
          disabled={!stripe || isProcessing}
          className="flex-1 h-14 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg shadow-green-500/30"
        >
          {isProcessing ? (
            <>
              <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              Processando...
            </>
          ) : (
            <>
              <CheckCircle2 className="h-5 w-5 mr-2" />
              Pagar R$ {amount.toFixed(2)}
            </>
          )}
        </Button>
      </div>
    </form>
  );
}

interface StripeCheckoutProps {
  amount: number;
  currency: string;
  paymentMethod: 'pix' | 'credit' | 'paypal';
  cryptoSymbol: string;
  tokenAmount: string;
  customerEmail?: string;
  walletAddress?: string;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function StripeCheckout({
  amount,
  currency,
  paymentMethod,
  cryptoSymbol,
  tokenAmount,
  customerEmail,
  walletAddress,
  onSuccess,
  onCancel,
}: StripeCheckoutProps) {
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const createPaymentIntent = async () => {
      setIsLoading(true);
      setError(null);

      try {
        console.log("🔄 Criando Payment Intent via API backend...");
        
        const response = await fetch('/api/create-payment-intent', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            amount,
            currency,
            cryptoSymbol,
            tokenAmount,
            customerEmail,
            walletAddress,
          }),
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ error: 'Erro ao conectar com servidor' }));
          throw new Error(errorData.error || 'Erro ao criar pagamento');
        }

        const data = await response.json();
        console.log("✅ Payment Intent criado:", data.paymentIntentId);
        console.log("💰 Valor:", `R$ ${amount.toFixed(2)}`);
        
        setClientSecret(data.clientSecret);

      } catch (err: any) {
        console.error('❌ Erro ao criar Payment Intent:', err);
        setError(err.message || 'Erro ao processar pagamento');
        
        toast.error('Erro ao inicializar pagamento', {
          description: err.message,
        });
      } finally {
        setIsLoading(false);
      }
    };

    createPaymentIntent();
  }, [amount, currency, paymentMethod, cryptoSymbol, tokenAmount, customerEmail, walletAddress]);

  const appearance = {
    theme: 'night' as const,
    variables: {
      colorPrimary: '#10b981',
      colorBackground: '#030712',
      colorText: '#ffffff',
      colorDanger: '#ef4444',
      fontFamily: 'system-ui, sans-serif',
      spacingUnit: '4px',
      borderRadius: '8px',
    },
  };

  const options = {
    clientSecret: clientSecret || '',
    appearance,
  };

  if (isLoading) {
    return (
      <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl">
        <CardContent className="py-12">
          <div className="flex flex-col items-center justify-center space-y-4">
            <Loader2 className="h-12 w-12 text-green-500 animate-spin" />
            <p className="text-white font-semibold">Inicializando pagamento seguro...</p>
            <p className="text-gray-400 text-sm">Conectando com Stripe via backend</p>
            <div className="flex items-center gap-2 mt-4">
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse delay-100" />
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse delay-200" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl">
        <CardContent className="py-12 px-8">
          <Alert className="bg-red-500/10 border-red-500/50 mb-6">
            <AlertCircle className="h-5 w-5 text-red-500" />
            <AlertDescription className="text-red-400">
              <p className="font-bold mb-2">Erro ao conectar com servidor</p>
              <p className="text-sm mb-4">{error}</p>
              <div className="bg-gray-900/50 rounded-lg p-4 space-y-2 text-xs">
                <p className="text-gray-300 font-semibold">Para usar pagamentos reais, você precisa rodar o servidor backend:</p>
                <div className="bg-gray-950 rounded p-2 font-mono text-green-400">
                  <p># 1. Instalar dependências</p>
                  <p>npm install</p>
                  <p className="mt-2"># 2. Rodar servidor</p>
                  <p>npm run dev</p>
                  <p className="mt-2"># 3. Acessar</p>
                  <p>http://localhost:3000</p>
                </div>
                <p className="text-gray-400 mt-3">Ou faça deploy no Vercel (grátis):</p>
                <div className="bg-gray-950 rounded p-2 font-mono text-blue-400">
                  <p>npm i -g vercel</p>
                  <p>vercel</p>
                </div>
              </div>
            </AlertDescription>
          </Alert>
          <Button
            onClick={onCancel}
            className="w-full h-12 bg-gray-800 hover:bg-gray-700 text-white"
          >
            Voltar
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!clientSecret) {
    return null;
  }

  return (
    <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl shadow-2xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white text-2xl flex items-center gap-2">
              {paymentMethod === 'pix' ? (
                <Smartphone className="h-6 w-6 text-green-500" />
              ) : (
                <CreditCard className="h-6 w-6 text-blue-500" />
              )}
              Pagamento Seguro - Stripe
            </CardTitle>
            <CardDescription className="text-gray-400 mt-2">
              Complete o pagamento para receber seus {cryptoSymbol}
            </CardDescription>
          </div>
          <div className="flex flex-col items-end gap-2">
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 animate-pulse">
              <div className="h-2 w-2 bg-green-500 rounded-full mr-2" />
              LIVE
            </Badge>
            <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-xs">
              <Shield className="h-3 w-3 mr-1" />
              Protegido
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Elements stripe={stripePromise} options={options}>
          <CheckoutForm
            clientSecret={clientSecret}
            amount={amount}
            cryptoSymbol={cryptoSymbol}
            tokenAmount={tokenAmount}
            onSuccess={onSuccess}
            onCancel={onCancel}
          />
        </Elements>
      </CardContent>
    </Card>
  );
}
