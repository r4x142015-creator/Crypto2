// 500 Maiores Criptomoedas do Mundo com dados completos
export interface CryptoData {
  id: string;
  name: string;
  symbol: string;
  logo: string;
  description: string;
  rank: number;
  category: string;
}

export const top500Cryptos: CryptoData[] = [
  // Top 50
  {
    id: 'bitcoin',
    name: 'Bitcoin',
    symbol: 'BTC',
    logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png',
    description: 'A primeira e mais valiosa criptomoeda descentralizada do mundo, criada por Satoshi Nakamoto em 2009.',
    rank: 1,
    category: 'Currency'
  },
  {
    id: 'ethereum',
    name: 'Ethereum',
    symbol: 'ETH',
    logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.png',
    description: 'Plataforma blockchain com contratos inteligentes que permite criar aplicações descentralizadas (dApps).',
    rank: 2,
    category: 'Smart Contract Platform'
  },
  {
    id: 'tether',
    name: 'Tether',
    symbol: 'USDT',
    logo: 'https://cryptologos.cc/logos/tether-usdt-logo.png',
    description: 'Stablecoin atrelada ao dólar americano (USD) na proporção 1:1, ideal para estabilidade de valor.',
    rank: 3,
    category: 'Stablecoin'
  },
  {
    id: 'binancecoin',
    name: 'BNB',
    symbol: 'BNB',
    logo: 'https://cryptologos.cc/logos/bnb-bnb-logo.png',
    description: 'Token nativo da Binance, usado para taxas reduzidas e acesso a recursos premium na exchange.',
    rank: 4,
    category: 'Exchange Token'
  },
  {
    id: 'solana',
    name: 'Solana',
    symbol: 'SOL',
    logo: 'https://cryptologos.cc/logos/solana-sol-logo.png',
    description: 'Blockchain de alta performance com transações rápidas e baixo custo, ideal para DeFi e NFTs.',
    rank: 5,
    category: 'Smart Contract Platform'
  }
];
