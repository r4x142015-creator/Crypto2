// API Backend - Roda no servidor (SEGURO)
// A chave secreta fica no .env.local e nunca é exposta ao cliente

import Stripe from 'stripe';

// ✅ Chave secreta vem do arquivo .env.local (SEGURO)
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
});

export default async function handler(req, res) {
  // Configurar CORS
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');

  // Responder OPTIONS para CORS preflight
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // Apenas POST é permitido
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  try {
    const { amount, currency, cryptoSymbol, tokenAmount, customerEmail, walletAddress } = req.body;

    // Validações
    if (!amount || amount < 100) {
      return res.status(400).json({ error: 'Valor mínimo de R$ 100,00' });
    }

    if (!cryptoSymbol) {
      return res.status(400).json({ error: 'Criptomoeda não selecionada' });
    }

    console.log('✅ Criando Payment Intent:', {
      amount: `R$ ${amount.toFixed(2)}`,
      currency,
      cryptoSymbol,
      tokenAmount,
    });

    // Cria o Payment Intent no Stripe
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Converte para centavos
      currency: currency?.toLowerCase() || 'brl',
      payment_method_types: ['card'],
      metadata: {
        crypto_symbol: cryptoSymbol,
        token_amount: tokenAmount,
        customer_email: customerEmail || 'sem-email@cryptosell.com',
        wallet_address: walletAddress || 'informar-depois',
        tipo_transacao: 'compra_cripto',
        plataforma: 'CryptoSell',
      },
      description: `Compra de ${tokenAmount} ${cryptoSymbol} - CryptoSell`,
      statement_descriptor: 'CRYPTOSELL',
    });

    console.log('✅ Payment Intent criado com sucesso:', paymentIntent.id);
    console.log('💰 Valor:', `${Math.round(amount * 100)} centavos (R$ ${amount.toFixed(2)})`);

    // Retorna o client secret para o frontend
    return res.status(200).json({
      success: true,
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
    });

  } catch (error) {
    console.error('❌ Erro ao criar Payment Intent:', error);
    return res.status(500).json({
      error: error.message || 'Erro ao processar pagamento',
      details: process.env.NODE_ENV === 'development' ? error.toString() : undefined,
    });
  }
}
