#!/bin/bash

echo "🚀 CryptoSell - Setup Inicial"
echo "================================"
echo ""

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Verificar se Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "❌ Node.js não encontrado. Instale em: https://nodejs.org"
    exit 1
fi

echo "✅ Node.js $(node -v) detectado"
echo ""

# Verificar se .env.local existe
if [ -f .env.local ]; then
    echo "✅ .env.local encontrado"
else
    echo "⚠️  .env.local não encontrado"
    echo "Criando .env.local..."
    cat > .env.local << EOF
# STRIPE - CHAVES SECRETAS (NUNCA COMMITAR NO GIT)
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml

# Outras configurações
NEXT_PUBLIC_APP_URL=http://localhost:3000
EOF
    echo "✅ .env.local criado"
fi

echo ""
echo "📦 Instalando dependências..."
npm install

echo ""
echo "================================"
echo "✅ Setup concluído!"
echo ""
echo -e "${GREEN}Para rodar localmente:${NC}"
echo -e "${BLUE}npm run dev${NC}"
echo ""
echo -e "${GREEN}Para fazer deploy:${NC}"
echo -e "${BLUE}npm i -g vercel${NC}"
echo -e "${BLUE}vercel${NC}"
echo ""
echo "📖 Leia: README.md ou INICIO_RAPIDO.md"
echo ""
