import { useState, useEffect } from 'react';
import { Shield, Lock, CheckCircle2, Copy, ArrowLeft, QrCode, AlertCircle, TrendingUp, Users, Zap, Info, Search, ShoppingCart, Send } from 'lucide-react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Badge } from './components/ui/badge';
import { Progress } from './components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './components/ui/tooltip';
import QRCodeGenerator from './components/QRCodeGenerator';
import SecurityBadges from './components/SecurityBadges';
import StatsBar from './components/StatsBar';
import PaymentOptions from './components/PaymentOptions';
import BuyCryptoPage from './components/BuyCryptoPage';
import PaymentMethodSelector from './components/PaymentMethodSelector';
import PixPayment from './components/PixPayment';
import CardPayment from './components/CardPayment';
import AboutUs from './components/AboutUs';
import ContactSupport from './components/ContactSupport';
import LanguageSelector from './components/LanguageSelector';
import { useLocalization } from './hooks/useLocalization';
import { toast } from 'sonner@2.0.3';
import { Toaster } from './components/ui/sonner';

type CryptoType = 'btc' | 'eth' | 'sol' | 'bnb' | 'xrp' | 'usdt' | 'usdc' | 'avax' | 'baby' | 'bera' | 'bch' | 
  'bb' | 'b2_btc' | 'celo' | 'cfx' | 'doge' | 'ftm' | 'ltc' | 'mito' | 'metis' | 'matic' | 'ron' | 
  'sei' | 'sonic' | 'ip' | 'sui' | 'ton' | 'trx' | 'zeta' | 'xpl';

interface WalletData {
  [key: string]: string;
}

interface Wallets {
  [key: string]: WalletData;
}

const icons: Record<string, string> = {
  btc: "https://cryptologos.cc/logos/bitcoin-btc-logo.png",
  eth: "https://cryptologos.cc/logos/ethereum-eth-logo.png",
  sol: "https://cryptologos.cc/logos/solana-sol-logo.png",
  bnb: "https://cryptologos.cc/logos/bnb-bnb-logo.png",
  xrp: "https://cryptologos.cc/logos/xrp-xrp-logo.png",
  usdt: "https://cryptologos.cc/logos/tether-usdt-logo.png",
  usdc: "https://cryptologos.cc/logos/usd-coin-usdc-logo.png",
  avax: "https://cryptologos.cc/logos/avalanche-avax-logo.png",
  bch: "https://cryptologos.cc/logos/bitcoin-cash-bch-logo.png",
  doge: "https://cryptologos.cc/logos/dogecoin-doge-logo.png",
  ftm: "https://cryptologos.cc/logos/fantom-ftm-logo.png",
  ltc: "https://cryptologos.cc/logos/litecoin-ltc-logo.png",
  matic: "https://cryptologos.cc/logos/polygon-matic-logo.png",
  trx: "https://cryptologos.cc/logos/tron-trx-logo.png",
  ton: "https://cryptologos.cc/logos/toncoin-ton-logo.png",
  sui: "https://cryptologos.cc/logos/sui-sui-logo.png",
  base: "https://cryptologos.cc/logos/base-logo.png",
  arbitrum: "https://cryptologos.cc/logos/arbitrum-arb-logo.png",
  optimism: "https://cryptologos.cc/logos/optimism-ethereum-op-logo.png",
  polygon: "https://cryptologos.cc/logos/polygon-matic-logo.png",
  avalanche: "https://cryptologos.cc/logos/avalanche-avax-logo.png",
};

const cryptoNames: Record<string, string> = {
  btc: "Bitcoin",
  eth: "Ethereum",
  sol: "Solana",
  bnb: "BNB",
  xrp: "XRP",
  usdt: "Tether (USDT)",
  usdc: "USD Coin",
  avax: "Avalanche",
  baby: "Babylon",
  bera: "Berachain",
  bch: "Bitcoin Cash",
  bb: "BounceBit",
  b2_btc: "B2 Network",
  celo: "Celo",
  cfx: "Conflux",
  doge: "Dogecoin",
  ftm: "Fantom",
  ltc: "Litecoin",
  mito: "Mitosis",
  metis: "Metis",
  matic: "Polygon",
  ron: "Ronin",
  sei: "SEI",
  sonic: "Sonic",
  ip: "Story Protocol",
  sui: "SUI",
  ton: "TON",
  trx: "Tron",
  zeta: "ZetaChain",
  xpl: "Plasma",
};

const wallets: Wallets = {
  btc: { 
    Bitcoin: "bc1p4ekdw3q4ut5gh87vtpnlth0wd20eanscd7mnem4dlht3vs95g7nqsg067x",
    "BVM_BTC": "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    "Bitlayer_BTC": "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf"
  },
  eth: { 
    Ethereum: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Base: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Arbitrum: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Optimism: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    BOB: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Blast: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    CYBER: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    HEMI: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    LINEA: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Mantra: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Mode: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Scroll: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Zircuit: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    ZKLink: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    zkSync: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf"
  },
  sol: { Solana: "obEWoDk7pMNG76dvYyc366FrULbnWBCxdSn2zuinHvp" },
  bnb: { BNB: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf", opBNB: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  xrp: { XRP: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  usdt: { 
    BNB: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Ethereum: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Solana: "obEWoDk7pMNG76dvYyc366FrULbnWBCxdSn2zuinHvp",
    Arbitrum: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Avalanche: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    B2: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    CELO: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Conflux: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Mantra: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Mode: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    opBNB: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Polygon: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    TON: "UQC7jZmGd5nwlPxSculyCImg5lecGCrFlWBKDrQlESOaIeDj",
    Tron: "TFNaDeT6ohaDcK8iyvDmP9Kz1kw2onqRbK",
    ZKLink: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    zkSync: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf"
  },
  usdc: { 
    BNB: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Ethereum: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Solana: "obEWoDk7pMNG76dvYyc366FrULbnWBCxdSn2zuinHvp",
    Base: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Arbitrum: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Avalanche: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    B2: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    CELO: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Conflux: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Mantra: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Metis: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Optimism: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Polygon: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Ronin: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    Scroll: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf",
    SUI: "0x43a9b8078fdf4158eff4d95cb3dcf4d964b97a3d041c67fb71a7ed748a2ab59d",
    Tron: "TFNaDeT6ohaDcK8iyvDmP9Kz1kw2onqRbK",
    zkSync: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf"
  },
  avax: { Avalanche: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  baby: { Babylon: "bbn1gvzll3n85y43sc65ae3rz853z8ac35pdf4vpm4" },
  bera: { Berachain: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  bch: { "Bitcoin Cash": "qppstl7xv7sjkxrr2nhxyvg7jyglhzxs956xalampc" },
  bb: { BounceBit: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  b2_btc: { "B2 Network": "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  celo: { CELO: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  cfx: { Conflux: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  doge: { Dogecoin: "DBFUzwKQmPEo5yLuR1rs4VYqrHMTPGCxf6" },
  ftm: { Fantom: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  ltc: { Litecoin: "ltc1qgvzll3n85y43sc65ae3rz853z8ac35pdvdelc3" },
  mito: { Mitosis: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  metis: { Metis: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  matic: { Polygon: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  ron: { Ronin: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  sei: { SEI: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  sonic: { Sonic: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  ip: { "Story Protocol": "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  sui: { SUI: "0x43a9b8078fdf4158eff4d95cb3dcf4d964b97a3d041c67fb71a7ed748a2ab59d" },
  ton: { TON: "UQC7jZmGd5nwlPxSculyCImg5lecGCrFlWBKDrQlESOaIeDj" },
  trx: { Tron: "TFNaDeT6ohaDcK8iyvDmP9Kz1kw2onqRbK" },
  zeta: { ZetaChain: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" },
  xpl: { Plasma: "0x3B43E8391BC8e6FF0A24be7AC0Eb9961291cB1Bf" }
};

export default function App() {
  // Hook de localização
  const { currentLang, currentCurrency: userCurrency, changeLanguage, t, isDetecting } = useLocalization();
  
  const [currentPage, setCurrentPage] = useState<'sell' | 'buy'>('sell');
  const [step, setStep] = useState(1);
  const [selectedCrypto, setSelectedCrypto] = useState<string>('btc');
  const [selectedNetwork, setSelectedNetwork] = useState('');
  const [receiveMethod, setReceiveMethod] = useState('pix');
  const [receiveData, setReceiveData] = useState('');
  const [copied, setCopied] = useState(false);
  const [progressValue, setProgressValue] = useState(33);
  const [searchTerm, setSearchTerm] = useState('');
  const [anonymousMode, setAnonymousMode] = useState(false);
  const [selectedBank, setSelectedBank] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'card' | null>(null);
  const [showPaymentSelector, setShowPaymentSelector] = useState(false);

  const getCurrentCurrency = () => {
    if (receiveMethod === 'banco_internacional') {
      const currencyMap: Record<string, { code: string; symbol: string; name: string }> = {
        'América do Norte': { code: 'USD', symbol: '$', name: 'Dólares Americanos' },
        'Europa': { code: 'EUR', symbol: '€', name: 'Euros' },
        'Ásia': { code: 'CNY', symbol: '¥', name: 'Yuan Chinês' },
        'Oceania': { code: 'AUD', symbol: 'A$', name: 'Dólares Australianos' },
        'Oriente Médio': { code: 'AED', symbol: 'د.إ', name: 'Dirham' },
      };
      const specificBankCurrencies: Record<string, { code: string; symbol: string; name: string }> = {
        'Royal Bank of Canada': { code: 'CAD', symbol: 'C$', name: 'Dólares Canadenses' },
        'TD Bank': { code: 'CAD', symbol: 'C$', name: 'Dólares Canadenses' },
        'Scotiabank': { code: 'CAD', symbol: 'C$', name: 'Dólares Canadenses' },
        'HSBC': { code: 'GBP', symbol: '£', name: 'Libras Esterlinas' },
        'Barclays': { code: 'GBP', symbol: '£', name: 'Libras Esterlinas' },
        'Credit Suisse': { code: 'CHF', symbol: 'Fr', name: 'Francos Suíços' },
        'UBS': { code: 'CHF', symbol: 'Fr', name: 'Francos Suíços' },
        'Mitsubishi UFJ': { code: 'JPY', symbol: '¥', name: 'Ienes Japoneses' },
        'Sumitomo Mitsui': { code: 'JPY', symbol: '¥', name: 'Ienes Japoneses' },
        'DBS Bank': { code: 'SGD', symbol: 'S$', name: 'Dólares de Singapura' },
        'HDFC Bank': { code: 'INR', symbol: '₹', name: 'Rúpias Indianas' },
        'State Bank of India': { code: 'INR', symbol: '₹', name: 'Rúpias Indianas' },
        'Shinhan Bank': { code: 'KRW', symbol: '₩', name: 'Won Sul-Coreano' },
      };
      if (selectedBank && specificBankCurrencies[selectedBank]) return specificBankCurrencies[selectedBank];
      if (selectedRegion && currencyMap[selectedRegion]) return currencyMap[selectedRegion];
      return { code: 'USD', symbol: '$', name: 'Dólares Americanos' };
    }
    return { code: 'BRL', symbol: 'R$', name: 'Reais' };
  };

  const currentCurrency = getCurrentCurrency();

  useEffect(() => {
    if (step === 1) setProgressValue(33);
    else if (step === 2) setProgressValue(66);
    else if (step === 3) setProgressValue(100);
  }, [step]);

  const handleCryptoSelect = (crypto: string) => {
    setSelectedCrypto(crypto);
    setSelectedNetwork('');
  };

  const handleContinueToNetwork = () => {
    const networks = Object.keys(wallets[selectedCrypto] || {});
    if (networks.length === 1) {
      setSelectedNetwork(networks[0]);
      setStep(3);
    } else {
      setStep(2);
    }
  };

  const handleNetworkSelect = (network: string) => {
    setSelectedNetwork(network);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success('Endereço copiado!', {
        description: 'O endereço da carteira foi copiado para a área de transferência.',
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error('Erro ao copiar', {
        description: 'Não foi possível copiar o endereço.',
      });
    }
  };

  const handleFinish = () => {
    if (receiveData.trim()) {
      toast.success('Dados enviados com sucesso!', {
        description: 'Aguarde a confirmação da transação em seu e-mail.',
      });
      setTimeout(() => {
        setStep(1);
        setReceiveData('');
        setSelectedNetwork('');
      }, 1500);
    }
  };

  const walletAddress = selectedNetwork ? (wallets[selectedCrypto]?.[selectedNetwork] || '') : '';

  const stepTitles = [
    { number: 1, title: 'Escolher Cripto', icon: TrendingUp },
    { number: 2, title: 'Escolher Rede', icon: Zap },
    { number: 3, title: 'Finalizar', icon: CheckCircle2 }
  ];

  const filteredCryptos = Object.keys(cryptoNames).filter(crypto => 
    cryptoNames[crypto].toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
        <Toaster richColors position="top-center" />
        
        <header className="border-b border-amber-500/20 bg-gray-950/90 backdrop-blur-xl sticky top-0 z-50 shadow-2xl shadow-amber-500/5">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-amber-500 via-orange-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/50 animate-pulse">
                  <Lock className="h-7 w-7 text-white" />
                </div>
                <div>
                  <h1 className="text-white tracking-tight text-xl">CryptoSell</h1>
                  <p className="text-xs text-amber-400/80">Exchange Premium • 500+ Cryptos</p>
                </div>
              </div>

              <div className="hidden lg:flex items-center gap-2 bg-gray-900/50 p-1 rounded-xl border border-gray-800">
                <Button
                  onClick={() => setCurrentPage('sell')}
                  className={`h-10 px-6 transition-all duration-300 ${
                    currentPage === 'sell'
                      ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-500/30'
                      : 'bg-transparent text-gray-400 hover:text-white hover:bg-gray-800/50'
                  }`}
                >
                  <Send className="h-4 w-4 mr-2" />
                  Vender Cripto
                </Button>
                <Button
                  onClick={() => setCurrentPage('buy')}
                  className={`h-10 px-6 transition-all duration-300 ${
                    currentPage === 'buy'
                      ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg shadow-green-500/30'
                      : 'bg-transparent text-gray-400 hover:text-white hover:bg-gray-800/50'
                  }`}
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Comprar Cripto
                </Button>
              </div>
              
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="border-green-500/50 bg-green-500/10 text-green-400 hidden sm:flex">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  Verificado
                </Badge>
                <Badge variant="outline" className="border-amber-500/50 bg-amber-500/10 text-amber-400 hidden sm:flex">
                  <Shield className="h-3 w-3 mr-1" />
                  Seguro
                </Badge>
                <div className="hidden md:flex items-center gap-1">
                  <LanguageSelector currentLang={currentLang} onLanguageChange={changeLanguage} />
                  <div className="h-4 w-px bg-gray-700 mx-1"></div>
                  <AboutUs />
                  <div className="h-4 w-px bg-gray-700 mx-1"></div>
                  <ContactSupport />
                </div>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                      <Info className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Plataforma 100% segura e verificada</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>
          </div>
        </header>

        <StatsBar />

        <div className="lg:hidden border-b border-gray-800/50 bg-gray-950/50 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4 max-w-4xl">
            <div className="flex items-center gap-2 bg-gray-900/50 p-1 rounded-xl border border-gray-800">
              <Button
                onClick={() => setCurrentPage('sell')}
                className={`flex-1 h-12 transition-all duration-300 ${
                  currentPage === 'sell'
                    ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-500/30'
                    : 'bg-transparent text-gray-400 hover:text-white hover:bg-gray-800/50'
                }`}
              >
                <Send className="h-4 w-4 mr-2" />
                Vender
              </Button>
              <Button
                onClick={() => setCurrentPage('buy')}
                className={`flex-1 h-12 transition-all duration-300 ${
                  currentPage === 'buy'
                    ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg shadow-green-500/30'
                    : 'bg-transparent text-gray-400 hover:text-white hover:bg-gray-800/50'
                }`}
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                Comprar
              </Button>
            </div>
          </div>
        </div>

        {currentPage === 'sell' ? (
          <>
            <div className="border-b border-gray-800/50 bg-gray-950/50 backdrop-blur-sm">
              <div className="container mx-auto px-4 py-6 max-w-4xl">
                <div className="flex items-center justify-between mb-4">
                  {stepTitles.map((item, index) => {
                    const Icon = item.icon;
                    const isActive = step === item.number;
                    const isCompleted = step > item.number;
                    
                    return (
                      <div key={item.number} className="flex items-center flex-1">
                        <div className="flex flex-col items-center gap-2 flex-1">
                          <div className={`h-10 w-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                            isActive 
                              ? 'bg-gradient-to-br from-amber-500 to-orange-600 shadow-lg shadow-amber-500/50 scale-110' 
                              : isCompleted 
                              ? 'bg-green-500/20 border-2 border-green-500' 
                              : 'bg-gray-800 border-2 border-gray-700'
                          }`}>
                            <Icon className={`h-5 w-5 ${
                              isActive ? 'text-white' : isCompleted ? 'text-green-400' : 'text-gray-500'
                            }`} />
                          </div>
                          <span className={`text-xs transition-colors ${
                            isActive ? 'text-amber-400' : isCompleted ? 'text-green-400' : 'text-gray-500'
                          }`}>
                            {item.title}
                          </span>
                        </div>
                        {index < stepTitles.length - 1 && (
                          <div className={`h-0.5 flex-1 mx-2 transition-colors ${
                            step > item.number ? 'bg-green-500' : 'bg-gray-800'
                          }`} />
                        )}
                      </div>
                    );
                  })}</div>
                <Progress value={progressValue} className="h-2" />
              </div>
            </div>

            <div className="container mx-auto px-4 py-8 max-w-4xl">
              {step === 1 && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl shadow-2xl">
                    <CardHeader>
                      <div className="flex items-center justify-center mb-6">
                        <div className="relative">
                          <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full blur-xl opacity-50 animate-pulse" />
                          <img 
                            src={icons[selectedCrypto] || icons.btc} 
                            alt={cryptoNames[selectedCrypto] || 'Crypto'}
                            className="h-20 w-20 rounded-full relative z-10 shadow-2xl"
                          />
                        </div>
                      </div>
                      <CardTitle className="text-center text-white text-2xl">Escolha a Criptomoeda</CardTitle>
                      <CardDescription className="text-center text-gray-400">
                        Mais de 30 criptomoedas disponíveis em 50+ redes blockchain
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="space-y-3">
                        <Label className="text-white flex items-center gap-2">
                          <Search className="h-4 w-4 text-amber-500" />
                          Pesquisar Criptomoeda
                        </Label>
                        <Input
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          placeholder="Digite o nome da criptomoeda..."
                          className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-amber-500/50 transition-colors"
                        />
                      </div>

                      <div className="space-y-3">
                        <Label htmlFor="crypto" className="text-white flex items-center gap-2">
                          <TrendingUp className="h-4 w-4 text-amber-500" />
                          Criptomoeda ({filteredCryptos.length} disponíveis)
                        </Label>
                        <Select value={selectedCrypto} onValueChange={handleCryptoSelect}>
                          <SelectTrigger id="crypto" className="bg-gray-950/50 border-gray-700 text-white h-14 hover:border-amber-500/50 transition-colors">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-950 border-gray-700 max-h-[400px]">
                            {filteredCryptos.map((crypto) => (
                              <SelectItem key={crypto} value={crypto} className="text-white hover:bg-gray-800">
                                <div className="flex items-center gap-3 py-1">
                                  <img src={icons[crypto] || icons.btc} alt={cryptoNames[crypto]} className="h-6 w-6 rounded-full" />
                                  <span>{cryptoNames[crypto]}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <Button 
                        onClick={handleContinueToNetwork}
                        className="w-full h-14 bg-gradient-to-r from-amber-500 via-orange-500 to-orange-600 hover:from-amber-600 hover:via-orange-600 hover:to-orange-700 text-white shadow-lg shadow-amber-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/40 hover:scale-[1.02]"
                      >
                        Continuar para Próxima Etapa
                      </Button>

                      <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-xl">
                        <div className="h-8 w-8 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                          <AlertCircle className="h-4 w-4 text-blue-400" />
                        </div>
                        <div className="text-sm text-blue-300">
                          <p className="font-semibold mb-1">Transação 100% Segura</p>
                          <p className="text-xs text-blue-200/80">Todas as transações são protegidas com criptografia AES-256 de ponta a ponta</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 pt-4">
                        <div className="flex flex-col items-center gap-2 p-3 bg-gray-800/30 rounded-lg border border-gray-700/50">
                          <Zap className="h-5 w-5 text-yellow-500" />
                          <span className="text-xs text-gray-400 text-center">Processamento Rápido</span>
                        </div>
                        <div className="flex flex-col items-center gap-2 p-3 bg-gray-800/30 rounded-lg border border-gray-700/50">
                          <Shield className="h-5 w-5 text-green-500" />
                          <span className="text-xs text-gray-400 text-center">50+ Redes</span>
                        </div>
                        <div className="flex flex-col items-center gap-2 p-3 bg-gray-800/30 rounded-lg border border-gray-700/50">
                          <Users className="h-5 w-5 text-blue-500" />
                          <span className="text-xs text-gray-400 text-center">Suporte 24/7</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {step === 2 && (
                <div className="animate-in fade-in slide-in-from-right-4 duration-500">
                  <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl shadow-2xl">
                    <CardHeader>
                      <Button
                        onClick={() => setStep(1)}
                        variant="ghost"
                        className="w-fit mb-4 text-gray-400 hover:text-white"
                      >
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Voltar
                      </Button>
                      <div className="flex items-center justify-center mb-6">
                        <div className="relative">
                          <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full blur-xl opacity-50 animate-pulse" />
                          <img 
                            src={icons[selectedCrypto]} 
                            alt={cryptoNames[selectedCrypto]}
                            className="h-20 w-20 rounded-full relative z-10 shadow-2xl"
                          />
                        </div>
                      </div>
                      <CardTitle className="text-center text-white text-2xl">{cryptoNames[selectedCrypto]}</CardTitle>
                      <CardDescription className="text-center text-gray-400">
                        Escolha a rede blockchain para receber
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Label htmlFor="network" className="text-white flex items-center gap-2">
                        <Zap className="h-4 w-4 text-amber-500" />
                        Rede Blockchain
                      </Label>
                      <Select value={selectedNetwork} onValueChange={handleNetworkSelect}>
                        <SelectTrigger id="network" className="bg-gray-950/50 border-gray-700 text-white h-14 hover:border-amber-500/50 transition-colors">
                          <SelectValue placeholder="Selecione a rede..." />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-950 border-gray-700 max-h-[400px]">
                          {Object.keys(wallets[selectedCrypto] || {}).map((network) => (
                            <SelectItem key={network} value={network} className="text-white hover:bg-gray-800">
                              <div className="flex items-center gap-2 py-1">
                                <Badge variant="outline" className="border-amber-500/50 bg-amber-500/10 text-amber-400">
                                  {network}
                                </Badge>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Button 
                        onClick={() => setStep(3)}
                        disabled={!selectedNetwork}
                        className="w-full h-14 bg-gradient-to-r from-amber-500 via-orange-500 to-orange-600 hover:from-amber-600 hover:via-orange-600 hover:to-orange-700 text-white shadow-lg shadow-amber-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/40 hover:scale-[1.02] disabled:opacity-50"
                      >
                        Continuar para Finalização
                      </Button>

                      <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl">
                        <div className="h-8 w-8 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                          <Info className="h-4 w-4 text-purple-400" />
                        </div>
                        <div className="text-sm text-purple-300">
                          <p className="font-semibold mb-1">Atenção à Rede!</p>
                          <p className="text-xs text-purple-200/80">Certifique-se de selecionar a rede correta para evitar perda de fundos</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {step === 3 && selectedNetwork && (
                <div className="animate-in fade-in slide-in-from-right-4 duration-500">
                  <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl shadow-2xl">
                    <CardHeader>
                      <Button
                        onClick={() => setStep(2)}
                        variant="ghost"
                        className="w-fit mb-4 text-gray-400 hover:text-white"
                      >
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Voltar
                      </Button>
                      <div className="flex items-center justify-center gap-4 mb-6">
                        <div className="relative">
                          <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full blur-xl opacity-50 animate-pulse" />
                          <img 
                            src={icons[selectedCrypto]} 
                            alt={cryptoNames[selectedCrypto]}
                            className="h-16 w-16 rounded-full relative z-10 shadow-2xl"
                          />
                        </div>
                        <div className="text-left">
                          <CardTitle className="text-white text-2xl">{cryptoNames[selectedCrypto]}</CardTitle>
                          <Badge variant="outline" className="border-amber-500/50 bg-amber-500/10 text-amber-400 mt-2">
                            Rede: {selectedNetwork}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-8">
                      <div className="space-y-4">
                        <Label className="text-white flex items-center gap-2 text-lg">
                          <Lock className="h-5 w-5 text-green-500" />
                          Endereço para Depósito
                        </Label>
                        
                        <div className="bg-gray-950/50 border-2 border-amber-500/30 rounded-xl p-6 space-y-4">
                          <div className="flex items-center justify-between gap-4">
                            <code className="text-amber-400 font-mono text-sm break-all flex-1">
                              {walletAddress}
                            </code>
                            <Button
                              onClick={() => copyToClipboard(walletAddress)}
                              variant="outline"
                              size="sm"
                              className="flex-shrink-0 border-amber-500/50 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
                            >
                              {copied ? <CheckCircle2 className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                            </Button>
                          </div>

                          <div className="flex justify-center pt-4 border-t border-gray-700/50">
                            <QRCodeGenerator value={walletAddress} />
                          </div>
                        </div>

                        <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/30 rounded-xl">
                          <div className="h-8 w-8 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                            <AlertCircle className="h-4 w-4 text-amber-400" />
                          </div>
                          <div className="text-sm text-amber-300">
                            <p className="font-semibold mb-1">⚠️ Valor Mínimo: $100 USD</p>
                            <p className="text-xs text-amber-200/80">Depósitos abaixo de $100 não serão processados e não poderão ser devolvidos</p>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <Label className="text-white text-lg">Como deseja receber?</Label>
                        <PaymentOptions
                          receiveMethod={receiveMethod}
                          setReceiveMethod={setReceiveMethod}
                          receiveData={receiveData}
                          setReceiveData={setReceiveData}
                          anonymousMode={anonymousMode}
                          setAnonymousMode={setAnonymousMode}
                          selectedBank={selectedBank}
                          setSelectedBank={setSelectedBank}
                          selectedRegion={selectedRegion}
                          setSelectedRegion={setSelectedRegion}
                          transactionId={transactionId}
                          setTransactionId={setTransactionId}
                          currentCurrency={currentCurrency}
                        />
                      </div>

                      <Button 
                        onClick={handleFinish}
                        disabled={!receiveData || !transactionId || transactionId.length !== 66}
                        className="w-full h-14 bg-gradient-to-r from-green-500 via-emerald-500 to-green-600 hover:from-green-600 hover:via-emerald-600 hover:to-green-700 text-white shadow-lg shadow-green-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-green-500/40 hover:scale-[1.02] disabled:opacity-50"
                      >
                        <CheckCircle2 className="h-5 w-5 mr-2" />
                        Confirmar e Enviar Dados
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>

            <SecurityBadges />
          </>
        ) : (
          <BuyCryptoPage />
        )}

        {/* Footer with About Us */}
        <footer className="border-t border-gray-800/50 bg-gray-950/90 backdrop-blur-xl mt-12">
          <div className="container mx-auto px-4 py-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-amber-500 via-orange-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/50">
                  <Lock className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="text-white">CryptoSell</p>
                  <p className="text-xs text-gray-400">Exchange Premium Global</p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="flex items-center gap-2">
                  <AboutUs />
                  <div className="h-4 w-px bg-gray-700 mx-1"></div>
                  <ContactSupport />
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="border-green-500/50 bg-green-500/10 text-green-400">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    200+ Países
                  </Badge>
                  <Badge variant="outline" className="border-amber-500/50 bg-amber-500/10 text-amber-400">
                    <Shield className="h-3 w-3 mr-1" />
                    PCI DSS
                  </Badge>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-gray-800/50">
              <p className="text-center text-xs text-gray-500">
                © 2025 CryptoSell. Todos os direitos reservados. • Plataforma global de compra e venda de ativos digitais.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </TooltipProvider>
  );
}