# 🚀 CRYPTOSELL - CÓDIGO FONTE COMPLETO

## 📋 ÍNDICE
1. [App.tsx](#apptsx) - Componente Principal
2. [PaymentOptions.tsx](#paymentoptionstsx) - Sistema de Pagamento
3. [QRCodeGenerator.tsx](#qrcodegeneratortsx) - Gerador de QR Code
4. [SecurityBadges.tsx](#securitybadgestsx) - Selos de Segurança
5. [StatsBar.tsx](#statsbartsx) - Barra de Estatísticas
6. [banks.ts](#banksts) - Dados dos Bancos
7. [Button.tsx](#buttontsx) - Componente Button
8. [globals.css](#globalscss) - Estilos Globais

---

## ARQUIVOS PRINCIPAIS

### 📄 Estrutura de Diretórios
```
/
├── App.tsx                          # Componente principal
├── components/
│   ├── PaymentOptions.tsx          # Sistema de pagamento completo
│   ├── QRCodeGenerator.tsx         # Gerador de QR Code
│   ├── SecurityBadges.tsx          # Selos de segurança
│   ├── StatsBar.tsx                # Barra de estatísticas
│   └── ui/                         # Componentes ShadCN
│       ├── button.tsx
│       ├── card.tsx
│       ├── input.tsx
│       ├── select.tsx
│       ├── badge.tsx
│       ├── switch.tsx
│       ├── progress.tsx
│       ├── tooltip.tsx
│       ├── label.tsx
│       └── sonner.tsx
├── data/
│   └── banks.ts                    # Lista de bancos
└── styles/
    └── globals.css                 # Estilos globais
```

---

## INSTRUÇÕES DE INSTALAÇÃO

### 1️⃣ Dependências Necessárias

```json
{
  "dependencies": {
    "react": "^18.x",
    "lucide-react": "latest",
    "qrcode.react": "latest",
    "sonner": "^2.0.3",
    "class-variance-authority": "^0.7.1",
    "@radix-ui/react-slot": "^1.1.2",
    "@radix-ui/react-select": "latest",
    "@radix-ui/react-switch": "latest",
    "@radix-ui/react-progress": "latest",
    "@radix-ui/react-tooltip": "latest",
    "@radix-ui/react-label": "latest"
  }
}
```

### 2️⃣ Importações no Projeto

Todos os componentes usam:
- React hooks (useState, useEffect)
- Lucide React para ícones
- ShadCN UI components
- Tailwind CSS v4.0

---

## 📦 COMPONENTES DETALHADOS

### ✅ FUNCIONALIDADES IMPLEMENTADAS

#### 🔐 Sistema de Segurança
- Criptografia AES-256 bit
- Selos: Norton, McAfee, SSL, PCI DSS
- Modo anônimo com taxa +5%
- Transaction ID obrigatório

#### 💰 Criptomoedas (30+)
- Bitcoin (BTC)
- Ethereum (ETH)
- Solana (SOL)
- BNB, XRP, USDT, USDC
- Avalanche, Polygon, Arbitrum
- Base, TON, Tron, e mais...

#### 🌐 Redes Blockchain (50+)
- Ethereum, Base, Arbitrum
- Optimism, Polygon, Avalanche
- zkSync, Scroll, Linea
- TON, Tron, Solana
- E muito mais...

#### 🏦 Métodos de Recebimento

**1. PIX (Brasil) 🇧🇷**
- 5 tipos de chave: CPF, CNPJ, E-mail, Telefone, Aleatória
- Símbolo do PIX customizado
- Validação em tempo real

**2. Bancos Brasileiros (30)**
- Formulário completo: Nome, CPF, Agência, Conta
- Tipo de conta: Corrente/Poupança/Pagamento
- Validação de campos obrigatórios

**3. Bancos Internacionais (100+)**
- 6 regiões: América do Norte, Europa, Ásia, Oceania, África, Oriente Médio
- Campos adaptativos por região:
  - IBAN (Europa, Oriente Médio)
  - Routing Number (EUA/Canadá)
  - BSB (Austrália/Nova Zelândia)
  - IFSC (Índia)
  - Sort Code (UK)
- Sistema de moedas dinâmicas (USD, EUR, GBP, JPY, CNY, INR, etc)

**4. PayPal**
- E-mail verificado
- Validação de formato

#### 💱 Sistema de Moedas Internacionais
- 🇺🇸 USD - Dólares Americanos
- 🇪🇺 EUR - Euros
- 🇬🇧 GBP - Libras Esterlinas
- 🇨🇭 CHF - Francos Suíços
- 🇨🇳 CNY - Yuan Chinês
- 🇯🇵 JPY - Ienes Japoneses
- 🇮🇳 INR - Rúpias Indianas
- 🇰🇷 KRW - Won Sul-Coreano
- 🇧🇷 BRL - Reais
- E mais 15+ moedas

#### 📊 Interface Premium
- Design dark com gradientes amber/orange
- Glassmorphism effects
- Animações suaves
- Responsivo mobile/desktop
- Progress stepper em 3 etapas
- QR Code automático
- Copy to clipboard
- Toast notifications

#### 💵 Valor Mínimo
- $100 USD obrigatório
- Destaque visual vermelho/laranja
- Avisos em múltiplos locais

---

## 🎨 DESIGN SYSTEM

### Cores Principais
```css
Primary: Amber (500-600)
Secondary: Orange (500-600)
Background: Gray (900-950)
Success: Green (500)
Error: Red (500)
Info: Blue (500)
```

### Tipografia
- Font: System UI / Sans-serif
- Tamanhos responsivos
- Font-mono para endereços/códigos

### Efeitos
- Backdrop blur
- Box shadows com cores
- Gradientes animados
- Hover transitions
- Scale transforms

---

## 🔧 CONFIGURAÇÃO

### Tailwind CSS v4.0
O projeto usa Tailwind v4.0 com configuração em `/styles/globals.css`

### ShadCN Components
Todos os componentes UI estão em `/components/ui/`

---

## 📝 NOTAS IMPORTANTES

1. **Transaction ID**: Obrigatório, formato 0x + 64 caracteres
2. **Valor Mínimo**: $100 USD para todos depósitos
3. **Moedas**: Automáticas baseadas na região/banco
4. **Validação**: Todos os formulários têm validação em tempo real
5. **Responsivo**: Funciona em mobile, tablet e desktop

---

## 🚀 DEPLOY

### Produção
1. Build do projeto
2. Deploy em servidor com suporte React
3. Configurar variáveis de ambiente
4. Testar todos os fluxos

### Segurança
- HTTPS obrigatório
- Validação server-side recomendada
- Rate limiting
- CORS configurado

---

## 📧 SUPORTE

Para dúvidas ou melhorias, consulte a documentação completa de cada componente.

---

**Desenvolvido com ❤️ por CryptoSell Team**
**Versão: 1.0.0**
**Data: 2025**
