# 📦 COMO CRIAR ZIP DO PROJETO CRYPTOSELL

## 🎯 3 OPÇÕES DISPONÍVEIS

---

## ✅ OPÇÃO 1: DEPLOY NO VERCEL (MAIS FÁCIL)

O Vercel automaticamente cria um repositório Git que você pode baixar como ZIP:

### **Passo a Passo:**

```bash
# 1. Instalar Vercel CLI
npm install -g vercel

# 2. Fazer login
vercel login

# 3. Deploy (cria repositório automaticamente)
vercel

# Responder as perguntas:
# - Set up and deploy? → Y
# - Which scope? → (seu usuário)
# - Link to existing project? → N
# - Project name? → cryptosell
# - In which directory? → ./
# - Override settings? → N

# 4. Aguardar deploy...
```

### **Baixar como ZIP:**

1. Acesse: https://vercel.com/dashboard
2. Clique no projeto **cryptosell**
3. Vá em **Settings** → **Git**
4. Clique em **"Visit Repository"**
5. No GitHub/GitLab, clique em **"Code"** → **"Download ZIP"**

✅ **PRONTO! Você tem o ZIP completo!**

---

## ✅ OPÇÃO 2: SCRIPT AUTOMÁTICO

### **No Linux/Mac:**

```bash
# 1. Dar permissão de execução
chmod +x create-zip.sh

# 2. Executar
./create-zip.sh

# 3. ZIP criado!
# Arquivo: cryptosell-YYYYMMDD-HHMMSS.zip
```

### **No Windows:**

```batch
# 1. Executar o script
create-zip.bat

# 2. ZIP criado!
# Arquivo: cryptosell-YYYYMMDD-HHMMSS.zip
```

### **Extrair o ZIP:**

**Linux/Mac:**
```bash
unzip cryptosell-*.zip
cd cryptosell-export
```

**Windows:**
```batch
powershell Expand-Archive -Path cryptosell-*.zip -DestinationPath .
cd cryptosell-export
```

---

## ✅ OPÇÃO 3: COPIAR MANUALMENTE VIA GIT

Se você tem Git instalado:

```bash
# 1. Inicializar repositório
git init

# 2. Adicionar todos os arquivos
git add .

# 3. Commit
git commit -m "CryptoSell completo"

# 4. Criar bundle (equivalente a ZIP)
git bundle create cryptosell.bundle --all

# 5. Para extrair depois:
git clone cryptosell.bundle cryptosell-extracted
```

---

## ✅ OPÇÃO 4: DOWNLOAD MANUAL DO GITHUB

Se você fez deploy no Vercel ou conectou ao GitHub:

### **Método 1: Via Git Clone**

```bash
# 1. Clonar repositório
git clone https://github.com/seu-usuario/cryptosell.git

# 2. Entrar na pasta
cd cryptosell

# 3. Criar ZIP
zip -r cryptosell.zip .
```

### **Método 2: Via GitHub Web**

1. Acesse seu repositório no GitHub
2. Clique em **"Code"** (botão verde)
3. Clique em **"Download ZIP"**
4. Extraia o ZIP

---

## 📂 ESTRUTURA DO ZIP

Após extrair, você terá:

```
cryptosell/
├── .env.local                      # ⚠️ IMPORTANTE: Configure as chaves
├── .gitignore
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── postcss.config.js
├── App.tsx
│
├── styles/
│   └── globals.css
│
├── pages/
│   └── api/
│       └── create-payment-intent.js
│
├── components/
│   ├── BuyCryptoV3.tsx
│   ├── StripeCheckout.tsx
│   ├── PaymentOptions.tsx
│   ├── QRCodeGenerator.tsx
│   ├── SecurityBadges.tsx
│   ├── StatsBar.tsx
│   ├── BuyCryptoPage.tsx
│   ├── BuyCryptoV1.tsx
│   ├── BuyCryptoV2.tsx
│   │
│   ├── figma/
│   │   └── ImageWithFallback.tsx
│   │
│   └── ui/                         # 65+ componentes
│       ├── button.tsx
│       ├── card.tsx
│       ├── input.tsx
│       └── ...
│
├── data/
│   ├── cryptoData.ts
│   ├── banks.ts
│   └── bankLogos.ts
│
└── *.md                            # Documentação
```

---

## 🚀 APÓS EXTRAIR O ZIP

### **1. Instalar Dependências:**

```bash
cd cryptosell
npm install
```

### **2. Configurar .env.local:**

Verifique se o arquivo `.env.local` existe com as chaves Stripe:

```env
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### **3. Rodar o Projeto:**

```bash
npm run dev
```

### **4. Abrir no Navegador:**

```
http://localhost:3000
```

✅ **FUNCIONANDO!**

---

## 🔍 VERIFICAR SE ESTÁ COMPLETO

### **Checklist de Arquivos:**

```bash
# Verificar se todos os arquivos essenciais existem
ls -la | grep -E '(package.json|App.tsx|.env.local)'
ls -la components/ | wc -l  # Deve ter ~10 arquivos
ls -la components/ui/ | wc -l  # Deve ter ~65 arquivos
ls -la data/ | wc -l  # Deve ter ~3 arquivos
ls -la pages/api/ | wc -l  # Deve ter ~1 arquivo
```

### **Ou verificar pelo número total:**

```bash
# Contar todos os arquivos
find . -type f | wc -l
# Deve ter ~100 arquivos
```

---

## ⚠️ PROBLEMAS COMUNS

### **1. Script não executa (Linux/Mac)**

```bash
# Solução: Dar permissão
chmod +x create-zip.sh
./create-zip.sh
```

### **2. Comando 'zip' não encontrado (Mac)**

```bash
# Solução: Instalar
brew install zip
```

### **3. PowerShell não reconhece comando (Windows)**

```batch
# Solução: Executar como Administrador
# Botão direito no .bat → "Executar como Administrador"
```

### **4. .env.local não está no ZIP**

⚠️ **NORMAL!** O `.gitignore` bloqueia o `.env.local` por segurança.

**Solução:**
Crie manualmente após extrair:

```bash
# Criar .env.local
cat > .env.local << EOF
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml
NEXT_PUBLIC_APP_URL=http://localhost:3000
EOF
```

---

## 📊 TAMANHO ESPERADO DO ZIP

```
Arquivos:           ~100 arquivos
Tamanho (sem node_modules): ~2 MB
Tamanho (com node_modules): ~200 MB
Linhas de código:   ~17.500 linhas
```

⚠️ **IMPORTANTE:** O ZIP NÃO inclui `node_modules`.  
Você precisa rodar `npm install` após extrair!

---

## 🎯 RECOMENDAÇÃO FINAL

### **Para ter ZIP rapidamente:**

**🥇 1º Lugar: Vercel Deploy**
```bash
vercel
# Depois baixar do GitHub como ZIP
```
- ✅ Mais fácil
- ✅ Cria backup automático
- ✅ Site já fica online

**🥈 2º Lugar: Script Automático**
```bash
./create-zip.sh
# ou
create-zip.bat
```
- ✅ Rápido
- ✅ Local
- ✅ Sem internet

**🥉 3º Lugar: Git Bundle**
```bash
git bundle create cryptosell.bundle --all
```
- ✅ Inclui histórico
- ✅ Pode ser versionado

---

## 📚 ARQUIVOS CRIADOS

Você tem estes scripts disponíveis:

```
✅ /create-zip.sh      → Linux/Mac
✅ /create-zip.bat     → Windows
✅ /COMO_CRIAR_ZIP.md  → Este guia
```

---

## ✅ RESUMO

| Método | Tempo | Facilidade | Resultado |
|--------|-------|------------|-----------|
| Vercel + GitHub ZIP | 10 min | ⭐⭐⭐⭐⭐ | Perfeito |
| Script Automático | 2 min | ⭐⭐⭐⭐ | Bom |
| Git Bundle | 5 min | ⭐⭐⭐ | Completo |
| Manual | 1-2h | ⭐⭐ | Trabalhoso |

---

## 🚀 COMEÇAR AGORA

**Escolha uma opção acima e execute!**

**Mais rápido:**
```bash
vercel
```

**Mais simples:**
```bash
./create-zip.sh
```

**Mais completo:**
```bash
git bundle create cryptosell.bundle --all
```

---

**Status:** ✅ Pronto para criar ZIP  
**Arquivos:** ~100 arquivos  
**Tamanho:** ~2 MB (sem node_modules)
