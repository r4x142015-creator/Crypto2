# 📦 Dependências do Sistema de Pagamento Stripe

## 🚀 Instalação Rápida

Execute este comando na raiz do seu projeto:

```bash
npm install stripe @stripe/stripe-js @stripe/react-stripe-js
```

ou se usar Yarn:

```bash
yarn add stripe @stripe/stripe-js @stripe/react-stripe-js
```

ou se usar pnpm:

```bash
pnpm add stripe @stripe/stripe-js @stripe/react-stripe-js
```

## 📋 Detalhes das Dependências

### 1. `stripe` (Backend)
- **Versão**: ^14.0.0 (ou mais recente)
- **Uso**: API Routes (`/pages/api/`)
- **Descrição**: SDK oficial do Stripe para Node.js
- **Funções**:
  - Criar Payment Intents
  - Confirmar pagamentos
  - Gerenciar webhooks
  - Buscar transações

```javascript
// Exemplo de uso:
import Stripe from "stripe";
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
```

### 2. `@stripe/stripe-js` (Frontend)
- **Versão**: ^2.0.0 (ou mais recente)
- **Uso**: Componentes React
- **Descrição**: Carrega o Stripe.js de forma otimizada
- **Funções**:
  - Inicializar Stripe
  - Carregar script de forma assíncrona
  - Garantir segurança PCI

```javascript
// Exemplo de uso:
import { loadStripe } from '@stripe/stripe-js';
const stripePromise = loadStripe('pk_test_...');
```

### 3. `@stripe/react-stripe-js` (Frontend)
- **Versão**: ^2.0.0 (ou mais recente)
- **Uso**: Componentes React de checkout
- **Descrição**: Componentes React oficiais do Stripe
- **Funções**:
  - `<Elements>` - Provider do Stripe
  - `<PaymentElement>` - Formulário de pagamento
  - `useStripe()` - Hook para ações
  - `useElements()` - Hook para elementos

```javascript
// Exemplo de uso:
import { Elements, PaymentElement, useStripe } from '@stripe/react-stripe-js';
```

## 📦 Arquivo package.json (Seção Relevante)

Adicione estas linhas ao seu `package.json`:

```json
{
  "dependencies": {
    "stripe": "^14.0.0",
    "@stripe/stripe-js": "^2.0.0",
    "@stripe/react-stripe-js": "^2.0.0",
    "sonner": "^2.0.3"
  }
}
```

## 🔍 Verificação da Instalação

Após instalar, verifique se as dependências foram adicionadas:

```bash
# Ver versões instaladas
npm list stripe
npm list @stripe/stripe-js
npm list @stripe/react-stripe-js
```

## ⚙️ Dependências Relacionadas Já Instaladas

Estas dependências já devem estar no seu projeto:

✅ `react` - ^18.x
✅ `lucide-react` - Para ícones
✅ `sonner` - Para toast notifications
✅ Componentes ShadCN UI

## 🌐 CDN (Alternativa - Não Recomendado)

Se por algum motivo não puder usar npm, você pode carregar via CDN (não recomendado para produção):

```html
<!-- No <head> do seu HTML -->
<script src="https://js.stripe.com/v3/"></script>
```

⚠️ **Recomendamos usar a instalação via npm para melhor performance e segurança!**

## 🔄 Atualizando Dependências

Para atualizar para as versões mais recentes:

```bash
npm update stripe @stripe/stripe-js @stripe/react-stripe-js
```

ou

```bash
yarn upgrade stripe @stripe/stripe-js @stripe/react-stripe-js
```

## 🐛 Problemas Comuns

### Erro: "Cannot find module 'stripe'"
**Solução:**
```bash
rm -rf node_modules package-lock.json
npm install
```

### Erro: "Stripe is not defined"
**Solução:**
- Verifique se instalou `@stripe/stripe-js`
- Reinicie o servidor de desenvolvimento
- Limpe cache: `npm run clean` ou delete `.next`

### Erro de TypeScript
**Solução:**
```bash
npm install --save-dev @types/stripe
```

## 📊 Tamanho dos Pacotes

```
stripe: ~500KB (backend only)
@stripe/stripe-js: ~50KB (lazy loaded)
@stripe/react-stripe-js: ~20KB
```

**Total:** ~570KB (stripe.js é carregado apenas quando necessário)

## ✅ Checklist de Instalação

- [ ] Instalei as 3 dependências do Stripe
- [ ] Criei o arquivo `.env.local` com as chaves
- [ ] Reiniciei o servidor de desenvolvimento
- [ ] Testei a página de compra
- [ ] Sem erros no console

## 🎯 Próximos Passos

Após instalar as dependências:

1. Configure o `.env.local` (veja INSTRUCOES_PAGAMENTO.md)
2. Reinicie o servidor: `npm run dev`
3. Acesse a página "Comprar Cripto"
4. Teste com cartões de teste do Stripe

---

**Pronto para processar pagamentos! 🚀💳**
