# 💳 Instruções de Configuração do Sistema de Pagamento

## 📦 Dependências Necessárias

Instale as seguintes dependências no seu projeto:

```bash
npm install stripe @stripe/stripe-js @stripe/react-stripe-js
```

ou

```bash
yarn add stripe @stripe/stripe-js @stripe/react-stripe-js
```

## 🔐 Configuração das Chaves do Stripe

### 1️⃣ Crie o arquivo `.env.local`

Na **raiz do seu projeto**, crie um arquivo chamado `.env.local` e adicione:

```env
NEXT_PUBLIC_STRIPE_PUBLIC_KEY=pk_test_51SWaX2Rou34EiKZy0tu1ig2G1WDZMucFM66mtbw9y1Nvt7cULGji2G9YVgsbuIcuwWGzkpRiDvGymsny7KjDAkTj00fgKt1fXB
STRIPE_SECRET_KEY=sk_test_51SWaX2Rou34EiKZyw8jcIcBEHPCW1s0VSPOpPD46X2AJPI9SzbcFoISONh49wwHBMMfI8VsbnbI5GN2l3q7fzToZ00UF7riVMu
```

⚠️ **IMPORTANTE**: Adicione `.env.local` ao seu `.gitignore` para não commitar as chaves!

### 2️⃣ Obtenha suas próprias chaves (Recomendado)

1. Acesse: https://dashboard.stripe.com/register
2. Crie uma conta gratuita
3. Vá em **Developers** → **API Keys**
4. Copie a **Publishable key** (começa com `pk_test_`)
5. Copie a **Secret key** (começa com `sk_test_`)
6. Substitua no arquivo `.env.local`

## 📁 Estrutura de Arquivos Criada

```
/
├── .env.local                        # Configurações (NÃO commitar)
├── .env.example                      # Exemplo de configuração
├── pages/
│   └── api/
│       ├── pagamento.js              # API de criação de pagamento
│       └── confirm-payment.js        # API de confirmação
├── components/
│   ├── StripeCheckout.tsx            # Componente de checkout
│   └── BuyCryptoPage.tsx             # Página de compra (atualizada)
└── INSTRUCOES_PAGAMENTO.md           # Este arquivo
```

## 🚀 Como Funciona

### Fluxo de Pagamento:

1. **Usuário seleciona cripto e valor**
   - Escolhe BTC, ETH, SOL, etc
   - Define quanto quer investir (mínimo R$ 500)
   - Seleciona método: PIX ou Cartão

2. **Clica em "Comprar Agora"**
   - Sistema valida os dados
   - Cria um Payment Intent no Stripe
   - Redireciona para página de checkout

3. **Checkout do Stripe**
   - Interface segura do Stripe
   - Suporta PIX e Cartão de Crédito
   - Processamento em tempo real

4. **Confirmação**
   - Pagamento aprovado ✅
   - Toast de sucesso
   - Email de confirmação (se fornecido)

## 💰 Métodos de Pagamento Disponíveis

### 🇧🇷 Para BRL (Real Brasileiro):
- ✅ **PIX** - Instantâneo
- ✅ **Cartão de Crédito/Débito**
- ❌ PayPal (não suportado pelo Stripe no Brasil)

### 🌍 Para outras moedas:
- ✅ **Cartão de Crédito/Débito**
- ❌ PIX (apenas BRL)

## 🔒 Segurança

### SSL/TLS:
- Todos os dados são criptografados
- Comunicação HTTPS obrigatória
- Nunca armazenamos dados de cartão

### PCI DSS Compliance:
- Stripe é certificado PCI Level 1
- Máxima segurança para pagamentos
- Conformidade com regulações internacionais

### Testes:
Use os cartões de teste do Stripe:

```
Cartão de Sucesso:
4242 4242 4242 4242
Validade: Qualquer data futura
CVV: Qualquer 3 dígitos
CEP: Qualquer

Cartão que requer autenticação:
4000 0025 0000 3155

Cartão que falha:
4000 0000 0000 9995
```

## ⚙️ Configurações Avançadas

### Webhook (Opcional):

Para receber notificações de pagamentos:

1. No Dashboard do Stripe: **Developers** → **Webhooks**
2. Adicione endpoint: `https://seusite.com/api/webhook`
3. Eventos recomendados:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `charge.refunded`

### Metadata Enviada:

Cada pagamento inclui:
```javascript
{
  crypto_symbol: "BTC",
  customer_email: "usuario@email.com",
  tipo_transacao: "compra_cripto"
}
```

## 🧪 Testando o Sistema

### 1. Modo de Teste (Desenvolvimento):
```bash
# Usar chaves pk_test_ e sk_test_
npm run dev
```

### 2. Testar PIX:
- Selecione "PIX" como método
- Stripe gerará QR Code de teste
- Simule pagamento no dashboard

### 3. Testar Cartão:
- Use cartões de teste acima
- Preencha dados fictícios
- Confirme pagamento

## 📊 Monitoramento

### Dashboard do Stripe:
- Ver todas as transações
- Logs de API calls
- Gráficos de receita
- Relatórios detalhados

### Logs da Aplicação:
```javascript
// No console você verá:
✅ Payment Intent criado: pi_xxxxx
✅ Status do pagamento: succeeded
❌ Erro ao criar pagamento: [mensagem]
```

## 🔄 Ambiente de Produção

### Quando for fazer deploy:

1. **Obtenha chaves de produção**:
   - `pk_live_...` (pública)
   - `sk_live_...` (secreta)

2. **Configure no servidor**:
   ```env
   NEXT_PUBLIC_STRIPE_PUBLIC_KEY=pk_live_xxxxx
   STRIPE_SECRET_KEY=sk_live_xxxxx
   ```

3. **Ative o modo live** no Stripe Dashboard

4. **Configure Webhooks** para produção

## ❓ Troubleshooting

### Erro: "Stripe is not defined"
✅ Verifique se instalou `@stripe/stripe-js`

### Erro: "API key invalid"
✅ Verifique o `.env.local`
✅ Reinicie o servidor de dev

### PIX não aparece como opção
✅ Certifique-se de estar usando BRL
✅ Verifique se o Stripe suporta PIX na sua região

### Pagamento não processa
✅ Verifique console do navegador
✅ Verifique logs da API
✅ Confirme que as chaves estão corretas

## 📞 Suporte

### Documentação Oficial:
- Stripe Docs: https://stripe.com/docs
- Stripe React: https://stripe.com/docs/stripe-js/react

### Stripe Dashboard:
- https://dashboard.stripe.com

## 🎉 Pronto!

Seu sistema de pagamento está configurado e pronto para uso! 🚀

**Recursos Implementados:**
✅ Pagamento via PIX
✅ Pagamento via Cartão
✅ Validação de valores mínimos
✅ Cálculo automático de tokens
✅ Interface premium
✅ Segurança PCI DSS
✅ Notificações em tempo real
✅ Suporte multi-moeda
✅ Responsive design

---

**Desenvolvido com ❤️ para CryptoSell**
**Versão: 2.0 - Sistema de Pagamento Integrado**
