# 💎 CryptoSell - Exchange de Criptomoedas Premium

Sistema completo de compra e venda de criptomoedas com pagamentos reais via Stripe.

## 🚀 Início Rápido

### Rodar Localmente (2 minutos)
```bash
npm install
npm run dev
```
Acesse: http://localhost:3000

### Deploy Produção (5 minutos)
```bash
npm i -g vercel
vercel
```

## ✅ O que está incluído

- ✅ **50+ Carteiras Blockchain** (BTC, ETH, USDT, SOL, TON, etc)
- ✅ **100+ Bancos Brasileiros e Internacionais**
- ✅ **Pagamentos Reais Stripe** (cartão de crédito/débito)
- ✅ **Cotação em Tempo Real**
- ✅ **Design Premium Dark com Glassmorphism**
- ✅ **Backend Seguro** (chave secreta protegida)
- ✅ **Suporte 3D Secure**
- ✅ **Responsivo Mobile/Desktop**
- ✅ **Selos de Segurança** (Norton, McAfee, SSL 256-bit, PCI DSS)

## 🔐 Segurança

- Chave secreta Stripe no backend (`.env.local`)
- Frontend usa apenas chave pública
- APIs protegidas com validações
- Criptografia SSL 256-bit
- Autenticação 3D Secure

## 📁 Estrutura

```
/
├── .env.local                      # Chaves Stripe (seguro)
├── pages/api/create-payment-intent.js  # Backend API
├── components/StripeCheckout.tsx   # Checkout Frontend
└── App.tsx                         # Aplicação Principal
```

## 💳 Testar

**Cartão de Teste:**
```
Número: 4242 4242 4242 4242
Validade: 12/30
CVV: 123
```

**Cartão Real:**
Use qualquer cartão - será cobrado de verdade!

## 📖 Documentação

- **Início Rápido:** `/INICIO_RAPIDO.md`
- **Como Rodar Seguro:** `/COMO_RODAR_SEGURO.md`
- **Cartões Recusados:** `/CARTOES_RECUSADOS_SOLUCAO.md`

## 🔧 Tecnologias

- Next.js / React
- Stripe Payments
- Tailwind CSS v4
- Shadcn/ui
- TypeScript

## 💰 Taxas

- **Stripe:** 2.99% + R$ 0,39 por transação
- **Vercel:** Grátis (tier gratuito)

## 🆘 Suporte

Dashboard Stripe: https://dashboard.stripe.com  
Vercel: https://vercel.com/dashboard

---

**Status:** ✅ Pronto para produção  
**Próximo passo:** `npm run dev`
