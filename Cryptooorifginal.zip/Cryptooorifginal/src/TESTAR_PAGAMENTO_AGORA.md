# ⚡ TESTAR PAGAMENTO AGORA - GUIA RÁPIDO

## 🎯 3 PASSOS SIMPLES

---

## ✅ PASSO 1: INSTALAR E RODAR

Copie e cole no terminal:

```bash
npm install && npm run dev
```

**Aguarde aparecer:**
```
✓ Ready in 2.3s
○ Local: http://localhost:3000
```

---

## ✅ PASSO 2: ABRIR NO NAVEGADOR

Abra: **http://localhost:3000**

---

## ✅ PASSO 3: TESTAR PAGAMENTO

### **1. Clique em "Comprar Cripto"** (aba verde no topo)

### **2. Preencha o formulário:**
   - **Criptomoeda:** Escolha qualquer uma (ex: Bitcoin, USDT)
   - **Valor:** Digite pelo menos R$ 100,00
   - **Método:** Escolha "Cartão de Crédito"
   
### **3. Clique em "Comprar Agora"**

### **4. Preencha dados do cartão:**

#### **🔴 USANDO CHAVES LIVE (Atual):**

As chaves no `.env.local` são **LIVE** (reais).
Use cartão real para testar:

```
💳 Qualquer cartão válido:
   - Visa, Mastercard, Elo, Amex
   - Dados reais do cartão
   - ⚠️ Cobrará dinheiro REAL!
```

#### **🟢 PARA TESTES SEM COBRAR (Recomendado):**

Altere o `.env.local` para usar chaves de teste:

```bash
# Editar .env.local
# Trocar as chaves para:
STRIPE_SECRET_KEY=sk_test_sua_chave_de_teste
STRIPE_PUBLISHABLE_KEY=pk_test_sua_chave_de_teste
```

Depois use cartão de teste:

```
💳 Cartão de Teste (Aprovado):
   Número: 4242 4242 4242 4242
   Data: 12/25 (qualquer data futura)
   CVV: 123 (qualquer 3 dígitos)
   CEP: 12345-678 (qualquer CEP)
```

### **5. Clique em "Pagar R$ XXX"**

### **6. Aguarde o processamento...**

**Você verá:**
- ⏳ "Processando..."
- ✅ "Pagamento Aprovado!" (se aprovado)
- ❌ "Pagamento Recusado" (se recusado)

---

## 🎉 PRONTO!

Se você viu a mensagem **"Pagamento Aprovado!"**, está funcionando!

---

## 🔍 VERIFICAR SE FUNCIONOU

### **No Terminal:**
```
✅ Criando Payment Intent: {...}
✅ Payment Intent criado com sucesso: pi_xxxxx
💰 Valor: 10000 centavos (R$ 100.00)
```

### **No Console do Navegador (F12):**
```
🔄 Criando Payment Intent via API backend...
✅ Payment Intent criado: pi_xxxxx
🔄 Confirmando pagamento...
✅ Pagamento aprovado: pi_xxxxx
```

### **No Dashboard Stripe:**
1. Acesse: https://dashboard.stripe.com
2. Login com sua conta
3. Vá em "Pagamentos"
4. Veja a transação listada

---

## 🆘 PROBLEMAS?

### **❌ "Failed to fetch"**

**Solução:**
```bash
# Reiniciar servidor
Ctrl+C
npm run dev
```

### **❌ "STRIPE_SECRET_KEY is not defined"**

**Solução:**
```bash
# Verificar .env.local
cat .env.local

# Se vazio ou não existir, criar:
cat > .env.local << 'EOF'
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml
NEXT_PUBLIC_APP_URL=http://localhost:3000
EOF

# Reiniciar
npm run dev
```

### **❌ Cartão Recusado**

**Causas:**
- Banco bloqueou (mais comum com bancos brasileiros)
- Limite insuficiente
- Cartão não habilitado para online

**Soluções:**
1. Entre em contato com banco e autorize "STRIPE*CRYPTOSELL"
2. Habilite compras online no app do banco
3. Tente outro cartão
4. Use cartão virtual do banco

---

## 🎯 SCRIPT DE VERIFICAÇÃO

Execute para checar tudo:

### **Linux/Mac:**
```bash
chmod +x verificar-pagamento.sh
./verificar-pagamento.sh
```

### **Windows:**
```batch
verificar-pagamento.bat
```

**Mostra:**
- ✅ Arquivos existem
- ✅ Chaves configuradas
- ✅ Dependências instaladas
- ✅ Servidor rodando
- ✅ API funcionando

---

## 💳 CARTÕES DE TESTE

### **Para usar cartões de teste:**

1. **Edite `.env.local`** com chaves de teste:
```env
STRIPE_SECRET_KEY=sk_test_sua_chave
STRIPE_PUBLISHABLE_KEY=pk_test_sua_chave
```

2. **Reinicie o servidor:**
```bash
npm run dev
```

3. **Use estes cartões:**

```
✅ APROVADO:
   4242 4242 4242 4242

✅ COM 3D SECURE:
   4000 0027 6000 3184

❌ RECUSADO:
   4000 0000 0000 0002

❌ SALDO INSUFICIENTE:
   4000 0000 0000 9995

❌ EXPIRADO:
   4000 0000 0000 0069
```

**Para todos:**
- Data: Qualquer futura (12/25)
- CVV: Qualquer 3 dígitos (123)
- CEP: Qualquer (12345-678)

**Lista completa:** https://stripe.com/docs/testing

---

## 📱 FLUXO VISUAL

```
1. Abrir Site
   ↓
2. "Comprar Cripto" (aba verde)
   ↓
3. Escolher Criptomoeda
   ↓
4. Digite Valor (mín. R$ 100)
   ↓
5. Escolher "Cartão de Crédito"
   ↓
6. "Comprar Agora"
   ↓
7. [Tela Stripe aparece]
   ↓
8. Preencher dados do cartão
   ↓
9. "Pagar R$ XXX"
   ↓
10. ⏳ Processando...
   ↓
11. ✅ Aprovado! 🎉
```

---

## ✅ CHECKLIST RÁPIDO

- [ ] `npm install` executado
- [ ] `npm run dev` rodando
- [ ] `http://localhost:3000` aberto
- [ ] Aba "Comprar Cripto" clicada
- [ ] Formulário preenchido
- [ ] "Comprar Agora" clicado
- [ ] Tela Stripe apareceu
- [ ] Dados do cartão preenchidos
- [ ] "Pagar R$ XXX" clicado
- [ ] Viu "Processando..."
- [ ] Viu resultado (Aprovado/Recusado)

---

## 🚀 COMANDOS ÚTEIS

### **Iniciar:**
```bash
npm run dev
```

### **Parar:**
```bash
Ctrl+C
```

### **Reiniciar:**
```bash
Ctrl+C
npm run dev
```

### **Limpar e reiniciar:**
```bash
rm -rf node_modules .next
npm install
npm run dev
```

### **Ver logs detalhados:**
```bash
# Os logs aparecem no terminal enquanto roda
npm run dev
```

---

## 📚 DOCUMENTAÇÃO COMPLETA

Para mais detalhes:
- **`/PAGAMENTO_FUNCIONANDO.md`** - Guia completo
- **`/CARTOES_RECUSADOS_SOLUCAO.md`** - Ajuda com cartões
- **`/COMO_USAR_PAGAMENTOS_REAIS.md`** - Deploy em produção

---

## 🎯 RESUMO DE 1 LINHA

```bash
npm install && npm run dev
# Depois: http://localhost:3000 → Comprar Cripto → Testar!
```

---

**Status:** ✅ Sistema funcionando  
**Backend:** ✅ Rodando  
**Stripe:** ✅ Integrado  
**Pronto para:** ✅ Processar pagamentos reais  

**TESTE AGORA!** 🚀💳
