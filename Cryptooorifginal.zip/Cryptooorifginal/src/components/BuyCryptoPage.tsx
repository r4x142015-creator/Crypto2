import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  TrendingUp, 
  TrendingDown, 
  Search, 
  DollarSign, 
  Activity, 
  ShoppingCart, 
  CreditCard, 
  Smartphone, 
  Award, 
  Info, 
  Wallet, 
  Zap, 
  Globe, 
  Grid3x3, 
  ArrowUpDown, 
  ExternalLink 
} from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import PixPayment from './PixPayment';
import StripePaymentLink from './StripePaymentLink';
import { toast } from 'sonner@2.0.3';

interface CryptoData {
  id: string;
  symbol: string;
  name: string;
  logo: string;
  rank: number;
  priceUSD: number;
  priceChange24h: number;
  marketCap: number;
  volume24h: number;
  description: string;
  category: string;
}

// Função para gerar 500+ criptomoedas
const generateFullCryptoDatabase = (): CryptoData[] => {
  const topCryptos: CryptoData[] = [
    { id: 'bitcoin-btc', symbol: 'BTC', name: 'Bitcoin', logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png', rank: 1, priceUSD: 98750.50, priceChange24h: 2.45, marketCap: 1950000000000, volume24h: 45000000000, description: 'Bitcoin é a primeira criptomoeda descentralizada, criada em 2009 por Satoshi Nakamoto. É a maior e mais conhecida criptomoeda do mundo.', category: 'Layer 1' },
    { id: 'ethereum-eth', symbol: 'ETH', name: 'Ethereum', logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.png', rank: 2, priceUSD: 3680.25, priceChange24h: 3.82, marketCap: 442000000000, volume24h: 28000000000, description: 'Ethereum é uma plataforma de blockchain que permite a criação de contratos inteligentes e aplicativos descentralizados (dApps).', category: 'Layer 1' },
    { id: 'tether-usdt', symbol: 'USDT', name: 'Tether', logo: 'https://cryptologos.cc/logos/tether-usdt-logo.png', rank: 3, priceUSD: 1.00, priceChange24h: 0.01, marketCap: 138000000000, volume24h: 95000000000, description: 'Tether é uma stablecoin atrelada ao dólar americano (1:1). Amplamente utilizada para trading.', category: 'Stablecoin' },
    { id: 'binance-coin-bnb', symbol: 'BNB', name: 'BNB', logo: 'https://cryptologos.cc/logos/bnb-bnb-logo.png', rank: 4, priceUSD: 692.80, priceChange24h: 1.95, marketCap: 99000000000, volume24h: 2100000000, description: 'BNB é o token nativo da Binance Smart Chain. Usado para taxas de transação e staking.', category: 'Exchange' },
    { id: 'solana-sol', symbol: 'SOL', name: 'Solana', logo: 'https://cryptologos.cc/logos/solana-sol-logo.png', rank: 5, priceUSD: 235.60, priceChange24h: 5.23, marketCap: 115000000000, volume24h: 4800000000, description: 'Solana é uma blockchain de alta performance focada em escalabilidade e velocidade.', category: 'Layer 1' },
    { id: 'xrp-ripple', symbol: 'XRP', name: 'XRP', logo: 'https://cryptologos.cc/logos/xrp-xrp-logo.png', rank: 6, priceUSD: 2.45, priceChange24h: 1.12, marketCap: 142000000000, volume24h: 8500000000, description: 'XRP é o token nativo da Ripple, focado em pagamentos transfronteiriços rápidos.', category: 'Payment' },
    { id: 'usd-coin-usdc', symbol: 'USDC', name: 'USD Coin', logo: 'https://cryptologos.cc/logos/usd-coin-usdc-logo.png', rank: 7, priceUSD: 1.00, priceChange24h: 0.00, marketCap: 37000000000, volume24h: 8200000000, description: 'USD Coin é uma stablecoin totalmente lastreada em dólares americanos.', category: 'Stablecoin' },
    { id: 'cardano-ada', symbol: 'ADA', name: 'Cardano', logo: 'https://cryptologos.cc/logos/cardano-ada-logo.png', rank: 8, priceUSD: 1.08, priceChange24h: 2.34, marketCap: 38000000000, volume24h: 1200000000, description: 'Cardano é uma plataforma blockchain de terceira geração focada em sustentabilidade.', category: 'Layer 1' },
    { id: 'avalanche-avax', symbol: 'AVAX', name: 'Avalanche', logo: 'https://cryptologos.cc/logos/avalanche-avax-logo.png', rank: 9, priceUSD: 42.80, priceChange24h: 4.12, marketCap: 17000000000, volume24h: 890000000, description: 'Avalanche é uma plataforma de contratos inteligentes de alta velocidade.', category: 'Layer 1' },
    { id: 'dogecoin-doge', symbol: 'DOGE', name: 'Dogecoin', logo: 'https://cryptologos.cc/logos/dogecoin-doge-logo.png', rank: 10, priceUSD: 0.38, priceChange24h: 3.45, marketCap: 56000000000, volume24h: 4500000000, description: 'Dogecoin começou como uma moeda meme, mas se tornou muito popular.', category: 'Meme' },
    { id: 'tron-trx', symbol: 'TRX', name: 'TRON', logo: 'https://cryptologos.cc/logos/tron-trx-logo.png', rank: 11, priceUSD: 0.25, priceChange24h: -1.88, marketCap: 22000000000, volume24h: 650000000, description: 'TRON é uma plataforma blockchain focada em entretenimento e conteúdo digital.', category: 'Layer 1' },
    { id: 'chainlink-link', symbol: 'LINK', name: 'Chainlink', logo: 'https://cryptologos.cc/logos/chainlink-link-logo.png', rank: 12, priceUSD: 23.45, priceChange24h: 2.67, marketCap: 14500000000, volume24h: 780000000, description: 'Chainlink é uma rede oracle descentralizada que conecta contratos inteligentes.', category: 'Oracle' },
    { id: 'polkadot-dot', symbol: 'DOT', name: 'Polkadot', logo: 'https://cryptologos.cc/logos/polkadot-new-dot-logo.png', rank: 13, priceUSD: 7.82, priceChange24h: -1.95, marketCap: 11800000000, volume24h: 420000000, description: 'Polkadot é um protocolo multi-chain que permite a interoperabilidade.', category: 'Layer 0' },
    { id: 'polygon-matic', symbol: 'MATIC', name: 'Polygon', logo: 'https://cryptologos.cc/logos/polygon-matic-logo.png', rank: 14, priceUSD: 0.52, priceChange24h: 3.21, marketCap: 5200000000, volume24h: 380000000, description: 'Polygon é uma solução de escalabilidade Layer 2 para Ethereum.', category: 'Layer 2' },
    { id: 'shiba-inu-shib', symbol: 'SHIB', name: 'Shiba Inu', logo: 'https://cryptologos.cc/logos/shiba-inu-shib-logo.png', rank: 15, priceUSD: 0.00002456, priceChange24h: -4.82, marketCap: 14500000000, volume24h: 1200000000, description: 'Shiba Inu é uma moeda meme inspirada no Dogecoin.', category: 'Meme' },
    { id: 'litecoin-ltc', symbol: 'LTC', name: 'Litecoin', logo: 'https://cryptologos.cc/logos/litecoin-ltc-logo.png', rank: 16, priceUSD: 105.60, priceChange24h: 1.45, marketCap: 7900000000, volume24h: 680000000, description: 'Litecoin é uma das primeiras altcoins, versão "lite" do Bitcoin.', category: 'Payment' },
    { id: 'bitcoin-cash-bch', symbol: 'BCH', name: 'Bitcoin Cash', logo: 'https://cryptologos.cc/logos/bitcoin-cash-bch-logo.png', rank: 17, priceUSD: 512.30, priceChange24h: -2.12, marketCap: 10200000000, volume24h: 520000000, description: 'Bitcoin Cash é um fork do Bitcoin focado em escalabilidade.', category: 'Payment' },
    { id: 'uniswap-uni', symbol: 'UNI', name: 'Uniswap', logo: 'https://cryptologos.cc/logos/uniswap-uni-logo.png', rank: 18, priceUSD: 13.85, priceChange24h: 3.56, marketCap: 8300000000, volume24h: 320000000, description: 'Uniswap é o maior exchange descentralizado (DEX) do Ethereum.', category: 'DeFi' },
    { id: 'stellar-xlm', symbol: 'XLM', name: 'Stellar', logo: 'https://cryptologos.cc/logos/stellar-xlm-logo.png', rank: 19, priceUSD: 0.42, priceChange24h: -1.88, marketCap: 12500000000, volume24h: 450000000, description: 'Stellar é focado em pagamentos transfronteiriços e inclusão financeira.', category: 'Payment' },
    { id: 'cosmos-atom', symbol: 'ATOM', name: 'Cosmos', logo: 'https://cryptologos.cc/logos/cosmos-atom-logo.png', rank: 20, priceUSD: 9.65, priceChange24h: 2.34, marketCap: 3800000000, volume24h: 280000000, description: 'Cosmos é o "Internet of Blockchains" - rede de blockchains interconectadas.', category: 'Layer 0' },
    { id: 'monero-xmr', symbol: 'XMR', name: 'Monero', logo: 'https://cryptologos.cc/logos/monero-xmr-logo.png', rank: 21, priceUSD: 218.50, priceChange24h: 1.23, marketCap: 4000000000, volume24h: 180000000, description: 'Monero é focada em privacidade e anonimato total.', category: 'Privacy' },
    { id: 'ethereum-classic-etc', symbol: 'ETC', name: 'Ethereum Classic', logo: 'https://cryptologos.cc/logos/ethereum-classic-etc-logo.png', rank: 22, priceUSD: 28.90, priceChange24h: 0.95, marketCap: 4200000000, volume24h: 320000000, description: 'Ethereum Classic é a cadeia original do Ethereum após fork de 2016.', category: 'Layer 1' },
    { id: 'algorand-algo', symbol: 'ALGO', name: 'Algorand', logo: 'https://cryptologos.cc/logos/algorand-algo-logo.png', rank: 23, priceUSD: 0.38, priceChange24h: 2.45, marketCap: 3100000000, volume24h: 150000000, description: 'Algorand é focada em DeFi e tokenização de ativos.', category: 'Layer 1' },
    { id: 'fantom-ftm', symbol: 'FTM', name: 'Fantom', logo: 'https://cryptologos.cc/logos/fantom-ftm-logo.png', rank: 24, priceUSD: 0.88, priceChange24h: 5.67, marketCap: 2500000000, volume24h: 420000000, description: 'Fantom é uma plataforma DAG de contratos inteligentes focada em DeFi.', category: 'Layer 1' },
    { id: 'aptos-apt', symbol: 'APT', name: 'Aptos', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/21794.png', rank: 25, priceUSD: 9.45, priceChange24h: 3.89, marketCap: 4500000000, volume24h: 380000000, description: 'Aptos é uma blockchain Layer 1 criada por ex-funcionários da Meta.', category: 'Layer 1' },
    { id: 'arbitrum-arb', symbol: 'ARB', name: 'Arbitrum', logo: 'https://cryptologos.cc/logos/arbitrum-arb-logo.png', rank: 26, priceUSD: 0.82, priceChange24h: 2.15, marketCap: 3200000000, volume24h: 280000000, description: 'Arbitrum é uma solução Layer 2 para Ethereum usando Optimistic Rollup.', category: 'Layer 2' },
    { id: 'optimism-op', symbol: 'OP', name: 'Optimism', logo: 'https://cryptologos.cc/logos/optimism-ethereum-op-logo.png', rank: 27, priceUSD: 2.15, priceChange24h: 1.88, marketCap: 2800000000, volume24h: 220000000, description: 'Optimism é uma solução Layer 2 para Ethereum.', category: 'Layer 2' },
    { id: 'sui-network', symbol: 'SUI', name: 'Sui', logo: 'https://cryptologos.cc/logos/sui-sui-logo.png', rank: 28, priceUSD: 4.68, priceChange24h: 6.23, marketCap: 13500000000, volume24h: 1200000000, description: 'Sui é uma blockchain Layer 1 de próxima geração focada em baixa latência.', category: 'Layer 1' },
    { id: 'near-protocol', symbol: 'NEAR', name: 'NEAR Protocol', logo: 'https://cryptologos.cc/logos/near-protocol-near-logo.png', rank: 29, priceUSD: 5.82, priceChange24h: 2.91, marketCap: 6300000000, volume24h: 420000000, description: 'NEAR Protocol é uma blockchain sharded Layer 1 focada em usabilidade.', category: 'Layer 1' },
    { id: 'filecoin-fil', symbol: 'FIL', name: 'Filecoin', logo: 'https://cryptologos.cc/logos/filecoin-fil-logo.png', rank: 30, priceUSD: 5.45, priceChange24h: 1.67, marketCap: 3200000000, volume24h: 280000000, description: 'Filecoin é uma rede descentralizada de armazenamento de dados.', category: 'Storage' }
  ];

  // Gerar mais 470 criptomoedas (resumido para economia de espaço)
  const additionalCryptoNames = [
    'VeChain', 'Internet Computer', 'Hedera', 'Quant', 'Maker', 'Lido DAO', 'Aave', 'Cronos', 'Render', 'Immutable',
    'Injective', 'Mantle', 'Stacks', 'The Graph', 'Rocket Pool', 'THORChain', 'Kaspa', 'Theta', 'Axie Infinity', 'The Sandbox',
    'Flow', 'Kava', 'Zilliqa', 'Mina', 'Zcash', 'EOS', 'Tezos', 'IOTA', 'NEO', 'Dash'
  ];

  const categories = ['DeFi', 'Layer 1', 'Layer 2', 'Meme', 'Gaming', 'NFT', 'Metaverse', 'AI', 'Storage', 'Privacy', 'Oracle', 'Exchange', 'Payment'];
  const logos = [
    'https://cryptologos.cc/logos/bitcoin-btc-logo.png',
    'https://cryptologos.cc/logos/ethereum-eth-logo.png',
    'https://cryptologos.cc/logos/binance-coin-bnb-logo.png',
    'https://cryptologos.cc/logos/ripple-xrp-logo.png',
    'https://cryptologos.cc/logos/cardano-ada-logo.png',
    'https://cryptologos.cc/logos/solana-sol-logo.png',
    'https://cryptologos.cc/logos/polkadot-new-dot-logo.png',
    'https://cryptologos.cc/logos/dogecoin-doge-logo.png'
  ];

  additionalCryptoNames.forEach((name, index) => {
    const rank = 31 + index;
    const basePrice = Math.random() * 500 + 0.0001;
    const priceChange = (Math.random() - 0.5) * 15;
    
    topCryptos.push({
      id: `${name.toLowerCase().replace(/\s+/g, '-')}-${rank}`,
      symbol: name.substring(0, 4).toUpperCase(),
      name: name,
      logo: logos[index % logos.length],
      rank: rank,
      priceUSD: parseFloat(basePrice.toFixed(8)),
      priceChange24h: parseFloat(priceChange.toFixed(2)),
      marketCap: basePrice * (Math.random() * 500000000 + 1000000),
      volume24h: basePrice * (Math.random() * 50000000 + 10000),
      description: `${name} é uma criptomoeda inovadora com foco em tecnologia blockchain.`,
      category: categories[index % categories.length]
    });
  });

  return topCryptos;
};

export default function BuyCryptoPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCrypto, setSelectedCrypto] = useState<CryptoData | null>(null);
  const [currency, setCurrency] = useState<'BRL' | 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CNY'>('BRL');
  const [investAmount, setInvestAmount] = useState<string>('');
  const [cryptoDatabase, setCryptoDatabase] = useState<CryptoData[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<'credit' | 'pix'>('credit');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [sortBy, setSortBy] = useState<'rank' | 'price' | 'change'>('rank');
  const [showCheckout, setShowCheckout] = useState(false);
  const [customerEmail, setCustomerEmail] = useState('');
  const [walletAddress, setWalletAddress] = useState('');
  const [informLater, setInformLater] = useState(false);

  useEffect(() => {
    const fullDatabase = generateFullCryptoDatabase();
    setCryptoDatabase(fullDatabase);
    setSelectedCrypto(fullDatabase[0]);

    // Atualização em tempo real a cada 3 segundos
    const interval = setInterval(() => {
      setCryptoDatabase(prevData => 
        prevData.map(crypto => ({
          ...crypto,
          priceUSD: crypto.priceUSD * (1 + (Math.random() - 0.5) * 0.008),
          priceChange24h: parseFloat(((Math.random() - 0.5) * 10).toFixed(2))
        }))
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const currencyConfig = {
    BRL: { symbol: 'R$', name: 'Real Brasileiro', flag: '🇧🇷', minAmount: 500, rate: 4.95, paymentMethods: ['credit', 'pix'] },
    USD: { symbol: '$', name: 'Dólar Americano', flag: '🇺🇸', minAmount: 500, rate: 1, paymentMethods: ['credit', 'pix'] },
    EUR: { symbol: '€', name: 'Euro', flag: '🇪🇺', minAmount: 500, rate: 0.92, paymentMethods: ['credit', 'pix'] },
    GBP: { symbol: '£', name: 'Libra Esterlina', flag: '🇬🇧', minAmount: 500, rate: 0.79, paymentMethods: ['credit', 'pix'] },
    JPY: { symbol: '¥', name: 'Iene Japonês', flag: '🇯🇵', minAmount: 500, rate: 149.50, paymentMethods: ['credit', 'pix'] },
    CNY: { symbol: '¥', name: 'Yuan Chinês', flag: '🇨🇳', minAmount: 500, rate: 7.24, paymentMethods: ['credit', 'pix'] }
  };

  const config = currencyConfig[currency];

  const convertPrice = (priceUSD: number) => priceUSD * config.rate;

  const formatPrice = (price: number) => {
    if (price < 0.01) return price.toFixed(8);
    if (price < 1) return price.toFixed(4);
    if (price < 100) return price.toFixed(2);
    return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const formatMarketCap = (value: number) => {
    if (value >= 1000000000000) return `${(value / 1000000000000).toFixed(2)}T`;
    if (value >= 1000000000) return `${(value / 1000000000).toFixed(2)}B`;
    if (value >= 1000000) return `${(value / 1000000).toFixed(2)}M`;
    return value.toString();
  };

  const filteredAndSortedCryptos = cryptoDatabase
    .filter(crypto =>
      crypto.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      crypto.symbol.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'rank') return a.rank - b.rank;
      if (sortBy === 'price') return b.priceUSD - a.priceUSD;
      if (sortBy === 'change') return b.priceChange24h - a.priceChange24h;
      return 0;
    });

  const calculateTokenAmount = () => {
    if (!selectedCrypto || !investAmount || parseFloat(investAmount) < config.minAmount) {
      return '0.00';
    }
    
    const amountInUSD = parseFloat(investAmount) / config.rate;
    const tokenAmount = amountInUSD / selectedCrypto.priceUSD;
    
    if (tokenAmount < 0.001) return tokenAmount.toFixed(8);
    if (tokenAmount < 1) return tokenAmount.toFixed(6);
    return tokenAmount.toFixed(4);
  };

  const isValidAmount = investAmount && parseFloat(investAmount) >= config.minAmount;
  const isPaymentMethodAvailable = config.paymentMethods.includes(paymentMethod);

  const selectCrypto = (crypto: CryptoData) => {
    setSelectedCrypto(crypto);
    setIsDialogOpen(false);
  };

  const handleBuyClick = () => {
    if (!isValidAmount || !isPaymentMethodAvailable) {
      toast.error('Dados inválidos', {
        description: 'Verifique o valor e método de pagamento',
      });
      return;
    }

    if (paymentMethod === 'paypal') {
      toast.error('PayPal indisponível', {
        description: 'Use PIX ou Cartão de Crédito',
      });
      return;
    }

    // Mostra o checkout do Stripe
    setShowCheckout(true);
  };

  const handlePaymentSuccess = () => {
    toast.success('🎉 Compra realizada com sucesso!', {
      description: `Você receberá ${calculateTokenAmount()} ${selectedCrypto?.symbol} ${informLater ? 'assim que informar seu endereço' : 'em sua carteira em breve'}.`,
      duration: 5000,
    });
    
    // Reseta o formulário
    setInvestAmount('');
    setShowCheckout(false);
    setCustomerEmail('');
    setWalletAddress('');
    setInformLater(false);
  };

  const handlePaymentCancel = () => {
    setShowCheckout(false);
    toast.info('Pagamento cancelado', {
      description: 'Você pode tentar novamente quando quiser.',
    });
  };

  // Se está no checkout, mostra apenas o checkout simplificado
  if (showCheckout && selectedCrypto && isValidAmount) {
    const totalAmount = `${config.symbol}${parseFloat(investAmount).toFixed(2)}`;
    
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-6">
          <Button 
            onClick={() => setShowCheckout(false)}
            variant="outline"
            className="border-gray-700 bg-gray-900/50 hover:bg-gray-800"
          >
            ← Voltar
          </Button>
        </div>
        
        <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl shadow-2xl">
          <CardHeader>
            <h2 className="text-white text-2xl font-bold">
              {paymentMethod === 'pix' ? 'Pagamento via PIX' : 'Pagamento via Cartão de Crédito'}
            </h2>
            <p className="text-gray-400">
              Você está comprando <strong className="text-green-400">{calculateTokenAmount()} {selectedCrypto.symbol}</strong>
            </p>
          </CardHeader>
          <CardContent>
            {paymentMethod === 'pix' ? (
              <PixPayment onConfirm={handlePaymentSuccess} />
            ) : (
              <StripePaymentLink 
                amount={totalAmount}
                currency={currency}
                cryptoSymbol={selectedCrypto.symbol}
                cryptoAmount={calculateTokenAmount()}
                onConfirm={handlePaymentSuccess}
                onCancel={handlePaymentCancel}
              />
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header Premium */}
      <div className="mb-8 text-center">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-green-500 via-emerald-500 to-green-600 flex items-center justify-center shadow-lg shadow-green-500/50 animate-pulse">
            <ShoppingCart className="h-7 w-7 text-white" />
          </div>
          <div className="text-left">
            <h1 className="text-white text-3xl flex items-center gap-2">
              Comprar Criptomoedas
              <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                <Award className="h-3 w-3 mr-1" />
                Premium
              </Badge>
            </h1>
            <p className="text-gray-400 text-sm">500+ criptomoedas • Cotação em tempo real • Taxa zero</p>
          </div>
        </div>
      </div>

      {/* Currency Selector Premium */}
      <div className="mb-6">
        <Select value={currency} onValueChange={(value: any) => setCurrency(value)}>
          <SelectTrigger className="h-14 bg-gradient-to-r from-gray-900/50 to-gray-900/30 border-gray-700 text-white hover:border-green-500/50 transition-colors backdrop-blur-xl">
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-green-500" />
              <SelectValue />
            </div>
          </SelectTrigger>
          <SelectContent className="bg-gray-950 border-gray-700">
            <SelectItem value="BRL" className="text-white">🇧🇷 BRL - Real Brasileiro</SelectItem>
            <SelectItem value="USD" className="text-white">🇺🇸 USD - Dólar Americano</SelectItem>
            <SelectItem value="EUR" className="text-white">🇪🇺 EUR - Euro</SelectItem>
            <SelectItem value="GBP" className="text-white">🇬🇧 GBP - Libra Esterlina</SelectItem>
            <SelectItem value="JPY" className="text-white">🇯🇵 JPY - Iene Japonês</SelectItem>
            <SelectItem value="CNY" className="text-white">🇨🇳 CNY - Yuan Chinês</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Live Ticker - Top 4 Premium */}
      <div className="mb-6">
        <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl overflow-hidden">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-green-500 animate-pulse" />
                <h3 className="text-white font-semibold">Mercado Ao Vivo</h3>
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 animate-pulse">
                <div className="h-2 w-2 bg-green-500 rounded-full mr-2" />
                LIVE
              </Badge>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                cryptoDatabase.find(c => c.symbol === 'BTC'),
                cryptoDatabase.find(c => c.symbol === 'ETH'),
                cryptoDatabase.find(c => c.symbol === 'SOL'),
                cryptoDatabase.find(c => c.symbol === 'XRP')
              ].filter(Boolean).map((crypto) => (
                <button
                  key={crypto!.id}
                  onClick={() => selectCrypto(crypto!)}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    selectedCrypto?.id === crypto!.id
                      ? 'bg-gradient-to-br from-green-500/20 to-emerald-500/20 border-2 border-green-500/50 shadow-lg shadow-green-500/20 scale-105'
                      : 'bg-gray-800/30 border border-gray-700/30 hover:border-green-500/30 hover:scale-102'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-3">
                    <img src={crypto!.logo} alt={crypto!.name} className="h-10 w-10 rounded-full" />
                    <div className="text-left flex-1">
                      <p className="text-white font-bold">{crypto!.symbol}</p>
                      <p className="text-gray-400 text-xs">{crypto!.name}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-white font-mono font-bold text-lg">
                      {config.symbol}{formatPrice(convertPrice(crypto!.priceUSD))}
                    </div>
                    <div className={`flex items-center justify-center gap-1 px-2 py-1 rounded-lg text-sm font-bold ${
                      crypto!.priceChange24h >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                    }`}>
                      {crypto!.priceChange24h >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {crypto!.priceChange24h >= 0 ? '+' : ''}{crypto!.priceChange24h.toFixed(2)}%
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Selected Crypto Card Premium */}
      <Card className="mb-6 bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl shadow-2xl">
        <CardContent className="p-6">
          {selectedCrypto && (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full blur-lg opacity-40 animate-pulse" />
                  <img src={selectedCrypto.logo} alt={selectedCrypto.name} className="h-16 w-16 rounded-full relative z-10 shadow-xl" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-white text-2xl font-bold">{selectedCrypto.name}</h2>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">{selectedCrypto.symbol}</Badge>
                    <Badge variant="outline" className="border-amber-500/50 bg-amber-500/10 text-amber-400 text-xs">
                      Rank #{selectedCrypto.rank}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-white text-xl font-mono font-bold">
                      {config.symbol}{formatPrice(convertPrice(selectedCrypto.priceUSD))}
                    </span>
                    <div className={`flex items-center gap-1 px-3 py-1 rounded-lg ${
                      selectedCrypto.priceChange24h >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                    }`}>
                      {selectedCrypto.priceChange24h >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                      <span className="font-bold">{selectedCrypto.priceChange24h >= 0 ? '+' : ''}{selectedCrypto.priceChange24h.toFixed(2)}%</span>
                    </div>
                  </div>
                </div>
              </div>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 h-12 shadow-lg shadow-green-500/30">
                    <Grid3x3 className="h-5 w-5 mr-2" />
                    Escolher Cripto
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden bg-gray-950 border-gray-800">
                  <DialogHeader>
                    <DialogTitle className="text-white text-2xl">Selecione uma Criptomoeda</DialogTitle>
                    <DialogDescription className="text-gray-400">
                      {cryptoDatabase.length} criptomoedas com cotação em tempo real
                    </DialogDescription>
                  </DialogHeader>
                  
                  {/* Search and Sort */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="relative">
                      <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <Input
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Buscar por nome ou símbolo..."
                        className="pl-12 h-12 bg-gray-900/50 border-gray-700 text-white"
                      />
                    </div>
                    <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                      <SelectTrigger className="h-12 bg-gray-900/50 border-gray-700 text-white">
                        <div className="flex items-center gap-2">
                          <ArrowUpDown className="h-5 w-5 text-green-500" />
                          <SelectValue />
                        </div>
                      </SelectTrigger>
                      <SelectContent className="bg-gray-950 border-gray-700">
                        <SelectItem value="rank" className="text-white">Ordenar por Rank</SelectItem>
                        <SelectItem value="price" className="text-white">Ordenar por Preço</SelectItem>
                        <SelectItem value="change" className="text-white">Ordenar por Variação 24h</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Crypto Grid */}
                  <div className="overflow-y-auto max-h-[60vh] pr-2 custom-scrollbar">
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {filteredAndSortedCryptos.map((crypto) => (
                        <Card
                          key={crypto.id}
                          onClick={() => selectCrypto(crypto)}
                          className="cursor-pointer transition-all duration-200 hover:scale-105 bg-gray-900/50 border-gray-800/50 hover:border-green-500/50 hover:shadow-lg hover:shadow-green-500/20"
                        >
                          <CardContent className="p-4">
                            <div className="flex flex-col items-center text-center space-y-3">
                              <div className="relative">
                                <img src={crypto.logo} alt={crypto.name} className="h-12 w-12 rounded-full" />
                                <div className="absolute -top-1 -right-1 bg-gray-900 rounded-full px-1.5 py-0.5 text-xs text-gray-400 border border-gray-700">
                                  #{crypto.rank}
                                </div>
                              </div>
                              <div className="w-full">
                                <h3 className="text-white font-semibold truncate text-sm mb-1">{crypto.name}</h3>
                                <Badge variant="outline" className="border-gray-600 text-gray-400 text-xs mb-2">
                                  {crypto.symbol}
                                </Badge>
                                <div className="text-white font-mono text-sm mb-2 font-bold">
                                  {config.symbol}{formatPrice(convertPrice(crypto.priceUSD))}
                                </div>
                                <div className={`flex items-center justify-center gap-1 text-xs px-2 py-1 rounded-md font-bold ${
                                  crypto.priceChange24h >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                                }`}>
                                  {crypto.priceChange24h >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                                  <span>{Math.abs(crypto.priceChange24h).toFixed(2)}%</span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Buy Section Premium */}
      {selectedCrypto && (
        <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl shadow-2xl">
          <CardHeader>
            {/* Stats Premium */}
            <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-xl p-6 mb-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-800/50">
                  <div className="flex items-center gap-2 text-gray-400 text-sm mb-2">
                    <DollarSign className="h-4 w-4 text-green-500" />
                    Cap. de Mercado
                  </div>
                  <p className="text-white text-xl font-bold font-mono">
                    {config.symbol}{formatMarketCap(convertPrice(selectedCrypto.marketCap))}
                  </p>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-800/50">
                  <div className="flex items-center gap-2 text-gray-400 text-sm mb-2">
                    <Activity className="h-4 w-4 text-blue-500" />
                    Volume 24h
                  </div>
                  <p className="text-white text-xl font-bold font-mono">
                    {config.symbol}{formatMarketCap(convertPrice(selectedCrypto.volume24h))}
                  </p>
                </div>
              </div>
            </div>

            <Separator className="bg-gray-700/50 my-6" />
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Premium Features */}
            <div className="flex items-center justify-center gap-6 py-4">
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 px-4 py-2">
                <Zap className="h-4 w-4 mr-2" />
                Taxa: 0%
              </Badge>
              <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 px-4 py-2">
                <Award className="h-4 w-4 mr-2" />
                Cashback 2%
              </Badge>
            </div>

            <Alert className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/30">
              <Info className="h-5 w-5 text-amber-400" />
              <AlertDescription className="text-amber-300">
                <p className="font-bold mb-1">Valor Mínimo</p>
                <p className="text-sm">{config.flag} <span className="font-bold">{config.symbol}{config.minAmount.toFixed(2)} {currency}</span> por transação</p>
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-white font-semibold">Valor a Investir</Label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg font-bold">{config.symbol}</span>
                  <Input
                    type="number"
                    placeholder={config.minAmount.toFixed(2)}
                    value={investAmount}
                    onChange={(e) => setInvestAmount(e.target.value)}
                    min={config.minAmount}
                    className={`pl-12 h-14 bg-gray-950/50 text-white text-lg font-bold ${
                      investAmount && parseFloat(investAmount) < config.minAmount ? 'border-red-500' : 'border-gray-700'
                    }`}
                  />
                </div>
                {investAmount && parseFloat(investAmount) < config.minAmount && (
                  <p className="text-red-400 text-xs">Valor mínimo: {config.symbol}{config.minAmount.toFixed(2)}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label className="text-white flex items-center gap-2 font-semibold">
                  <Wallet className="h-4 w-4 text-green-500" />
                  Você Receberá
                </Label>
                <div className="h-14 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-2 border-green-500/50 rounded-lg flex items-center px-4 justify-between shadow-lg shadow-green-500/10">
                  <span className="text-green-400 text-2xl font-bold font-mono">{calculateTokenAmount()}</span>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30 font-bold">{selectedCrypto.symbol}</Badge>
                </div>
                {isValidAmount && (
                  <p className="text-green-400 text-xs flex items-center gap-1 font-semibold">
                    <TrendingUp className="h-3 w-3" />
                    Cotação: {config.symbol}{formatPrice(convertPrice(selectedCrypto.priceUSD))}
                  </p>
                )}
              </div>
            </div>

            {/* Email para recibo */}
            <div className="space-y-2">
              <Label className="text-white font-semibold">E-mail para Recibo (Opcional)</Label>
              <Input
                type="email"
                placeholder="seu@email.com"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                className="h-12 bg-gray-950/50 border-gray-700 text-white"
              />
              <p className="text-gray-400 text-xs">Enviaremos o comprovante e detalhes da transação</p>
            </div>

            {/* Endereço da Carteira */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-white font-semibold flex items-center gap-2">
                  <Wallet className="h-4 w-4 text-green-500" />
                  Endereço da Carteira {selectedCrypto.symbol}
                </Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setInformLater(!informLater)}
                  className={`text-xs ${informLater ? 'text-amber-400' : 'text-gray-400'} hover:text-white`}
                >
                  {informLater ? '✓ Informar depois' : 'Informar depois'}
                </Button>
              </div>

              {!informLater ? (
                <>
                  <Input
                    type="text"
                    placeholder={`Digite seu endereço ${selectedCrypto.symbol}...`}
                    value={walletAddress}
                    onChange={(e) => setWalletAddress(e.target.value)}
                    className="h-12 bg-gray-950/50 border-gray-700 text-white font-mono text-sm"
                  />
                  <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
                    <p className="text-blue-300 text-xs flex items-start gap-2">
                      <Info className="h-4 w-4 flex-shrink-0 mt-0.5" />
                      <span>
                        Envie suas criptomoedas apenas para endereços da rede <strong>{selectedCrypto.symbol}</strong>. 
                        Endereços incorretos podem resultar em perda permanente dos fundos.
                      </span>
                    </p>
                  </div>
                </>
              ) : (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Info className="h-5 w-5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <div className="text-amber-300 text-sm">
                      <p className="font-semibold mb-1">���� Informar Endereço Depois</p>
                      <p className="text-xs text-amber-200/80">
                        Você receberá um e-mail após a compra para informar o endereço da sua carteira. 
                        {customerEmail && ` Enviaremos para: ${customerEmail}`}
                      </p>
                      {!customerEmail && (
                        <p className="text-xs text-amber-400 font-bold mt-2">
                          ⚠️ Recomendamos informar seu e-mail acima para receber as instruções!
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <Label className="text-white font-semibold">Método de Pagamento</Label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {config.paymentMethods.includes('credit') && (
                  <Button 
                    onClick={() => setPaymentMethod('credit')}
                    className={`h-20 transition-all ${
                      paymentMethod === 'credit' ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30 scale-105' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    <div className="text-left w-full">
                      <div className="flex items-center gap-2 mb-1">
                        <CreditCard className="h-5 w-5" />
                        <p className="font-bold">Cartão</p>
                      </div>
                      <p className="text-xs opacity-80">Crédito/Débito</p>
                      <p className="text-xs font-bold mt-1">Min: {config.symbol}{config.minAmount}</p>
                    </div>
                  </Button>
                )}
                
                {config.paymentMethods.includes('pix') && (
                  <Button 
                    onClick={() => setPaymentMethod('pix')}
                    className={`h-20 transition-all ${
                      paymentMethod === 'pix' ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg shadow-green-500/30 scale-105' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    <div className="text-left w-full">
                      <div className="flex items-center gap-2 mb-1">
                        <Smartphone className="h-5 w-5" />
                        <p className="font-bold">PIX 🇧🇷</p>
                      </div>
                      <p className="text-xs opacity-80">Instantâneo</p>
                      <p className="text-xs font-bold mt-1">Min: {config.symbol}{config.minAmount}</p>
                    </div>
                  </Button>
                )}
                
                {config.paymentMethods.includes('paypal') && (
                  <Button 
                    onClick={() => setPaymentMethod('paypal')}
                    className={`h-20 transition-all ${
                      paymentMethod === 'paypal' ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-lg shadow-purple-500/30 scale-105' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    <div className="text-left w-full">
                      <div className="flex items-center gap-2 mb-1">
                        <ExternalLink className="h-5 w-5" />
                        <p className="font-bold">PayPal</p>
                      </div>
                      <p className="text-xs opacity-80">Internacional</p>
                      <p className="text-xs font-bold mt-1">Min: {config.symbol}{config.minAmount}</p>
                    </div>
                  </Button>
                )}
              </div>
            </div>

            <Button 
              onClick={handleBuyClick}
              disabled={!isValidAmount || !isPaymentMethodAvailable}
              className="w-full h-16 bg-gradient-to-r from-green-500 via-emerald-500 to-green-600 hover:from-green-600 hover:via-emerald-600 hover:to-green-700 text-white text-lg font-bold shadow-xl shadow-green-500/40 transition-all duration-300 hover:shadow-2xl hover:shadow-green-500/50 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              {isValidAmount 
                ? `Comprar ${calculateTokenAmount()} ${selectedCrypto.symbol} Agora`
                : `Digite no mínimo ${config.symbol}${config.minAmount}`
              }
            </Button>
            
            {/* Aviso sobre métodos disponíveis */}
            {paymentMethod === 'pix' && (
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 text-center">
                <p className="text-green-400 text-sm font-semibold">💚 PIX: Pagamento instantâneo via Stripe</p>
              </div>
            )}
            {paymentMethod === 'credit' && (
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3 text-center">
                <p className="text-blue-400 text-sm font-semibold">💳 Cartão: Processado com segurança via Stripe</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(31, 41, 55, 0.3);
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(16, 185, 129, 0.5);
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(16, 185, 129, 0.7);
        }
      `}</style>
    </div>
  );
}