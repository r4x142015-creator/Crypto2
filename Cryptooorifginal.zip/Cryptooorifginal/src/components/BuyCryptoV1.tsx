import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Search, ShoppingCart, Info, Globe, DollarSign, Wallet, CreditCard, Smartphone, ExternalLink, Grid3x3, Star, ArrowUpDown, Sparkles, Zap, TrendingDownIcon } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Separator } from './ui/separator';
import { Alert, AlertDescription } from './ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';

interface CryptoData {
  id: string;
  symbol: string;
  name: string;
  logo: string;
  rank: number;
  priceUSD: number;
  priceChange24h: number;
  marketCap: number;
  volume24h: number;
  description: string;
  category: string;
}

const generateFullCryptoDatabase = (): CryptoData[] => {
  const topCryptos: CryptoData[] = [
    { id: 'bitcoin-btc', symbol: 'BTC', name: 'Bitcoin', logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png', rank: 1, priceUSD: 98750.50, priceChange24h: 2.45, marketCap: 1950000000000, volume24h: 45000000000, description: 'Bitcoin é a primeira criptomoeda descentralizada, criada em 2009 por Satoshi Nakamoto. É a maior e mais conhecida criptomoeda do mundo.', category: 'Layer 1' },
    { id: 'ethereum-eth', symbol: 'ETH', name: 'Ethereum', logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.png', rank: 2, priceUSD: 3680.25, priceChange24h: 3.82, marketCap: 442000000000, volume24h: 28000000000, description: 'Ethereum é uma plataforma de blockchain que permite a criação de contratos inteligentes e aplicativos descentralizados (dApps).', category: 'Layer 1' },
    { id: 'solana-sol', symbol: 'SOL', name: 'Solana', logo: 'https://cryptologos.cc/logos/solana-sol-logo.png', rank: 5, priceUSD: 235.60, priceChange24h: 5.23, marketCap: 115000000000, volume24h: 4800000000, description: 'Solana é uma blockchain de alta performance focada em escalabilidade e velocidade.', category: 'Layer 1' },
    { id: 'xrp-ripple', symbol: 'XRP', name: 'XRP', logo: 'https://cryptologos.cc/logos/xrp-xrp-logo.png', rank: 6, priceUSD: 2.45, priceChange24h: 1.12, marketCap: 142000000000, volume24h: 8500000000, description: 'XRP é o token nativo da Ripple, focado em pagamentos transfronteiriços rápidos.', category: 'Payment' },
    { id: 'binance-coin-bnb', symbol: 'BNB', name: 'BNB', logo: 'https://cryptologos.cc/logos/bnb-bnb-logo.png', rank: 4, priceUSD: 692.80, priceChange24h: 1.95, marketCap: 99000000000, volume24h: 2100000000, description: 'BNB é o token nativo da Binance Smart Chain.', category: 'Exchange' },
    { id: 'cardano-ada', symbol: 'ADA', name: 'Cardano', logo: 'https://cryptologos.cc/logos/cardano-ada-logo.png', rank: 8, priceUSD: 1.08, priceChange24h: 2.34, marketCap: 38000000000, volume24h: 1200000000, description: 'Cardano é uma plataforma blockchain de terceira geração.', category: 'Layer 1' },
    { id: 'avalanche-avax', symbol: 'AVAX', name: 'Avalanche', logo: 'https://cryptologos.cc/logos/avalanche-avax-logo.png', rank: 9, priceUSD: 42.80, priceChange24h: 4.12, marketCap: 17000000000, volume24h: 890000000, description: 'Avalanche é uma plataforma de contratos inteligentes.', category: 'Layer 1' },
    { id: 'dogecoin-doge', symbol: 'DOGE', name: 'Dogecoin', logo: 'https://cryptologos.cc/logos/dogecoin-doge-logo.png', rank: 10, priceUSD: 0.38, priceChange24h: 3.45, marketCap: 56000000000, volume24h: 4500000000, description: 'Dogecoin é uma moeda meme popular.', category: 'Meme' },
  ];
  return topCryptos;
};

export default function BuyCryptoV1() {
  const [cryptoDatabase, setCryptoDatabase] = useState<CryptoData[]>([]);
  const [selectedCrypto, setSelectedCrypto] = useState<CryptoData | null>(null);
  const [currency, setCurrency] = useState<'BRL' | 'USD' | 'EUR'>('BRL');
  const [investAmount, setInvestAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'credit' | 'pix' | 'paypal'>('pix');

  useEffect(() => {
    const db = generateFullCryptoDatabase();
    setCryptoDatabase(db);
    setSelectedCrypto(db[0]);

    const interval = setInterval(() => {
      setCryptoDatabase(prevData => 
        prevData.map(crypto => ({
          ...crypto,
          priceUSD: crypto.priceUSD * (1 + (Math.random() - 0.5) * 0.01),
          priceChange24h: parseFloat(((Math.random() - 0.5) * 10).toFixed(2))
        }))
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const currencyConfig = {
    BRL: { symbol: 'R$', rate: 4.95, minAmount: 500 },
    USD: { symbol: '$', rate: 1, minAmount: 500 },
    EUR: { symbol: '€', rate: 0.92, minAmount: 500 }
  };

  const config = currencyConfig[currency];
  const convertPrice = (priceUSD: number) => priceUSD * config.rate;

  const formatPrice = (price: number) => {
    if (price < 0.01) return price.toFixed(8);
    if (price < 1) return price.toFixed(4);
    if (price < 100) return price.toFixed(2);
    return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const calculateTokenAmount = () => {
    if (!selectedCrypto || !investAmount || parseFloat(investAmount) < config.minAmount) {
      return '0.00';
    }
    const amountInUSD = parseFloat(investAmount) / config.rate;
    const tokenAmount = amountInUSD / selectedCrypto.priceUSD;
    if (tokenAmount < 0.001) return tokenAmount.toFixed(8);
    if (tokenAmount < 1) return tokenAmount.toFixed(6);
    return tokenAmount.toFixed(4);
  };

  const isValidAmount = investAmount && parseFloat(investAmount) >= config.minAmount;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Header Bybit Style */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-amber-500 via-orange-500 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/30">
                <Zap className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-white text-2xl">Mercado Spot</h1>
                <p className="text-gray-400 text-sm">Compre cripto com taxa zero</p>
              </div>
            </div>
            <Select value={currency} onValueChange={(value: any) => setCurrency(value)}>
              <SelectTrigger className="w-40 h-10 bg-gray-900/50 border-gray-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-950 border-gray-700">
                <SelectItem value="BRL" className="text-white">🇧🇷 BRL</SelectItem>
                <SelectItem value="USD" className="text-white">🇺🇸 USD</SelectItem>
                <SelectItem value="EUR" className="text-white">🇪🇺 EUR</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Top Gainers Ticker - Bybit Style */}
        <div className="mb-6">
          <div className="bg-gradient-to-r from-gray-900/80 to-gray-900/40 border border-gray-800/50 rounded-xl p-4 backdrop-blur-xl">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-5 w-5 text-amber-500" />
              <h3 className="text-white font-semibold">Top Moedas - Tempo Real</h3>
              <div className="ml-auto flex items-center gap-1.5">
                <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-green-400 text-xs font-semibold">LIVE</span>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {cryptoDatabase.slice(0, 4).map((crypto) => (
                <button
                  key={crypto.id}
                  onClick={() => setSelectedCrypto(crypto)}
                  className={`p-3 rounded-lg transition-all duration-200 ${
                    selectedCrypto?.id === crypto.id
                      ? 'bg-gradient-to-br from-amber-500/20 to-orange-500/20 border-2 border-amber-500/50'
                      : 'bg-gray-800/30 border border-gray-700/30 hover:border-amber-500/30'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <img src={crypto.logo} alt={crypto.name} className="h-8 w-8 rounded-full" />
                    <div className="text-left">
                      <p className="text-white font-semibold text-sm">{crypto.symbol}</p>
                      <p className="text-gray-400 text-xs">{crypto.name}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white font-mono font-bold text-sm">
                      {config.symbol}{formatPrice(convertPrice(crypto.priceUSD))}
                    </span>
                    <div className={`flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold ${
                      crypto.priceChange24h >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                    }`}>
                      {crypto.priceChange24h >= 0 ? '+' : ''}{crypto.priceChange24h.toFixed(2)}%
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Trading Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left - Crypto List */}
          <div className="lg:col-span-1">
            <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl h-full">
              <CardHeader className="pb-3">
                <CardTitle className="text-white text-lg flex items-center gap-2">
                  <Grid3x3 className="h-5 w-5 text-amber-500" />
                  Mercados
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {cryptoDatabase.map((crypto) => (
                  <button
                    key={crypto.id}
                    onClick={() => setSelectedCrypto(crypto)}
                    className={`w-full p-3 rounded-lg transition-all duration-200 ${
                      selectedCrypto?.id === crypto.id
                        ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/50'
                        : 'bg-gray-800/20 hover:bg-gray-800/40 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <img src={crypto.logo} alt={crypto.name} className="h-8 w-8 rounded-full" />
                        <div className="text-left">
                          <p className="text-white font-semibold text-sm">{crypto.symbol}</p>
                          <p className="text-gray-400 text-xs">{crypto.name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-mono text-sm">
                          {config.symbol}{formatPrice(convertPrice(crypto.priceUSD))}
                        </p>
                        <p className={`text-xs font-semibold ${
                          crypto.priceChange24h >= 0 ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {crypto.priceChange24h >= 0 ? '+' : ''}{crypto.priceChange24h.toFixed(2)}%
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Right - Buy Panel */}
          <div className="lg:col-span-2">
            <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50 backdrop-blur-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white text-xl">Comprar {selectedCrypto?.name}</CardTitle>
                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                    Taxa: 0%
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Amount Input */}
                <div className="space-y-2">
                  <Label className="text-white flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-amber-500" />
                    Valor a Investir
                  </Label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg font-semibold">
                      {config.symbol}
                    </span>
                    <Input
                      type="number"
                      placeholder={config.minAmount.toString()}
                      value={investAmount}
                      onChange={(e) => setInvestAmount(e.target.value)}
                      className="pl-12 h-14 bg-gray-950/50 border-gray-700 text-white text-lg"
                    />
                  </div>
                  <p className="text-gray-400 text-xs">Mínimo: {config.symbol}{config.minAmount}</p>
                </div>

                {/* Receive Amount */}
                <div className="space-y-2">
                  <Label className="text-white flex items-center gap-2">
                    <Wallet className="h-4 w-4 text-green-500" />
                    Você Receberá
                  </Label>
                  <div className="h-14 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-2 border-green-500/50 rounded-lg flex items-center px-4 justify-between">
                    <span className="text-green-400 text-2xl font-bold font-mono">
                      {calculateTokenAmount()}
                    </span>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      {selectedCrypto?.symbol}
                    </Badge>
                  </div>
                </div>

                {/* Payment Method */}
                <div className="space-y-3">
                  <Label className="text-white">Método de Pagamento</Label>
                  <div className="grid grid-cols-3 gap-3">
                    <Button
                      onClick={() => setPaymentMethod('pix')}
                      className={`h-16 ${
                        paymentMethod === 'pix'
                          ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white'
                          : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                      }`}
                    >
                      <div>
                        <Smartphone className="h-5 w-5 mx-auto mb-1" />
                        <p className="text-xs font-semibold">PIX</p>
                      </div>
                    </Button>
                    <Button
                      onClick={() => setPaymentMethod('credit')}
                      className={`h-16 ${
                        paymentMethod === 'credit'
                          ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white'
                          : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                      }`}
                    >
                      <div>
                        <CreditCard className="h-5 w-5 mx-auto mb-1" />
                        <p className="text-xs font-semibold">Cartão</p>
                      </div>
                    </Button>
                    <Button
                      onClick={() => setPaymentMethod('paypal')}
                      className={`h-16 ${
                        paymentMethod === 'paypal'
                          ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white'
                          : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                      }`}
                    >
                      <div>
                        <ExternalLink className="h-5 w-5 mx-auto mb-1" />
                        <p className="text-xs font-semibold">PayPal</p>
                      </div>
                    </Button>
                  </div>
                </div>

                {/* Buy Button */}
                <Button
                  disabled={!isValidAmount}
                  className="w-full h-14 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-600 hover:via-orange-600 hover:to-amber-700 text-white text-lg font-bold shadow-lg shadow-amber-500/30 transition-all duration-300 disabled:opacity-50"
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  {isValidAmount
                    ? `Comprar ${calculateTokenAmount()} ${selectedCrypto?.symbol}`
                    : `Mínimo ${config.symbol}${config.minAmount}`}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
