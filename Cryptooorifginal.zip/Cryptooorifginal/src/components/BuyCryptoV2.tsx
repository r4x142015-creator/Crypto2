import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, ShoppingCart, Wallet, CreditCard, Smartphone, ExternalLink, Star, Activity, BarChart3, Flame } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface CryptoData {
  id: string;
  symbol: string;
  name: string;
  logo: string;
  rank: number;
  priceUSD: number;
  priceChange24h: number;
  marketCap: number;
  volume24h: number;
  category: string;
}

const generateCryptoDatabase = (): CryptoData[] => {
  return [
    { id: 'bitcoin-btc', symbol: 'BTC', name: 'Bitcoin', logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png', rank: 1, priceUSD: 98750.50, priceChange24h: 2.45, marketCap: 1950000000000, volume24h: 45000000000, category: 'Layer 1' },
    { id: 'ethereum-eth', symbol: 'ETH', name: 'Ethereum', logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.png', rank: 2, priceUSD: 3680.25, priceChange24h: 3.82, marketCap: 442000000000, volume24h: 28000000000, category: 'Layer 1' },
    { id: 'solana-sol', symbol: 'SOL', name: 'Solana', logo: 'https://cryptologos.cc/logos/solana-sol-logo.png', rank: 5, priceUSD: 235.60, priceChange24h: 5.23, marketCap: 115000000000, volume24h: 4800000000, category: 'Layer 1' },
    { id: 'xrp-ripple', symbol: 'XRP', name: 'XRP', logo: 'https://cryptologos.cc/logos/xrp-xrp-logo.png', rank: 6, priceUSD: 2.45, priceChange24h: 1.12, marketCap: 142000000000, volume24h: 8500000000, category: 'Payment' },
    { id: 'binance-coin-bnb', symbol: 'BNB', name: 'BNB', logo: 'https://cryptologos.cc/logos/bnb-bnb-logo.png', rank: 4, priceUSD: 692.80, priceChange24h: 1.95, marketCap: 99000000000, volume24h: 2100000000, category: 'Exchange' },
    { id: 'cardano-ada', symbol: 'ADA', name: 'Cardano', logo: 'https://cryptologos.cc/logos/cardano-ada-logo.png', rank: 8, priceUSD: 1.08, priceChange24h: 2.34, marketCap: 38000000000, volume24h: 1200000000, category: 'Layer 1' },
  ];
};

export default function BuyCryptoV2() {
  const [cryptoDatabase, setCryptoDatabase] = useState<CryptoData[]>([]);
  const [selectedCrypto, setSelectedCrypto] = useState<CryptoData | null>(null);
  const [investAmount, setInvestAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'credit' | 'paypal'>('pix');
  const [currency] = useState<'BRL'>('BRL');

  useEffect(() => {
    const db = generateCryptoDatabase();
    setCryptoDatabase(db);
    setSelectedCrypto(db[0]);

    const interval = setInterval(() => {
      setCryptoDatabase(prevData => 
        prevData.map(crypto => ({
          ...crypto,
          priceUSD: crypto.priceUSD * (1 + (Math.random() - 0.5) * 0.008),
          priceChange24h: parseFloat(((Math.random() - 0.5) * 10).toFixed(2))
        }))
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const config = { symbol: 'R$', rate: 4.95, minAmount: 500 };
  const convertPrice = (priceUSD: number) => priceUSD * config.rate;

  const formatPrice = (price: number) => {
    if (price < 0.01) return price.toFixed(8);
    if (price < 1) return price.toFixed(4);
    return price.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const calculateTokenAmount = () => {
    if (!selectedCrypto || !investAmount || parseFloat(investAmount) < config.minAmount) {
      return '0.00';
    }
    const amountInUSD = parseFloat(investAmount) / config.rate;
    const tokenAmount = amountInUSD / selectedCrypto.priceUSD;
    if (tokenAmount < 0.001) return tokenAmount.toFixed(8);
    if (tokenAmount < 1) return tokenAmount.toFixed(6);
    return tokenAmount.toFixed(4);
  };

  const isValidAmount = investAmount && parseFloat(investAmount) >= config.minAmount;

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-950 via-gray-950 to-gray-950">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Hero Header - Binance Style */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-yellow-500/20 via-amber-500/20 to-yellow-500/20 border border-yellow-500/30 rounded-2xl p-8 backdrop-blur-xl">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center shadow-lg shadow-yellow-500/50">
                    <Flame className="h-7 w-7 text-white" />
                  </div>
                  <div>
                    <h1 className="text-white text-3xl font-bold">Compre Cripto</h1>
                    <p className="text-yellow-300 text-sm font-semibold">Comece com apenas R$500</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30 px-3 py-1">
                    <Activity className="h-3 w-3 mr-1" />
                    Taxa 0%
                  </Badge>
                  <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 px-3 py-1">
                    <Star className="h-3 w-3 mr-1" />
                    Cashback 2%
                  </Badge>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-yellow-400 text-sm font-semibold">Volume 24h</p>
                  <p className="text-white text-2xl font-bold">R$ 2.4B</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Hot Picks - Cards Style */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Flame className="h-6 w-6 text-orange-500" />
            <h2 className="text-white text-xl font-bold">Populares Hoje</h2>
            <div className="ml-auto flex items-center gap-1.5 bg-green-500/20 px-3 py-1 rounded-full">
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-green-400 text-xs font-bold">TEMPO REAL</span>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {cryptoDatabase.slice(0, 6).map((crypto) => (
              <button
                key={crypto.id}
                onClick={() => setSelectedCrypto(crypto)}
                className={`p-5 rounded-2xl transition-all duration-300 transform hover:scale-105 ${
                  selectedCrypto?.id === crypto.id
                    ? 'bg-gradient-to-br from-yellow-500/30 via-amber-500/20 to-yellow-500/30 border-2 border-yellow-500/50 shadow-lg shadow-yellow-500/20'
                    : 'bg-gray-900/50 border border-gray-800 hover:border-yellow-500/30'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img src={crypto.logo} alt={crypto.name} className="h-12 w-12 rounded-full" />
                      {crypto.rank <= 3 && (
                        <div className="absolute -top-1 -right-1 bg-yellow-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                          {crypto.rank}
                        </div>
                      )}
                    </div>
                    <div className="text-left">
                      <p className="text-white font-bold text-lg">{crypto.symbol}</p>
                      <p className="text-gray-400 text-sm">{crypto.name}</p>
                    </div>
                  </div>
                  <Badge className="bg-gray-800/50 text-gray-300 border-gray-700 text-xs">
                    {crypto.category}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex items-baseline justify-between">
                    <span className="text-gray-400 text-sm">Preço</span>
                    <span className="text-white font-mono font-bold text-lg">
                      {config.symbol} {formatPrice(convertPrice(crypto.priceUSD))}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 text-sm">24h</span>
                    <div className={`flex items-center gap-1 px-3 py-1 rounded-lg font-bold ${
                      crypto.priceChange24h >= 0
                        ? 'bg-green-500/20 text-green-400'
                        : 'bg-red-500/20 text-red-400'
                    }`}>
                      {crypto.priceChange24h >= 0 ? (
                        <TrendingUp className="h-4 w-4" />
                      ) : (
                        <TrendingDown className="h-4 w-4" />
                      )}
                      {crypto.priceChange24h >= 0 ? '+' : ''}
                      {crypto.priceChange24h.toFixed(2)}%
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Buy Panel - Binance Style */}
        {selectedCrypto && (
          <Card className="bg-gradient-to-br from-gray-900/90 to-gray-900/70 border-gray-800 backdrop-blur-xl shadow-2xl">
            <CardHeader className="border-b border-gray-800">
              <div className="flex items-center justify-between">
                <CardTitle className="text-white text-2xl flex items-center gap-3">
                  <img src={selectedCrypto.logo} alt={selectedCrypto.name} className="h-10 w-10 rounded-full" />
                  Comprar {selectedCrypto.name}
                  <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                    {selectedCrypto.symbol}
                  </Badge>
                </CardTitle>
                <div className="text-right">
                  <p className="text-gray-400 text-sm">Preço Atual</p>
                  <p className="text-white font-mono font-bold text-xl">
                    {config.symbol} {formatPrice(convertPrice(selectedCrypto.priceUSD))}
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left Side - Input */}
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label className="text-white text-lg font-semibold">Quanto você quer investir?</Label>
                    <div className="relative">
                      <span className="absolute left-5 top-1/2 transform -translate-y-1/2 text-gray-400 text-xl font-bold">
                        {config.symbol}
                      </span>
                      <Input
                        type="number"
                        placeholder="500.00"
                        value={investAmount}
                        onChange={(e) => setInvestAmount(e.target.value)}
                        className="pl-16 h-16 bg-gray-950/50 border-gray-700 text-white text-2xl font-bold"
                      />
                    </div>
                    <div className="flex gap-2">
                      {[500, 1000, 2000, 5000].map((amount) => (
                        <Button
                          key={amount}
                          onClick={() => setInvestAmount(amount.toString())}
                          variant="outline"
                          className="flex-1 bg-gray-800/50 border-gray-700 text-gray-300 hover:bg-yellow-500/20 hover:text-yellow-400 hover:border-yellow-500/50"
                        >
                          {config.symbol}{amount}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Payment Method */}
                  <div className="space-y-3">
                    <Label className="text-white text-lg font-semibold">Método de Pagamento</Label>
                    <div className="grid grid-cols-3 gap-3">
                      <Button
                        onClick={() => setPaymentMethod('pix')}
                        className={`h-20 flex-col ${
                          paymentMethod === 'pix'
                            ? 'bg-gradient-to-br from-green-500 to-emerald-600 text-white shadow-lg shadow-green-500/30'
                            : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700'
                        }`}
                      >
                        <Smartphone className="h-6 w-6 mb-1" />
                        <span className="text-xs font-bold">PIX</span>
                      </Button>
                      <Button
                        onClick={() => setPaymentMethod('credit')}
                        className={`h-20 flex-col ${
                          paymentMethod === 'credit'
                            ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30'
                            : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700'
                        }`}
                      >
                        <CreditCard className="h-6 w-6 mb-1" />
                        <span className="text-xs font-bold">Cartão</span>
                      </Button>
                      <Button
                        onClick={() => setPaymentMethod('paypal')}
                        className={`h-20 flex-col ${
                          paymentMethod === 'paypal'
                            ? 'bg-gradient-to-br from-purple-500 to-purple-600 text-white shadow-lg shadow-purple-500/30'
                            : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700'
                        }`}
                      >
                        <ExternalLink className="h-6 w-6 mb-1" />
                        <span className="text-xs font-bold">PayPal</span>
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Right Side - Summary */}
                <div className="space-y-6">
                  <div className="bg-gradient-to-br from-yellow-500/10 to-amber-500/10 border border-yellow-500/30 rounded-2xl p-6">
                    <h3 className="text-yellow-400 font-bold text-lg mb-4">Resumo da Compra</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center pb-3 border-b border-gray-700">
                        <span className="text-gray-400">Você paga</span>
                        <span className="text-white font-mono font-bold text-xl">
                          {config.symbol} {investAmount || '0.00'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center pb-3 border-b border-gray-700">
                        <span className="text-gray-400">Taxa de transação</span>
                        <span className="text-green-400 font-bold">R$ 0,00</span>
                      </div>
                      <div className="flex justify-between items-center pb-3 border-b border-gray-700">
                        <span className="text-gray-400">Você recebe</span>
                        <div className="text-right">
                          <span className="text-green-400 font-mono font-bold text-2xl block">
                            {calculateTokenAmount()}
                          </span>
                          <span className="text-gray-500 text-sm">{selectedCrypto.symbol}</span>
                        </div>
                      </div>
                      {isValidAmount && (
                        <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
                          <p className="text-green-400 text-sm font-semibold flex items-center gap-2">
                            <Star className="h-4 w-4" />
                            Você ganhará R$ {(parseFloat(investAmount) * 0.02).toFixed(2)} de cashback!
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <Button
                    disabled={!isValidAmount}
                    className="w-full h-16 bg-gradient-to-r from-yellow-400 via-amber-500 to-yellow-500 hover:from-yellow-500 hover:via-amber-600 hover:to-yellow-600 text-gray-900 text-xl font-bold shadow-xl shadow-yellow-500/40 transition-all duration-300 disabled:opacity-50"
                  >
                    <ShoppingCart className="h-6 w-6 mr-2" />
                    {isValidAmount ? 'Comprar Agora' : 'Digite um valor válido'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
