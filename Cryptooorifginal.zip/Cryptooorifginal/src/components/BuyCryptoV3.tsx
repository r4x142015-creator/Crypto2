import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, ShoppingCart, Wallet, CreditCard, Smartphone, ExternalLink, Zap, Clock, Shield, Award, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface CryptoData {
  id: string;
  symbol: string;
  name: string;
  logo: string;
  rank: number;
  priceUSD: number;
  priceChange24h: number;
  marketCap: number;
  volume24h: number;
  category: string;
}

const generateCryptoDatabase = (): CryptoData[] => {
  return [
    { id: 'bitcoin-btc', symbol: 'BTC', name: 'Bitcoin', logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png', rank: 1, priceUSD: 98750.50, priceChange24h: 2.45, marketCap: 1950000000000, volume24h: 45000000000, category: 'Layer 1' },
    { id: 'ethereum-eth', symbol: 'ETH', name: 'Ethereum', logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.png', rank: 2, priceUSD: 3680.25, priceChange24h: 3.82, marketCap: 442000000000, volume24h: 28000000000, category: 'Layer 1' },
    { id: 'solana-sol', symbol: 'SOL', name: 'Solana', logo: 'https://cryptologos.cc/logos/solana-sol-logo.png', rank: 5, priceUSD: 235.60, priceChange24h: 5.23, marketCap: 115000000000, volume24h: 4800000000, category: 'Layer 1' },
    { id: 'xrp-ripple', symbol: 'XRP', name: 'XRP', logo: 'https://cryptologos.cc/logos/xrp-xrp-logo.png', rank: 6, priceUSD: 2.45, priceChange24h: 1.12, marketCap: 142000000000, volume24h: 8500000000, category: 'Payment' },
    { id: 'binance-coin-bnb', symbol: 'BNB', name: 'BNB', logo: 'https://cryptologos.cc/logos/bnb-bnb-logo.png', rank: 4, priceUSD: 692.80, priceChange24h: 1.95, marketCap: 99000000000, volume24h: 2100000000, category: 'Exchange' },
    { id: 'cardano-ada', symbol: 'ADA', name: 'Cardano', logo: 'https://cryptologos.cc/logos/cardano-ada-logo.png', rank: 8, priceUSD: 1.08, priceChange24h: 2.34, marketCap: 38000000000, volume24h: 1200000000, category: 'Layer 1' },
    { id: 'avalanche-avax', symbol: 'AVAX', name: 'Avalanche', logo: 'https://cryptologos.cc/logos/avalanche-avax-logo.png', rank: 9, priceUSD: 42.80, priceChange24h: 4.12, marketCap: 17000000000, volume24h: 890000000, category: 'Layer 1' },
    { id: 'dogecoin-doge', symbol: 'DOGE', name: 'Dogecoin', logo: 'https://cryptologos.cc/logos/dogecoin-doge-logo.png', rank: 10, priceUSD: 0.38, priceChange24h: 3.45, marketCap: 56000000000, volume24h: 4500000000, category: 'Meme' },
  ];
};

export default function BuyCryptoV3() {
  const [cryptoDatabase, setCryptoDatabase] = useState<CryptoData[]>([]);
  const [selectedCrypto, setSelectedCrypto] = useState<CryptoData | null>(null);
  const [investAmount, setInvestAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'credit' | 'paypal'>('pix');
  const [activeTab, setActiveTab] = useState<string>('all');

  useEffect(() => {
    const db = generateCryptoDatabase();
    setCryptoDatabase(db);
    setSelectedCrypto(db[0]);

    const interval = setInterval(() => {
      setCryptoDatabase(prevData => 
        prevData.map(crypto => ({
          ...crypto,
          priceUSD: crypto.priceUSD * (1 + (Math.random() - 0.5) * 0.008),
          priceChange24h: parseFloat(((Math.random() - 0.5) * 10).toFixed(2))
        }))
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const config = { symbol: 'R$', rate: 4.95, minAmount: 500 };
  const convertPrice = (priceUSD: number) => priceUSD * config.rate;

  const formatPrice = (price: number) => {
    if (price < 0.01) return price.toFixed(8);
    if (price < 1) return price.toFixed(4);
    return price.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const formatMarketCap = (value: number) => {
    if (value >= 1000000000) return `${(value / 1000000000).toFixed(1)}B`;
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    return value.toString();
  };

  const calculateTokenAmount = () => {
    if (!selectedCrypto || !investAmount || parseFloat(investAmount) < config.minAmount) {
      return '0.00';
    }
    const amountInUSD = parseFloat(investAmount) / config.rate;
    const tokenAmount = amountInUSD / selectedCrypto.priceUSD;
    if (tokenAmount < 0.001) return tokenAmount.toFixed(8);
    if (tokenAmount < 1) return tokenAmount.toFixed(6);
    return tokenAmount.toFixed(4);
  };

  const isValidAmount = investAmount && parseFloat(investAmount) >= config.minAmount;

  const filteredCryptos = activeTab === 'all' 
    ? cryptoDatabase 
    : cryptoDatabase.filter(c => c.category === activeTab);

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900 via-gray-950 to-black">
      <div className="container mx-auto px-4 py-6 max-w-[1600px]">
        {/* Premium Header */}
        <div className="mb-8">
          <div className="relative overflow-hidden bg-gradient-to-r from-purple-600/20 via-pink-600/20 to-purple-600/20 border border-purple-500/30 rounded-3xl p-8 backdrop-blur-2xl">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnoiIHN0cm9rZT0iIzhmNWNhZiIgc3Ryb2tlLXdpZHRoPSIyIiBvcGFjaXR5PSIuMSIvPjwvZz48L3N2Zz4=')] opacity-20"></div>
            <div className="relative flex items-center justify-between flex-wrap gap-6">
              <div>
                <div className="flex items-center gap-4 mb-4">
                  <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-purple-500 via-pink-500 to-purple-600 flex items-center justify-center shadow-2xl shadow-purple-500/50 animate-pulse">
                    <Zap className="h-8 w-8 text-white" />
                  </div>
                  <div>
                    <h1 className="text-white text-4xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
                      CryptoSell Premium
                    </h1>
                    <p className="text-purple-300 font-semibold">Investimento inteligente em cripto</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30 px-4 py-2">
                    <Shield className="h-4 w-4 mr-2" />
                    Protegido SSL
                  </Badge>
                  <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 px-4 py-2">
                    <Clock className="h-4 w-4 mr-2" />
                    24/7 Suporte
                  </Badge>
                  <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 px-4 py-2">
                    <Award className="h-4 w-4 mr-2" />
                    Cashback 3%
                  </Badge>
                </div>
              </div>
              <div className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 border border-purple-500/30 rounded-2xl p-6 backdrop-blur-xl">
                <p className="text-purple-300 text-sm mb-1">Volume Total 24h</p>
                <p className="text-white text-3xl font-bold">R$ 8.7 Bilhões</p>
                <p className="text-green-400 text-sm font-semibold mt-1">↑ +12.4% hoje</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Left Panel - Crypto Selection */}
          <div className="xl:col-span-1 space-y-6">
            {/* Live Ticker */}
            <Card className="bg-gradient-to-br from-gray-900/90 to-gray-900/70 border-purple-500/20 backdrop-blur-xl overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white text-lg font-bold flex items-center gap-2">
                    <div className="h-2 w-2 bg-red-500 rounded-full animate-pulse" />
                    Mercado Ao Vivo
                  </CardTitle>
                  <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 text-xs">
                    Tempo Real
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-2 max-h-[600px] overflow-y-auto custom-scrollbar">
                {filteredCryptos.map((crypto, index) => (
                  <button
                    key={crypto.id}
                    onClick={() => setSelectedCrypto(crypto)}
                    className={`w-full p-4 rounded-xl transition-all duration-300 group ${
                      selectedCrypto?.id === crypto.id
                        ? 'bg-gradient-to-r from-purple-600/30 via-pink-600/30 to-purple-600/30 border-2 border-purple-500/50 shadow-lg shadow-purple-500/20'
                        : 'bg-gray-800/30 hover:bg-gray-800/50 border border-gray-700/30 hover:border-purple-500/30'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <img 
                            src={crypto.logo} 
                            alt={crypto.name} 
                            className="h-10 w-10 rounded-full ring-2 ring-purple-500/20" 
                          />
                          {index < 3 && (
                            <div className="absolute -top-1 -right-1 bg-gradient-to-br from-amber-400 to-orange-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center shadow-lg">
                              {index + 1}
                            </div>
                          )}
                        </div>
                        <div className="text-left">
                          <p className="text-white font-bold">{crypto.symbol}</p>
                          <p className="text-gray-400 text-xs">{crypto.name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-mono text-sm font-semibold">
                          {config.symbol}{formatPrice(convertPrice(crypto.priceUSD))}
                        </p>
                        <div className={`text-xs font-bold ${
                          crypto.priceChange24h >= 0 ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {crypto.priceChange24h >= 0 ? '↑' : '↓'} {Math.abs(crypto.priceChange24h).toFixed(2)}%
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Buy Interface */}
          <div className="xl:col-span-2">
            {selectedCrypto && (
              <Card className="bg-gradient-to-br from-gray-900/90 to-gray-900/70 border-purple-500/20 backdrop-blur-xl shadow-2xl">
                <CardHeader className="border-b border-gray-800/50 pb-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <img 
                        src={selectedCrypto.logo} 
                        alt={selectedCrypto.name} 
                        className="h-14 w-14 rounded-full ring-4 ring-purple-500/30" 
                      />
                      <div>
                        <CardTitle className="text-white text-2xl font-bold mb-1">
                          {selectedCrypto.name}
                        </CardTitle>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                            {selectedCrypto.symbol}
                          </Badge>
                          <Badge variant="outline" className="border-gray-600 text-gray-400 text-xs">
                            Rank #{selectedCrypto.rank}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-purple-300 text-sm mb-1">Preço Atual</p>
                      <p className="text-white font-mono font-bold text-3xl">
                        {config.symbol} {formatPrice(convertPrice(selectedCrypto.priceUSD))}
                      </p>
                      <div className={`flex items-center justify-end gap-1 mt-1 font-bold ${
                        selectedCrypto.priceChange24h >= 0 ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {selectedCrypto.priceChange24h >= 0 ? (
                          <TrendingUp className="h-4 w-4" />
                        ) : (
                          <TrendingDown className="h-4 w-4" />
                        )}
                        {selectedCrypto.priceChange24h >= 0 ? '+' : ''}
                        {selectedCrypto.priceChange24h.toFixed(2)}% (24h)
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-8 space-y-8">
                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-xl p-4">
                      <p className="text-purple-300 text-sm mb-1">Market Cap</p>
                      <p className="text-white font-bold text-xl">
                        {config.symbol} {formatMarketCap(convertPrice(selectedCrypto.marketCap))}
                      </p>
                    </div>
                    <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/30 rounded-xl p-4">
                      <p className="text-blue-300 text-sm mb-1">Volume 24h</p>
                      <p className="text-white font-bold text-xl">
                        {config.symbol} {formatMarketCap(convertPrice(selectedCrypto.volume24h))}
                      </p>
                    </div>
                  </div>

                  {/* Amount Input */}
                  <div className="space-y-4">
                    <Label className="text-white text-lg font-bold">Quanto deseja investir?</Label>
                    <div className="relative">
                      <span className="absolute left-6 top-1/2 transform -translate-y-1/2 text-gray-400 text-2xl font-bold">
                        {config.symbol}
                      </span>
                      <Input
                        type="number"
                        placeholder="500.00"
                        value={investAmount}
                        onChange={(e) => setInvestAmount(e.target.value)}
                        className="pl-20 h-20 bg-gray-950/50 border-2 border-purple-500/30 focus:border-purple-500 text-white text-3xl font-bold rounded-2xl"
                      />
                    </div>
                    <div className="grid grid-cols-4 gap-3">
                      {[500, 1000, 2500, 5000].map((amount) => (
                        <Button
                          key={amount}
                          onClick={() => setInvestAmount(amount.toString())}
                          variant="outline"
                          className="bg-gray-800/50 border-gray-700 text-gray-300 hover:bg-purple-500/20 hover:text-purple-400 hover:border-purple-500/50 h-12 font-bold"
                        >
                          {config.symbol}{amount}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Receive Display */}
                  <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-2 border-green-500/30 rounded-2xl p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-green-300 text-sm mb-2 flex items-center gap-2">
                          <Wallet className="h-5 w-5" />
                          Você Receberá
                        </Label>
                        <p className="text-green-400 font-mono font-bold text-4xl">
                          {calculateTokenAmount()}
                        </p>
                        <p className="text-green-300/70 text-sm mt-1">{selectedCrypto.symbol}</p>
                      </div>
                      <ChevronRight className="h-8 w-8 text-green-400" />
                    </div>
                  </div>

                  {/* Payment Method */}
                  <div className="space-y-4">
                    <Label className="text-white text-lg font-bold">Método de Pagamento</Label>
                    <div className="grid grid-cols-3 gap-4">
                      <Button
                        onClick={() => setPaymentMethod('pix')}
                        className={`h-24 flex-col justify-center ${
                          paymentMethod === 'pix'
                            ? 'bg-gradient-to-br from-green-500 to-emerald-600 text-white shadow-xl shadow-green-500/30 scale-105'
                            : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700 border border-gray-700'
                        }`}
                      >
                        <Smartphone className="h-8 w-8 mb-2" />
                        <span className="font-bold">PIX</span>
                        <span className="text-xs opacity-80">Instantâneo</span>
                      </Button>
                      <Button
                        onClick={() => setPaymentMethod('credit')}
                        className={`h-24 flex-col justify-center ${
                          paymentMethod === 'credit'
                            ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-xl shadow-blue-500/30 scale-105'
                            : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700 border border-gray-700'
                        }`}
                      >
                        <CreditCard className="h-8 w-8 mb-2" />
                        <span className="font-bold">Cartão</span>
                        <span className="text-xs opacity-80">Crédito/Débito</span>
                      </Button>
                      <Button
                        onClick={() => setPaymentMethod('paypal')}
                        className={`h-24 flex-col justify-center ${
                          paymentMethod === 'paypal'
                            ? 'bg-gradient-to-br from-purple-500 to-purple-600 text-white shadow-xl shadow-purple-500/30 scale-105'
                            : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700 border border-gray-700'
                        }`}
                      >
                        <ExternalLink className="h-8 w-8 mb-2" />
                        <span className="font-bold">PayPal</span>
                        <span className="text-xs opacity-80">Internacional</span>
                      </Button>
                    </div>
                  </div>

                  {/* Buy Button */}
                  <Button
                    disabled={!isValidAmount}
                    className="w-full h-20 bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 hover:from-purple-700 hover:via-pink-700 hover:to-purple-700 text-white text-xl font-bold shadow-2xl shadow-purple-500/50 transition-all duration-300 disabled:opacity-50 disabled:shadow-none rounded-2xl"
                  >
                    <ShoppingCart className="h-6 w-6 mr-3" />
                    {isValidAmount ? `Comprar ${selectedCrypto.symbol} Agora` : `Mínimo ${config.symbol}${config.minAmount}`}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(31, 41, 55, 0.3);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(168, 85, 247, 0.5);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(168, 85, 247, 0.7);
        }
      `}</style>
    </div>
  );
}
