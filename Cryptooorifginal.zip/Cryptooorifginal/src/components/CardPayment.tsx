import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { CreditCard, Lock, ArrowLeft, Shield, CheckCircle2, AlertCircle } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || 'pk_test_placeholder');

interface CardPaymentProps {
  amount: string;
  onBack: () => void;
  onSuccess: () => void;
}

function CardPaymentForm({ amount, onBack, onSuccess }: CardPaymentProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string>('');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!stripe || !elements) {
      return;
    }

    setProcessing(true);
    setError('');

    try {
      const cardElement = elements.getElement(CardElement);
      
      if (!cardElement) {
        throw new Error('Card element not found');
      }

      // Criar Payment Method
      const { error: pmError, paymentMethod } = await stripe.createPaymentMethod({
        type: 'card',
        card: cardElement,
        billing_details: {
          name: name,
          email: email,
        },
      });

      if (pmError) {
        throw new Error(pmError.message);
      }

      // Aqui você faria a chamada para seu backend para criar o Payment Intent
      // Por enquanto, simulamos sucesso
      console.log('Payment Method criado:', paymentMethod.id);
      
      // Simular processamento
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Erro ao processar pagamento');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          onClick={onBack}
          variant="outline"
          className="h-10 w-10 p-0 border-gray-700 bg-gray-900/50 hover:bg-gray-800"
          disabled={processing}
        >
          <ArrowLeft className="h-5 w-5 text-gray-400" />
        </Button>
        <div>
          <h2 className="text-white text-2xl font-bold">Pagamento com Cartão</h2>
          <p className="text-gray-400 text-sm">Processado de forma segura pelo Stripe</p>
        </div>
      </div>

      {/* Valor a pagar */}
      <Card className="border-2 border-blue-500/40 bg-gradient-to-br from-blue-500/10 to-indigo-500/10">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-200/70 text-sm mb-1">Valor a pagar</p>
              <p className="text-white text-3xl font-bold">{amount}</p>
            </div>
            <div className="h-16 w-16 rounded-full bg-blue-500/20 flex items-center justify-center">
              <CreditCard className="h-8 w-8 text-blue-400" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Formulário de Pagamento */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <Card className="border-gray-700 bg-gray-900/50">
          <CardContent className="p-6 space-y-5">
            {/* Nome */}
            <div className="space-y-2">
              <Label htmlFor="name" className="text-white">
                Nome no Cartão
              </Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="João da Silva"
                required
                className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50"
                disabled={processing}
              />
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">
                E-mail
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu-email@exemplo.com"
                required
                className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50"
                disabled={processing}
              />
            </div>

            {/* Dados do Cartão */}
            <div className="space-y-2">
              <Label className="text-white flex items-center gap-2">
                <CreditCard className="h-4 w-4 text-blue-400" />
                Dados do Cartão
              </Label>
              <div className="bg-gray-950/80 border-2 border-gray-700 rounded-lg p-4 hover:border-blue-500/50 transition-colors">
                <CardElement
                  options={{
                    style: {
                      base: {
                        fontSize: '16px',
                        color: '#ffffff',
                        '::placeholder': {
                          color: '#6b7280',
                        },
                      },
                      invalid: {
                        color: '#ef4444',
                      },
                    },
                  }}
                />
              </div>
              <p className="text-xs text-gray-400 flex items-center gap-2">
                <Lock className="h-3 w-3" />
                Seus dados estão protegidos com criptografia SSL 256-bit
              </p>
            </div>

            {/* Bandeiras Aceitas */}
            <div className="flex items-center justify-center gap-3 pt-2">
              <Badge variant="outline" className="border-gray-600 text-gray-400 text-xs">
                Visa
              </Badge>
              <Badge variant="outline" className="border-gray-600 text-gray-400 text-xs">
                Mastercard
              </Badge>
              <Badge variant="outline" className="border-gray-600 text-gray-400 text-xs">
                Amex
              </Badge>
              <Badge variant="outline" className="border-gray-600 text-gray-400 text-xs">
                Discover
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Erro */}
        {error && (
          <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl animate-in fade-in">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-300 font-semibold text-sm">Erro no pagamento</p>
                <p className="text-red-200/80 text-xs mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Botão de Pagamento */}
        <Button
          type="submit"
          disabled={!stripe || processing || !name || !email}
          className="w-full h-14 bg-gradient-to-r from-blue-500 via-indigo-500 to-blue-600 hover:from-blue-600 hover:via-indigo-600 hover:to-blue-700 text-white shadow-lg shadow-blue-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-blue-500/40 hover:scale-[1.02] disabled:opacity-50"
        >
          {processing ? (
            <>
              <div className="h-5 w-5 mr-2 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Processando...
            </>
          ) : (
            <>
              <Lock className="h-5 w-5 mr-2" />
              Pagar {amount}
            </>
          )}
        </Button>

        <div className="flex items-center justify-center gap-2 text-xs text-gray-400">
          <Shield className="h-3 w-3" />
          <span>Processado de forma segura pelo Stripe</span>
        </div>
      </form>

      {/* Informações de Segurança */}
      <Card className="border-blue-500/30 bg-gradient-to-br from-blue-500/5 to-indigo-500/5">
        <CardContent className="p-5">
          <div className="flex items-start gap-3">
            <Shield className="h-5 w-5 text-blue-400 flex-shrink-0 mt-0.5" />
            <div className="space-y-2 flex-1">
              <p className="text-white font-semibold">🔒 Pagamento 100% Seguro</p>
              <ul className="text-sm text-blue-200/80 space-y-1 list-disc list-inside">
                <li>Criptografia SSL 256-bit</li>
                <li>Certificação PCI DSS Level 1</li>
                <li>Dados nunca armazenados em nossos servidores</li>
                <li>Processamento instantâneo e seguro</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Políticas */}
      <div className="p-4 bg-gray-900/50 border border-gray-700 rounded-xl">
        <div className="text-xs text-gray-400 space-y-2">
          <div className="flex items-center justify-between">
            <span>Taxa de processamento:</span>
            <span className="text-white font-semibold">2.9% + $0.30</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Parcelamento:</span>
            <span className="text-white font-semibold">Até 12x sem juros</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Estorno:</span>
            <span className="text-white font-semibold">Até 7 dias</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CardPayment(props: CardPaymentProps) {
  return (
    <Elements stripe={stripePromise}>
      <CardPaymentForm {...props} />
    </Elements>
  );
}
