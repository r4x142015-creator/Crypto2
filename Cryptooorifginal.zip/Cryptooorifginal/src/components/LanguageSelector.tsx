import { useState } from 'react';
import { Globe, Check, Search } from 'lucide-react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { languages } from '../utils/i18n/languages';

interface LanguageSelectorProps {
  currentLang: string;
  onLanguageChange: (lang: string) => void;
}

export default function LanguageSelector({ currentLang, onLanguageChange }: LanguageSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const currentLanguage = languages[currentLang] || languages.en;

  // Filtrar idiomas pela busca
  const filteredLanguages = Object.entries(languages).filter(([code, lang]) =>
    lang.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Organizar idiomas por região
  const languagesByRegion = {
    'Popular': ['en', 'pt-br', 'es', 'fr', 'de', 'zh', 'ja', 'ru', 'ar', 'hi'],
    'Europe': ['en', 'es', 'pt', 'fr', 'de', 'it', 'nl', 'sv', 'no', 'da', 'fi', 'pl', 'cs', 'ru', 'uk', 'ro', 'hu', 'el', 'tr'],
    'Americas': ['en-us', 'pt-br', 'es-mx', 'es-ar', 'es-co', 'es-cl', 'en-ca', 'fr-ca'],
    'Asia': ['zh', 'ja', 'ko', 'hi', 'th', 'vi', 'id', 'ms', 'tl', 'bn', 'ur', 'ar', 'fa', 'he'],
    'Africa': ['sw', 'ar', 'fr', 'en', 'af', 'am'],
    'Oceania': ['en-au', 'en-nz']
  };

  const handleLanguageSelect = (langCode: string) => {
    onLanguageChange(langCode);
    setIsOpen(false);
    setSearchTerm('');
  };

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        variant="ghost"
        size="sm"
        className="text-gray-400 hover:text-white hover:bg-gray-800/50 transition-all flex items-center gap-2"
      >
        <span className="text-xl">{currentLanguage.flag}</span>
        <Globe className="h-4 w-4" />
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[85vh] overflow-hidden bg-gradient-to-br from-gray-900/95 to-gray-950/95 border-amber-500/20 backdrop-blur-xl">
          <DialogHeader>
            <div className="flex items-center justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full blur-xl opacity-50 animate-pulse" />
                <div className="h-16 w-16 rounded-xl bg-gradient-to-br from-blue-500 via-purple-500 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/50 relative z-10">
                  <Globe className="h-8 w-8 text-white" />
                </div>
              </div>
            </div>
            <DialogTitle className="text-center text-white text-3xl mb-2">
              Select Language / Selecionar Idioma
            </DialogTitle>
            <DialogDescription className="text-center text-blue-400/80">
              150+ languages • Automatic currency conversion
            </DialogDescription>
          </DialogHeader>

          {/* Busca */}
          <div className="space-y-2 mt-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search language / Buscar idioma..."
                className="pl-10 bg-gray-950/50 border-gray-700 text-white h-12 hover:border-blue-500/50 transition-colors"
              />
            </div>
          </div>

          {/* Idioma Atual */}
          <div className="p-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/30 rounded-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{currentLanguage.flag}</span>
                <div>
                  <p className="text-white font-semibold">{currentLanguage.name}</p>
                  <p className="text-xs text-gray-400">
                    {currentLanguage.currency} ({currentLanguage.symbol})
                  </p>
                </div>
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                <Check className="h-3 w-3 mr-1" />
                Current
              </Badge>
            </div>
          </div>

          {/* Lista de Idiomas */}
          <ScrollArea className="h-[400px] pr-4">
            {searchTerm ? (
              // Resultados da busca
              <div className="space-y-2">
                <p className="text-gray-400 text-sm mb-3">
                  {filteredLanguages.length} results
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {filteredLanguages.map(([code, lang]) => (
                    <button
                      key={code}
                      onClick={() => handleLanguageSelect(code)}
                      className={`flex items-center gap-3 p-3 rounded-lg border transition-all hover:scale-[1.02] ${
                        currentLang === code
                          ? 'bg-blue-500/20 border-blue-500/50'
                          : 'bg-gray-800/30 border-gray-700/50 hover:bg-gray-800/50 hover:border-blue-500/30'
                      }`}
                    >
                      <span className="text-2xl">{lang.flag}</span>
                      <div className="flex-1 text-left">
                        <p className="text-white text-sm font-medium">{lang.name}</p>
                        <p className="text-xs text-gray-400">
                          {lang.currency} {lang.symbol}
                        </p>
                      </div>
                      {currentLang === code && (
                        <Check className="h-4 w-4 text-blue-400" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              // Idiomas por região
              <div className="space-y-6">
                {Object.entries(languagesByRegion).map(([region, langCodes]) => (
                  <div key={region}>
                    <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                      <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-700 to-transparent" />
                      <span>{region}</span>
                      <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-700 to-transparent" />
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {langCodes
                        .filter(code => languages[code])
                        .map((code) => {
                          const lang = languages[code];
                          return (
                            <button
                              key={code}
                              onClick={() => handleLanguageSelect(code)}
                              className={`flex items-center gap-3 p-3 rounded-lg border transition-all hover:scale-[1.02] ${
                                currentLang === code
                                  ? 'bg-blue-500/20 border-blue-500/50'
                                  : 'bg-gray-800/30 border-gray-700/50 hover:bg-gray-800/50 hover:border-blue-500/30'
                              }`}
                            >
                              <span className="text-2xl">{lang.flag}</span>
                              <div className="flex-1 text-left">
                                <p className="text-white text-sm font-medium">{lang.name}</p>
                                <p className="text-xs text-gray-400">
                                  {lang.currency} {lang.symbol}
                                </p>
                              </div>
                              {currentLang === code && (
                                <Check className="h-4 w-4 text-blue-400" />
                              )}
                            </button>
                          );
                        })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Info */}
          <div className="mt-4 p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg">
            <p className="text-xs text-purple-300 text-center">
              ✨ Currency will automatically change based on your selected language
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
