import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Copy, CheckCircle2, QrCode, AlertCircle, Shield } from 'lucide-react';
import QRCodeGenerator from './QRCodeGenerator';

interface PixPaymentProps {
  amount?: string;
  onConfirm?: () => void;
}

export default function PixPayment({ amount, onConfirm }: PixPaymentProps) {
  const PIX_KEY = '43a285fe-298c-4e4f-95a9-6d1521dea290';
  const [copied, setCopied] = useState(false);

  const copyPixKey = async () => {
    try {
      // Tenta usar a Clipboard API moderna
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(PIX_KEY);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } else {
        // Fallback: método antigo que funciona sem permissões
        const textArea = document.createElement('textarea');
        textArea.value = PIX_KEY;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
          document.execCommand('copy');
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        } catch (err) {
          console.error('Erro ao copiar:', err);
          alert('Não foi possível copiar. Por favor, copie manualmente: ' + PIX_KEY);
        } finally {
          document.body.removeChild(textArea);
        }
      }
    } catch (err) {
      console.error('Erro ao copiar:', err);
      // Fallback final: método manual
      const textArea = document.createElement('textarea');
      textArea.value = PIX_KEY;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      
      try {
        document.execCommand('copy');
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (fallbackErr) {
        console.error('Fallback também falhou:', fallbackErr);
        alert('Não foi possível copiar automaticamente. Por favor, copie manualmente:\n\n' + PIX_KEY);
      } finally {
        document.body.removeChild(textArea);
      }
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* QR Code e Chave PIX */}
      <Card className="border-gray-700 bg-gray-900/50">
        <CardContent className="p-6 space-y-6">
          {/* QR Code */}
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className="bg-white p-6 rounded-2xl shadow-2xl">
                <QRCodeGenerator value={PIX_KEY} size={240} />
              </div>
            </div>
            <p className="text-center text-gray-400 text-sm">
              Escaneie o QR Code com o app do seu banco
            </p>
          </div>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-700"></div>
            </div>
            <div className="relative flex justify-center">
              <span className="bg-gray-900/50 px-4 text-sm text-gray-400">OU</span>
            </div>
          </div>

          {/* Chave PIX */}
          <div className="space-y-3">
            <Label className="text-white text-center block">
              Copie a chave PIX
            </Label>

            <div className="bg-gray-950/80 border-2 border-teal-500/30 rounded-xl p-4">
              <div className="flex items-center justify-between gap-3">
                <code className="text-teal-400 font-mono text-sm break-all flex-1">
                  {PIX_KEY}
                </code>
                <button
                  onClick={copyPixKey}
                  className="flex-shrink-0 h-12 w-12 rounded-lg bg-teal-500/20 border border-teal-500/40 hover:bg-teal-500/30 transition-all duration-300 flex items-center justify-center group"
                >
                  {copied ? (
                    <CheckCircle2 className="h-6 w-6 text-teal-400" />
                  ) : (
                    <Copy className="h-6 w-6 text-teal-400 group-hover:scale-110 transition-transform" />
                  )}
                </button>
              </div>
              {copied && (
                <p className="text-xs text-teal-400 mt-3 text-center animate-in fade-in">
                  ✓ Chave copiada! Cole no app do seu banco
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Instruções Simples */}
      <Card className="border-teal-500/30 bg-gradient-to-br from-teal-500/5 to-cyan-500/5">
        <CardContent className="p-5">
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-full bg-teal-500/20 flex items-center justify-center flex-shrink-0">
              <AlertCircle className="h-4 w-4 text-teal-400" />
            </div>
            <div className="space-y-2 flex-1">
              <p className="text-white font-semibold">📱 Como pagar:</p>
              <ol className="text-sm text-teal-200/80 space-y-2 list-decimal list-inside">
                <li>Abra o app do seu banco</li>
                <li><strong className="text-teal-300">Escaneie o QR Code</strong> acima OU <strong className="text-teal-300">copie a chave</strong></li>
                <li>Confirme o pagamento</li>
                <li>Pronto! Aguarde a confirmação</li>
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>

      {onConfirm && (
        <Button
          onClick={onConfirm}
          className="w-full h-14 bg-gradient-to-r from-teal-500 via-emerald-500 to-teal-600 hover:from-teal-600 hover:via-emerald-600 hover:to-teal-700 text-white shadow-lg shadow-teal-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-teal-500/40 hover:scale-[1.02]"
        >
          <CheckCircle2 className="h-5 w-5 mr-2" />
          Confirmar Pagamento
        </Button>
      )}

      {/* Aviso de Segurança */}
      <div className="p-4 bg-gray-900/50 border border-gray-700 rounded-xl">
        <div className="flex items-start gap-3">
          <Shield className="h-5 w-5 text-amber-400 flex-shrink-0 mt-0.5" />
          <div className="text-xs text-gray-300 space-y-1">
            <p className="font-semibold text-white">🔒 Pagamento 100% Seguro</p>
            <ul className="list-disc list-inside space-y-1 text-gray-400">
              <li>Chave PIX validada e verificada</li>
              <li>Confirmação automática em até 5 minutos</li>
              <li>Não solicitamos senha ou dados bancários</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}