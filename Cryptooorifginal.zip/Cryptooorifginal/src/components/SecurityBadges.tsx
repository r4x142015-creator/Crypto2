import { Shield, Lock, Server, CheckCircle2, Globe } from 'lucide-react';

export default function SecurityBadges() {
  const badges = [
    {
      icon: Shield,
      text: 'SSL Certificado',
      color: 'text-green-400',
      bgColor: 'bg-green-500/10',
      borderColor: 'border-green-500/30'
    },
    {
      icon: Lock,
      text: 'Criptografia E2E',
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/10',
      borderColor: 'border-blue-500/30'
    },
    {
      icon: Server,
      text: 'Servidor Seguro',
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10',
      borderColor: 'border-purple-500/30'
    },
    {
      icon: CheckCircle2,
      text: 'Verificado',
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10',
      borderColor: 'border-emerald-500/30'
    },
    {
      icon: Globe,
      text: 'PCI Compliant',
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/10',
      borderColor: 'border-cyan-500/30'
    }
  ];

  return (
    <div className="border-t border-gray-800/50 bg-gray-950/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-6">
        {/* Security Info Banner */}
        <div className="mb-6 p-5 bg-gradient-to-r from-green-500/10 via-emerald-500/10 to-green-500/10 border border-green-500/30 rounded-xl shadow-lg shadow-green-500/5">
          <div className="flex items-center gap-3 flex-wrap justify-center">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-green-500/20 flex items-center justify-center animate-pulse">
                <Lock className="h-6 w-6 text-green-400" />
              </div>
              <div className="text-left">
                <p className="text-base text-green-400 font-semibold">🔒 Criptografia Ponta a Ponta Ativa</p>
                <p className="text-sm text-green-300/70 mt-1">Todas as transações são protegidas com AES-256 e TLS 1.3</p>
              </div>
            </div>
          </div>
        </div>

        {/* Security Badges Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 mb-6">
          {badges.map((badge, index) => {
            const Icon = badge.icon;
            return (
              <div
                key={index}
                className={`flex items-center gap-3 p-4 ${badge.bgColor} border ${badge.borderColor} rounded-xl hover:scale-105 transition-all duration-300 cursor-pointer shadow-lg`}
              >
                <Icon className={`h-6 w-6 ${badge.color}`} />
                <span className={`text-sm font-medium ${badge.color}`}>{badge.text}</span>
              </div>
            );
          })}
        </div>

        {/* Trust Badges */}
        <div className="flex flex-wrap items-center justify-center gap-6 py-4">
          {/* Norton Secured */}
          <div className="flex items-center gap-3 px-5 py-3 bg-yellow-500/10 border border-yellow-500/30 rounded-xl hover:scale-105 transition-all duration-300 shadow-lg">
            <Shield className="h-7 w-7 text-yellow-400" />
            <div className="text-left">
              <p className="text-sm text-yellow-400 font-semibold">Norton</p>
              <p className="text-xs text-yellow-300/70">Secured</p>
            </div>
          </div>

          {/* McAfee Secure */}
          <div className="flex items-center gap-3 px-5 py-3 bg-red-500/10 border border-red-500/30 rounded-xl hover:scale-105 transition-all duration-300 shadow-lg">
            <CheckCircle2 className="h-7 w-7 text-red-400" />
            <div className="text-left">
              <p className="text-sm text-red-400 font-semibold">McAfee</p>
              <p className="text-xs text-red-300/70">Secure</p>
            </div>
          </div>

          {/* SSL Encryption */}
          <div className="flex items-center gap-3 px-5 py-3 bg-blue-500/10 border border-blue-500/30 rounded-xl hover:scale-105 transition-all duration-300 shadow-lg">
            <Lock className="h-7 w-7 text-blue-400" />
            <div className="text-left">
              <p className="text-sm text-blue-400 font-semibold">256-bit SSL</p>
              <p className="text-xs text-blue-300/70">Encryption</p>
            </div>
          </div>

          {/* PCI Compliant */}
          <div className="flex items-center gap-3 px-5 py-3 bg-purple-500/10 border border-purple-500/30 rounded-xl hover:scale-105 transition-all duration-300 shadow-lg">
            <Server className="h-7 w-7 text-purple-400" />
            <div className="text-left">
              <p className="text-sm text-purple-400 font-semibold">PCI DSS</p>
              <p className="text-xs text-purple-300/70">Compliant</p>
            </div>
          </div>

          {/* Verified Exchange */}
          <div className="flex items-center gap-3 px-5 py-3 bg-green-500/10 border border-green-500/30 rounded-xl hover:scale-105 transition-all duration-300 shadow-lg">
            <CheckCircle2 className="h-7 w-7 text-green-400" />
            <div className="text-left">
              <p className="text-sm text-green-400 font-semibold">Verified</p>
              <p className="text-xs text-green-300/70">Exchange</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}