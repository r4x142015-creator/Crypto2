import { useState } from 'react';
import { Button } from './ui/button';
import { CreditCard, Lock, Shield, CheckCircle2, ExternalLink, Smartphone } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface StripePaymentLinkProps {
  amount: string;
  currency: string;
  cryptoSymbol: string;
  cryptoAmount: string;
  onConfirm: () => void;
  onCancel?: () => void;
}

// ✅ PAYMENT LINK DO STRIPE - 100% SEGURO
const STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/00wcMYaPJdmD7sT6Spco000';

export default function StripePaymentLink({ 
  amount, 
  currency, 
  cryptoSymbol, 
  cryptoAmount, 
  onConfirm,
  onCancel 
}: StripePaymentLinkProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePaymentClick = () => {
    setIsProcessing(true);

    // Abrir Payment Link diretamente
    window.open(STRIPE_PAYMENT_LINK, '_blank', 'noopener,noreferrer');
    
    // Toast de informação após abrir
    setTimeout(() => {
      setIsProcessing(false);
      
      toast.info('Checkout aberto', {
        description: 'Complete o pagamento na aba do Stripe. Após finalizar, clique em "Confirmar Pagamento" aqui.',
        duration: 6000,
      });
    }, 500);
  };

  const handlePaymentComplete = () => {
    toast.success('✅ Pagamento Confirmado!', {
      description: `Você receberá ${cryptoAmount} ${cryptoSymbol} em sua carteira`,
      duration: 5000,
    });
    onConfirm();
  };

  return (
    <div className="space-y-6">
      {/* Aviso de segurança - POSITIVO */}
      <div className="bg-green-500/10 border-2 border-green-500/50 rounded-xl p-6">
        <div className="flex items-start gap-4">
          <div className="h-12 w-12 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0">
            <Shield className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="text-green-400 text-xl font-bold mb-2">
              ✅ Pagamento 100% Seguro
            </h3>
            <p className="text-green-300 text-sm mb-3">
              Você será redirecionado para o checkout oficial do Stripe.
            </p>
            <div className="bg-green-900/30 rounded-lg p-3 space-y-1">
              <p className="text-green-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" />
                Hospedado pelo Stripe (não armazenamos dados do cartão)
              </p>
              <p className="text-green-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" />
                Certificado SSL 256-bit e PCI DSS Level 1
              </p>
              <p className="text-green-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" />
                Aceita cartões de crédito/débito de todo o mundo
              </p>
              <p className="text-green-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" />
                Suporte a 3D Secure e autenticação bancária
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Header com segurança */}
      <div className="bg-gradient-to-r from-blue-600/10 to-blue-800/10 border border-blue-500/30 rounded-xl p-6">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="h-12 w-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
            <CreditCard className="h-6 w-6 text-white" />
          </div>
          <h3 className="text-white text-xl font-semibold">Checkout Stripe Oficial</h3>
        </div>
        
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <div className="flex items-center gap-2 text-blue-300 text-sm">
            <Shield className="h-4 w-4" />
            <span>SSL 256-bit</span>
          </div>
          <div className="flex items-center gap-2 text-blue-300 text-sm">
            <Lock className="h-4 w-4" />
            <span>PCI DSS Level 1</span>
          </div>
          <div className="flex items-center gap-2 text-green-300 text-sm">
            <CheckCircle2 className="h-4 w-4" />
            <span>Stripe Verified</span>
          </div>
        </div>
      </div>

      {/* Resumo da compra */}
      <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-2 border-green-500/30 rounded-xl p-6">
        <div className="text-center space-y-2">
          <p className="text-gray-400 text-sm">Você está comprando</p>
          <p className="text-green-400 text-2xl font-bold">{cryptoAmount} {cryptoSymbol}</p>
          <div className="h-px bg-green-500/30 my-3" />
          <p className="text-gray-400 text-sm">Valor Total</p>
          <p className="text-white text-4xl font-bold font-mono">{amount}</p>
        </div>
      </div>

      {/* Como funciona */}
      <div className="bg-gray-900/50 border border-gray-700/50 rounded-xl p-6">
        <h4 className="text-white font-bold mb-4 flex items-center gap-2">
          <Shield className="h-5 w-5 text-blue-400" />
          Como funciona o pagamento:
        </h4>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-full bg-blue-500/20 border border-blue-500/50 flex items-center justify-center flex-shrink-0">
              <span className="text-blue-400 font-bold text-sm">1</span>
            </div>
            <div>
              <p className="text-white text-sm font-semibold">Redirecionamento Seguro</p>
              <p className="text-gray-400 text-xs">Você será levado ao checkout oficial do Stripe</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-full bg-blue-500/20 border border-blue-500/50 flex items-center justify-center flex-shrink-0">
              <span className="text-blue-400 font-bold text-sm">2</span>
            </div>
            <div>
              <p className="text-white text-sm font-semibold">Preencha os Dados</p>
              <p className="text-gray-400 text-xs">Insira os dados do cartão no formulário seguro do Stripe</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-full bg-blue-500/20 border border-blue-500/50 flex items-center justify-center flex-shrink-0">
              <span className="text-blue-400 font-bold text-sm">3</span>
            </div>
            <div>
              <p className="text-white text-sm font-semibold">Confirme o Pagamento</p>
              <p className="text-gray-400 text-xs">Seu banco pode solicitar autenticação adicional (3D Secure)</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-full bg-green-500/20 border border-green-500/50 flex items-center justify-center flex-shrink-0">
              <span className="text-green-400 font-bold text-sm">4</span>
            </div>
            <div>
              <p className="text-white text-sm font-semibold">Receba suas Criptomoedas</p>
              <p className="text-gray-400 text-xs">Após confirmação, receberá {cryptoAmount} {cryptoSymbol}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bandeiras aceitas */}
      <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-4">
        <p className="text-gray-400 text-xs mb-3 text-center">Bandeiras e Métodos Aceitos</p>
        <div className="flex items-center justify-center gap-3 flex-wrap">
          {['Visa', 'Mastercard', 'Amex', 'Discover', 'Diners', 'JCB', 'Union Pay', 'Elo'].map((brand) => (
            <div
              key={brand}
              className="bg-white px-3 py-1.5 rounded text-xs font-bold text-gray-900"
            >
              {brand}
            </div>
          ))}
        </div>
        <div className="mt-3 flex items-center justify-center gap-3 flex-wrap">
          <div className="bg-green-600 px-3 py-1.5 rounded text-xs font-bold text-white flex items-center gap-1">
            <Smartphone className="h-3 w-3" />
            Apple Pay
          </div>
          <div className="bg-purple-600 px-3 py-1.5 rounded text-xs font-bold text-white flex items-center gap-1">
            <Smartphone className="h-3 w-3" />
            Google Pay
          </div>
          <div className="bg-blue-600 px-3 py-1.5 rounded text-xs font-bold text-white flex items-center gap-1">
            <CreditCard className="h-3 w-3" />
            Boleto
          </div>
        </div>
      </div>

      {/* Botão principal - Ir para pagamento */}
      <Button
        onClick={handlePaymentClick}
        disabled={isProcessing}
        className="w-full h-16 bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:from-blue-600 hover:via-blue-700 hover:to-blue-800 text-white text-lg font-bold shadow-xl shadow-blue-500/40 transition-all duration-300 hover:shadow-2xl hover:shadow-blue-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
        style={{
          background: isProcessing ? '#635bff' : 'linear-gradient(to right, #3b82f6, #2563eb, #1d4ed8)',
        }}
        onMouseOver={(e) => !isProcessing && (e.currentTarget.style.background = 'linear-gradient(to right, #2563eb, #1d4ed8, #1e40af)')}
        onMouseOut={(e) => !isProcessing && (e.currentTarget.style.background = 'linear-gradient(to right, #3b82f6, #2563eb, #1d4ed8)')}
      >
        {isProcessing ? (
          <div className="flex items-center gap-3">
            <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            <span>Abrindo Checkout Seguro...</span>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            <span>💳 Ir para Pagamento Seguro</span>
            <ExternalLink className="h-4 w-4" />
          </div>
        )}
      </Button>

      {/* Botão "Confirmar pagamento após finalizar no Stripe" */}
      <div className="bg-amber-500/10 border-2 border-amber-500/30 rounded-xl p-4 mb-4">
        <p className="text-amber-300 text-sm text-center mb-3">
          <strong>⚠️ Importante:</strong> Após completar o pagamento no Stripe, retorne aqui e clique no botão abaixo para confirmar.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Button
          onClick={handlePaymentComplete}
          variant="outline"
          className="h-14 border-green-600 text-green-400 hover:bg-green-600 hover:text-white"
        >
          <CheckCircle2 className="h-4 w-4 mr-2" />
          ✅ Confirmar Pagamento Finalizado
        </Button>

        {/* Botão cancelar */}
        {onCancel && (
          <Button
            onClick={onCancel}
            variant="outline"
            className="h-14 border-gray-700 text-gray-400 hover:bg-gray-800"
          >
            Cancelar
          </Button>
        )}
      </div>

      {/* Informações adicionais */}
      <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Shield className="h-5 w-5 text-blue-400 flex-shrink-0 mt-0.5" />
          <div className="text-blue-300 text-sm">
            <p className="font-semibold mb-1">🔒 Máxima Segurança</p>
            <p className="text-xs text-blue-200/80">
              O Stripe processa bilhões de dólares anualmente para empresas como Amazon, Google, e Microsoft. 
              Seus dados de pagamento são processados diretamente nos servidores do Stripe - nós nunca vemos ou armazenamos informações do seu cartão.
            </p>
          </div>
        </div>
      </div>

      {/* Link direto (backup) */}
      <div className="text-center pt-4 border-t border-gray-700/50">
        <p className="text-gray-400 text-xs mb-3">Ou acesse diretamente:</p>
        <a 
          href={STRIPE_PAYMENT_LINK} 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 text-sm font-semibold transition-colors"
        >
          <ExternalLink className="h-4 w-4" />
          {STRIPE_PAYMENT_LINK}
        </a>
      </div>

      <div className="text-center text-gray-400 text-xs space-y-1">
        <p>Ao confirmar, você concorda com nossos Termos de Uso</p>
        <p className="text-gray-500">Powered by Stripe • Payment Link Oficial ✓</p>
      </div>
    </div>
  );
}