#!/bin/bash

echo "📦 Criando ZIP do projeto CryptoSell..."
echo ""

# Nome do arquivo ZIP
ZIP_NAME="cryptosell-$(date +%Y%m%d-%H%M%S).zip"

# Criar diretório temporário
TEMP_DIR="cryptosell-export"
mkdir -p $TEMP_DIR

echo "✅ Copiando arquivos..."

# Copiar estrutura de pastas
mkdir -p $TEMP_DIR/components/ui
mkdir -p $TEMP_DIR/data
mkdir -p $TEMP_DIR/pages/api
mkdir -p $TEMP_DIR/styles

# Copiar arquivos principais
cp App.tsx $TEMP_DIR/ 2>/dev/null || echo "⚠️ App.tsx não encontrado"
cp package.json $TEMP_DIR/ 2>/dev/null || echo "⚠️ package.json não encontrado"
cp .env.local $TEMP_DIR/ 2>/dev/null || echo "⚠️ .env.local não encontrado"
cp .gitignore $TEMP_DIR/ 2>/dev/null || echo "⚠️ .gitignore não encontrado"
cp tsconfig.json $TEMP_DIR/ 2>/dev/null || echo "⚠️ tsconfig.json não encontrado"
cp tailwind.config.js $TEMP_DIR/ 2>/dev/null || echo "⚠️ tailwind.config.js não encontrado"
cp postcss.config.js $TEMP_DIR/ 2>/dev/null || echo "⚠️ postcss.config.js não encontrado"

# Copiar componentes
cp components/*.tsx $TEMP_DIR/components/ 2>/dev/null || echo "⚠️ Componentes não encontrados"

# Copiar componentes UI
cp components/ui/*.tsx $TEMP_DIR/components/ui/ 2>/dev/null || echo "⚠️ Componentes UI não encontrados"
cp components/ui/*.ts $TEMP_DIR/components/ui/ 2>/dev/null

# Copiar dados
cp data/*.ts $TEMP_DIR/data/ 2>/dev/null || echo "⚠️ Dados não encontrados"

# Copiar API
cp pages/api/*.js $TEMP_DIR/pages/api/ 2>/dev/null || echo "⚠️ API não encontrada"

# Copiar estilos
cp styles/*.css $TEMP_DIR/styles/ 2>/dev/null || echo "⚠️ Estilos não encontrados"

# Copiar documentação
cp *.md $TEMP_DIR/ 2>/dev/null

echo ""
echo "✅ Criando arquivo ZIP..."

# Criar ZIP
zip -r $ZIP_NAME $TEMP_DIR

# Limpar diretório temporário
rm -rf $TEMP_DIR

echo ""
echo "🎉 ZIP criado com sucesso: $ZIP_NAME"
echo ""
echo "Para extrair:"
echo "unzip $ZIP_NAME"
echo ""
