export const brazilianBankLogos: Record<string, string> = {
  "Banco do Brasil": "https://logodownload.org/wp-content/uploads/2020/02/banco-do-brasil-logo-0.png",
  "Caixa Econômica Federal": "https://logodownload.org/wp-content/uploads/2015/02/caixa-economica-federal-logo-0.png",
  "Bradesco": "https://logodownload.org/wp-content/uploads/2014/05/bradesco-logo.png",
  "Itaú Unibanco": "https://logodownload.org/wp-content/uploads/2014/09/itau-logo.png",
  "Santander Brasil": "https://logodownload.org/wp-content/uploads/2014/07/santander-logo.png",
  "Banco Safra": "https://via.placeholder.com/120x40/003366/ffffff?text=Safra",
  "BTG Pactual": "https://via.placeholder.com/120x40/000000/ffffff?text=BTG",
  "Banco Inter": "https://logodownload.org/wp-content/uploads/2020/10/banco-inter-logo.png",
  "Nubank": "https://logodownload.org/wp-content/uploads/2020/02/nubank-logo.png",
  "C6 Bank": "https://via.placeholder.com/120x40/1A1A1A/ffffff?text=C6+Bank",
  "Banco Original": "https://via.placeholder.com/120x40/00D959/ffffff?text=Original",
  "Banco Pan": "https://via.placeholder.com/120x40/0066CC/ffffff?text=Pan",
  "Banrisul": "https://via.placeholder.com/120x40/003D7A/ffffff?text=Banrisul",
  "Banco Votorantim": "https://via.placeholder.com/120x40/FF6600/ffffff?text=Votorantim",
  "Sicredi": "https://via.placeholder.com/120x40/006838/ffffff?text=Sicredi",
  "Banco BMG": "https://via.placeholder.com/120x40/E60000/ffffff?text=BMG",
  "Banco Mercantil": "https://via.placeholder.com/120x40/003D7A/ffffff?text=Mercantil",
  "Banco Daycoval": "https://via.placeholder.com/120x40/0052A5/ffffff?text=Daycoval",
  "Banco Pine": "https://via.placeholder.com/120x40/1B4F72/ffffff?text=Pine",
  "Banco Fibra": "https://via.placeholder.com/120x40/E74C3C/ffffff?text=Fibra",
  "Banco Sofisa": "https://via.placeholder.com/120x40/2ECC71/ffffff?text=Sofisa",
  "Banco Modal": "https://via.placeholder.com/120x40/9B59B6/ffffff?text=Modal",
  "Banco ABC Brasil": "https://via.placeholder.com/120x40/34495E/ffffff?text=ABC",
  "Banco Agibank": "https://via.placeholder.com/120x40/E67E22/ffffff?text=Agibank",
  "PagBank (PagSeguro)": "https://logodownload.org/wp-content/uploads/2021/05/pagbank-logo.png",
  "Banco BS2": "https://via.placeholder.com/120x40/16A085/ffffff?text=BS2",
  "Banco Neon": "https://via.placeholder.com/120x40/00D9E1/ffffff?text=Neon",
  "Banco Next": "https://via.placeholder.com/120x40/00E3A0/ffffff?text=Next",
  "Banco Digio": "https://via.placeholder.com/120x40/8E44AD/ffffff?text=Digio",
  "Banco Will Bank": "https://via.placeholder.com/120x40/F39C12/ffffff?text=Will"
};

export const internationalBankLogos: Record<string, string> = {
  // USA
  "JPMorgan Chase (USA)": "https://logodownload.org/wp-content/uploads/2014/04/jp-morgan-chase-logo.png",
  "Bank of America (USA)": "https://logodownload.org/wp-content/uploads/2014/05/bank-of-america-logo.png",
  "Wells Fargo (USA)": "https://logodownload.org/wp-content/uploads/2018/10/wells-fargo-logo.png",
  "Citigroup (USA)": "https://logodownload.org/wp-content/uploads/2014/05/citibank-logo.png",
  "U.S. Bancorp (USA)": "https://via.placeholder.com/120x40/CC0000/ffffff?text=US+Bank",
  "PNC Financial Services (USA)": "https://via.placeholder.com/120x40/F47721/ffffff?text=PNC",
  "Goldman Sachs (USA)": "https://via.placeholder.com/120x40/0F4C8C/ffffff?text=Goldman",
  "Morgan Stanley (USA)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=Morgan",
  "Charles Schwab (USA)": "https://via.placeholder.com/120x40/00A0DF/ffffff?text=Schwab",
  "Capital One (USA)": "https://via.placeholder.com/120x40/004879/ffffff?text=Capital+One",
  
  // Canada
  "TD Bank (USA/Canada)": "https://via.placeholder.com/120x40/006B3F/ffffff?text=TD",
  "Royal Bank of Canada (RBC)": "https://via.placeholder.com/120x40/005DAA/ffffff?text=RBC",
  "Toronto-Dominion Bank (Canada)": "https://via.placeholder.com/120x40/006B3F/ffffff?text=TD+Canada",
  "Bank of Nova Scotia (Canada)": "https://via.placeholder.com/120x40/EC1C24/ffffff?text=Scotiabank",
  "Bank of Montreal (Canada)": "https://via.placeholder.com/120x40/003DA5/ffffff?text=BMO",
  "Canadian Imperial Bank (Canada)": "https://via.placeholder.com/120x40/D6001C/ffffff?text=CIBC",
  
  // México
  "Banamex (México)": "https://via.placeholder.com/120x40/ED1C24/ffffff?text=Banamex",
  "BBVA México (México)": "https://logodownload.org/wp-content/uploads/2019/11/bbva-logo.png",
  "Santander México (México)": "https://logodownload.org/wp-content/uploads/2014/07/santander-logo.png",
  "Banorte (México)": "https://via.placeholder.com/120x40/E30613/ffffff?text=Banorte",
  
  // UK
  "HSBC Holdings (Reino Unido)": "https://logodownload.org/wp-content/uploads/2014/05/hsbc-logo.png",
  "Barclays (Reino Unido)": "https://logodownload.org/wp-content/uploads/2014/05/barclays-logo.png",
  "Lloyds Banking Group (Reino Unido)": "https://via.placeholder.com/120x40/006F62/ffffff?text=Lloyds",
  "Royal Bank of Scotland (Reino Unido)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=RBS",
  "Standard Chartered (Reino Unido)": "https://via.placeholder.com/120x40/007C92/ffffff?text=SC",
  
  // França
  "BNP Paribas (França)": "https://logodownload.org/wp-content/uploads/2014/09/bnp-paribas-logo.png",
  "Crédit Agricole (França)": "https://via.placeholder.com/120x40/00523F/ffffff?text=CA",
  "Société Générale (França)": "https://via.placeholder.com/120x40/E60028/ffffff?text=SG",
  
  // Alemanha
  "Deutsche Bank (Alemanha)": "https://logodownload.org/wp-content/uploads/2014/05/deutsche-bank-logo.png",
  "Commerzbank (Alemanha)": "https://via.placeholder.com/120x40/FFCC00/000000?text=Commerzbank",
  "DZ Bank (Alemanha)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=DZ",
  "KfW (Alemanha)": "https://via.placeholder.com/120x40/004F9F/ffffff?text=KfW",
  
  // Suíça
  "UBS (Suíça)": "https://logodownload.org/wp-content/uploads/2014/04/ubs-logo.png",
  "Credit Suisse (Suíça)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=CS",
  
  // Holanda
  "Rabobank (Holanda)": "https://via.placeholder.com/120x40/FF6600/ffffff?text=Rabobank",
  "ING Group (Holanda)": "https://logodownload.org/wp-content/uploads/2014/05/ing-logo.png",
  "ABN AMRO (Holanda)": "https://via.placeholder.com/120x40/00857C/ffffff?text=ABN",
  
  // Itália
  "UniCredit (Itália)": "https://via.placeholder.com/120x40/E30613/ffffff?text=UniCredit",
  "Intesa Sanpaolo (Itália)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=Intesa",
  
  // Espanha
  "Banco Santander (Espanha)": "https://logodownload.org/wp-content/uploads/2014/07/santander-logo.png",
  "BBVA (Espanha)": "https://logodownload.org/wp-content/uploads/2019/11/bbva-logo.png",
  "CaixaBank (Espanha)": "https://via.placeholder.com/120x40/0077C8/ffffff?text=CaixaBank",
  
  // Nórdicos
  "Nordea Bank (Suécia)": "https://via.placeholder.com/120x40/0000A0/ffffff?text=Nordea",
  "Swedbank (Suécia)": "https://via.placeholder.com/120x40/FF5000/ffffff?text=Swedbank",
  "Danske Bank (Dinamarca)": "https://via.placeholder.com/120x40/003755/ffffff?text=Danske",
  
  // China
  "Industrial and Commercial Bank of China (ICBC)": "https://via.placeholder.com/120x40/C8102E/ffffff?text=ICBC",
  "China Construction Bank": "https://via.placeholder.com/120x40/003D7A/ffffff?text=CCB",
  "Agricultural Bank of China": "https://via.placeholder.com/120x40/00793E/ffffff?text=ABC",
  "Bank of China": "https://via.placeholder.com/120x40/B91E24/ffffff?text=BOC",
  "Postal Savings Bank of China": "https://via.placeholder.com/120x40/007A3D/ffffff?text=PSBC",
  "China Merchants Bank": "https://via.placeholder.com/120x40/DC143C/ffffff?text=CMB",
  "Shanghai Pudong Development Bank": "https://via.placeholder.com/120x40/0052A5/ffffff?text=SPDB",
  "Bank of Communications (China)": "https://via.placeholder.com/120x40/004B87/ffffff?text=BOCOM",
  
  // Japão
  "Mitsubishi UFJ Financial (Japão)": "https://via.placeholder.com/120x40/E60012/ffffff?text=MUFG",
  "Sumitomo Mitsui Financial (Japão)": "https://via.placeholder.com/120x40/00A040/ffffff?text=SMBC",
  "Mizuho Financial Group (Japão)": "https://via.placeholder.com/120x40/005BAA/ffffff?text=Mizuho",
  "Nomura Holdings (Japão)": "https://via.placeholder.com/120x40/00693E/ffffff?text=Nomura",
  
  // Índia
  "HDFC Bank (Índia)": "https://via.placeholder.com/120x40/004C8F/ffffff?text=HDFC",
  "ICICI Bank (Índia)": "https://via.placeholder.com/120x40/F37021/ffffff?text=ICICI",
  "State Bank of India": "https://via.placeholder.com/120x40/1C4B9B/ffffff?text=SBI",
  "Axis Bank (Índia)": "https://via.placeholder.com/120x40/800000/ffffff?text=Axis",
  "Kotak Mahindra Bank (Índia)": "https://via.placeholder.com/120x40/ED1C24/ffffff?text=Kotak",
  
  // Singapura
  "DBS Bank (Singapura)": "https://via.placeholder.com/120x40/EB0A1E/ffffff?text=DBS",
  "OCBC Bank (Singapura)": "https://via.placeholder.com/120x40/D71921/ffffff?text=OCBC",
  "United Overseas Bank (Singapura)": "https://via.placeholder.com/120x40/002B5C/ffffff?text=UOB",
  
  // Malásia
  "CIMB Group (Malásia)": "https://via.placeholder.com/120x40/DC143C/ffffff?text=CIMB",
  "Maybank (Malásia)": "https://via.placeholder.com/120x40/FFCC00/000000?text=Maybank",
  "Public Bank (Malásia)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=Public",
  
  // Tailândia
  "Kasikornbank (Tailândia)": "https://via.placeholder.com/120x40/138F2D/ffffff?text=KBank",
  "Bangkok Bank (Tailândia)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=Bangkok",
  
  // Austrália
  "Commonwealth Bank (Austrália)": "https://via.placeholder.com/120x40/FFCC00/000000?text=CBA",
  "Westpac Banking (Austrália)": "https://via.placeholder.com/120x40/D4002A/ffffff?text=Westpac",
  "Australia and New Zealand Banking (ANZ)": "https://via.placeholder.com/120x40/007DBB/ffffff?text=ANZ",
  "National Australia Bank (NAB)": "https://via.placeholder.com/120x40/E30613/ffffff?text=NAB",
  "Macquarie Group (Austrália)": "https://via.placeholder.com/120x40/005A31/ffffff?text=Macquarie",
  
  // Nova Zelândia
  "Bank of New Zealand": "https://via.placeholder.com/120x40/00457C/ffffff?text=BNZ",
  "ASB Bank (Nova Zelândia)": "https://via.placeholder.com/120x40/FFCC00/000000?text=ASB",
  "Kiwibank (Nova Zelândia)": "https://via.placeholder.com/120x40/60BB46/ffffff?text=Kiwibank",
  
  // Oriente Médio
  "Qatar National Bank": "https://via.placeholder.com/120x40/52194E/ffffff?text=QNB",
  "Emirates NBD (Dubai)": "https://via.placeholder.com/120x40/00923F/ffffff?text=Emirates",
  "First Abu Dhabi Bank": "https://via.placeholder.com/120x40/004D40/ffffff?text=FAB",
  "Al Rajhi Bank (Arábia Saudita)": "https://via.placeholder.com/120x40/007A33/ffffff?text=Al+Rajhi",
  "National Commercial Bank (Arábia Saudita)": "https://via.placeholder.com/120x40/0057A3/ffffff?text=NCB",
  "Kuwait Finance House": "https://via.placeholder.com/120x40/006838/ffffff?text=KFH",
  "National Bank of Kuwait": "https://via.placeholder.com/120x40/00693E/ffffff?text=NBK",
  "Mashreq Bank (Dubai)": "https://via.placeholder.com/120x40/DC143C/ffffff?text=Mashreq",
  "Commercial Bank of Dubai": "https://via.placeholder.com/120x40/0057A3/ffffff?text=CBD",
  "Abu Dhabi Commercial Bank": "https://via.placeholder.com/120x40/E30613/ffffff?text=ADCB",
  
  // África
  "Standard Bank (África do Sul)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=Standard",
  "FirstRand Bank (África do Sul)": "https://via.placeholder.com/120x40/002B5C/ffffff?text=FirstRand",
  "Absa Group (África do Sul)": "https://via.placeholder.com/120x40/DD0031/ffffff?text=Absa",
  "Nedbank (África do Sul)": "https://via.placeholder.com/120x40/007A3D/ffffff?text=Nedbank",
  "Capitec Bank (África do Sul)": "https://via.placeholder.com/120x40/0080C7/ffffff?text=Capitec",
  "Ecobank (Nigéria/Multi-país)": "https://via.placeholder.com/120x40/002B5C/ffffff?text=Ecobank",
  "United Bank for Africa (Nigéria)": "https://via.placeholder.com/120x40/E30613/ffffff?text=UBA",
  "Zenith Bank (Nigéria)": "https://via.placeholder.com/120x40/EC1C24/ffffff?text=Zenith",
  "Guaranty Trust Bank (Nigéria)": "https://via.placeholder.com/120x40/FF6600/ffffff?text=GTBank",
  "Access Bank (Nigéria)": "https://via.placeholder.com/120x40/F37021/ffffff?text=Access",
  
  // América Latina
  "Banco de Chile": "https://via.placeholder.com/120x40/003D7A/ffffff?text=Bco+Chile",
  "Banco Estado (Chile)": "https://via.placeholder.com/120x40/007A3D/ffffff?text=BancoEstado",
  "Banco de Crédito del Perú": "https://via.placeholder.com/120x40/002B5C/ffffff?text=BCP",
  "Interbank (Peru)": "https://via.placeholder.com/120x40/00A651/ffffff?text=Interbank",
  "Bancolombia (Colômbia)": "https://via.placeholder.com/120x40/FFCC00/000000?text=Bancolombia",
  "Banco de Bogotá (Colômbia)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=Bogota",
  "Banco Pichincha (Equador)": "https://via.placeholder.com/120x40/FFCC00/000000?text=Pichincha",
  "Banco General (Panamá)": "https://via.placeholder.com/120x40/003D7A/ffffff?text=General",
  "Banco de Costa Rica": "https://via.placeholder.com/120x40/0057A3/ffffff?text=BCR",
  "BAC Credomatic (América Central)": "https://via.placeholder.com/120x40/E30613/ffffff?text=BAC"
};

export const pixLogo = "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Pix_logo.svg/2560px-Pix_logo.svg.png";
export const paypalLogo = "https://logodownload.org/wp-content/uploads/2014/10/paypal-logo.png";
