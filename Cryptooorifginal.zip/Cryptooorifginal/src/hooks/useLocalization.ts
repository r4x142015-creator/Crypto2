import { useState, useEffect } from 'react';
import { languages, countryToLanguage } from '../utils/i18n/languages';
import { translations, getTranslation } from '../utils/i18n/translations';

export function useLocalization() {
  const [currentLang, setCurrentLang] = useState('en');
  const [currentCurrency, setCurrentCurrency] = useState({ code: 'USD', symbol: '$' });
  const [isDetecting, setIsDetecting] = useState(true);

  // Detectar país e idioma automaticamente
  useEffect(() => {
    const detectLocation = async () => {
      try {
        // Tentar localStorage primeiro
        const savedLang = localStorage.getItem('cryptosell_language');
        const savedCurrency = localStorage.getItem('cryptosell_currency');
        
        if (savedLang && savedCurrency) {
          setCurrentLang(savedLang);
          setCurrentCurrency(JSON.parse(savedCurrency));
          setIsDetecting(false);
          return;
        }

        // Detectar pelo navegador
        const browserLang = navigator.language.toLowerCase();
        let detectedLang = 'en';

        // Mapear idiomas do navegador
        if (browserLang.startsWith('pt-br') || browserLang === 'pt-br') {
          detectedLang = 'pt-br';
        } else if (browserLang.startsWith('pt')) {
          detectedLang = 'pt';
        } else if (browserLang.startsWith('es')) {
          if (browserLang.includes('mx')) detectedLang = 'es-mx';
          else if (browserLang.includes('ar')) detectedLang = 'es-ar';
          else detectedLang = 'es';
        } else if (browserLang.startsWith('fr')) {
          detectedLang = 'fr';
        } else if (browserLang.startsWith('de')) {
          detectedLang = 'de';
        } else if (browserLang.startsWith('zh')) {
          detectedLang = 'zh';
        } else if (browserLang.startsWith('ja')) {
          detectedLang = 'ja';
        } else if (browserLang.startsWith('ko')) {
          detectedLang = 'ko';
        } else if (browserLang.startsWith('ru')) {
          detectedLang = 'ru';
        } else if (browserLang.startsWith('ar')) {
          detectedLang = 'ar';
        } else if (browserLang.startsWith('hi')) {
          detectedLang = 'hi';
        } else {
          // Pegar os 2 primeiros caracteres
          const langCode = browserLang.substring(0, 2);
          if (languages[langCode]) {
            detectedLang = langCode;
          }
        }

        // Tentar detectar país via API de geolocalização (IP)
        try {
          const response = await fetch('https://ipapi.co/json/', {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
          });
          
          if (response.ok) {
            const data = await response.json();
            const countryCode = data.country_code;
            
            if (countryCode && countryToLanguage[countryCode]) {
              detectedLang = countryToLanguage[countryCode];
            }
          }
        } catch (error) {
          console.log('IP detection failed, using browser language');
        }

        // Aplicar idioma e moeda detectados
        if (languages[detectedLang]) {
          setCurrentLang(detectedLang);
          setCurrentCurrency({
            code: languages[detectedLang].currency,
            symbol: languages[detectedLang].symbol
          });
          
          // Salvar no localStorage
          localStorage.setItem('cryptosell_language', detectedLang);
          localStorage.setItem('cryptosell_currency', JSON.stringify({
            code: languages[detectedLang].currency,
            symbol: languages[detectedLang].symbol
          }));
        }
      } catch (error) {
        console.error('Location detection error:', error);
        // Fallback para inglês
        setCurrentLang('en');
        setCurrentCurrency({ code: 'USD', symbol: '$' });
      } finally {
        setIsDetecting(false);
      }
    };

    detectLocation();
  }, []);

  // Função para mudar idioma manualmente
  const changeLanguage = (langCode: string) => {
    if (languages[langCode]) {
      setCurrentLang(langCode);
      setCurrentCurrency({
        code: languages[langCode].currency,
        symbol: languages[langCode].symbol
      });
      
      // Salvar no localStorage
      localStorage.setItem('cryptosell_language', langCode);
      localStorage.setItem('cryptosell_currency', JSON.stringify({
        code: languages[langCode].currency,
        symbol: languages[langCode].symbol
      }));
    }
  };

  // Função para obter tradução
  const t = (key: string): string => {
    return getTranslation(currentLang, key);
  };

  return {
    currentLang,
    currentCurrency,
    isDetecting,
    changeLanguage,
    t,
    languages
  };
}
