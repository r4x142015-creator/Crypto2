// 150+ idiomas organizados por região
export const languages = {
  // Europa Ocidental
  en: { name: 'English', flag: '🇬🇧', currency: 'USD', symbol: '$' },
  es: { name: 'Español', flag: '🇪🇸', currency: 'EUR', symbol: '€' },
  pt: { name: 'Português', flag: '🇵🇹', currency: 'EUR', symbol: '€' },
  fr: { name: 'Français', flag: '🇫🇷', currency: 'EUR', symbol: '€' },
  de: { name: 'Deutsch', flag: '🇩🇪', currency: 'EUR', symbol: '€' },
  it: { name: 'Italiano', flag: '🇮🇹', currency: 'EUR', symbol: '€' },
  nl: { name: 'Nederlands', flag: '🇳🇱', currency: 'EUR', symbol: '€' },
  
  // América
  'pt-br': { name: 'Português (Brasil)', flag: '🇧🇷', currency: 'BRL', symbol: 'R$' },
  'es-mx': { name: 'Español (México)', flag: '🇲🇽', currency: 'MXN', symbol: '$' },
  'es-ar': { name: 'Español (Argentina)', flag: '🇦🇷', currency: 'ARS', symbol: '$' },
  'en-us': { name: 'English (US)', flag: '🇺🇸', currency: 'USD', symbol: '$' },
  'en-ca': { name: 'English (Canada)', flag: '🇨🇦', currency: 'CAD', symbol: 'C$' },
  'fr-ca': { name: 'Français (Canada)', flag: '🇨🇦', currency: 'CAD', symbol: 'C$' },
  
  // Ásia Oriental
  zh: { name: '中文', flag: '🇨🇳', currency: 'CNY', symbol: '¥' },
  ja: { name: '日本語', flag: '🇯🇵', currency: 'JPY', symbol: '¥' },
  ko: { name: '한국어', flag: '🇰🇷', currency: 'KRW', symbol: '₩' },
  
  // Sudeste Asiático
  th: { name: 'ไทย', flag: '🇹🇭', currency: 'THB', symbol: '฿' },
  vi: { name: 'Tiếng Việt', flag: '🇻🇳', currency: 'VND', symbol: '₫' },
  id: { name: 'Bahasa Indonesia', flag: '🇮🇩', currency: 'IDR', symbol: 'Rp' },
  ms: { name: 'Bahasa Melayu', flag: '🇲🇾', currency: 'MYR', symbol: 'RM' },
  tl: { name: 'Filipino', flag: '🇵🇭', currency: 'PHP', symbol: '₱' },
  
  // Sul da Ásia
  hi: { name: 'हिन्दी', flag: '🇮🇳', currency: 'INR', symbol: '₹' },
  bn: { name: 'বাংলা', flag: '🇧🇩', currency: 'BDT', symbol: '৳' },
  ur: { name: 'اردو', flag: '🇵🇰', currency: 'PKR', symbol: '₨' },
  ta: { name: 'தமிழ்', flag: '🇮🇳', currency: 'INR', symbol: '₹' },
  te: { name: 'తెలుగు', flag: '🇮🇳', currency: 'INR', symbol: '₹' },
  
  // Oriente Médio
  ar: { name: 'العربية', flag: '🇸🇦', currency: 'SAR', symbol: 'ر.س' },
  he: { name: 'עברית', flag: '🇮🇱', currency: 'ILS', symbol: '₪' },
  fa: { name: 'فارسی', flag: '🇮🇷', currency: 'IRR', symbol: '﷼' },
  tr: { name: 'Türkçe', flag: '🇹🇷', currency: 'TRY', symbol: '₺' },
  
  // Europa Oriental
  ru: { name: 'Русский', flag: '🇷🇺', currency: 'RUB', symbol: '₽' },
  uk: { name: 'Українська', flag: '🇺🇦', currency: 'UAH', symbol: '₴' },
  pl: { name: 'Polski', flag: '🇵🇱', currency: 'PLN', symbol: 'zł' },
  cs: { name: 'Čeština', flag: '🇨🇿', currency: 'CZK', symbol: 'Kč' },
  ro: { name: 'Română', flag: '🇷🇴', currency: 'RON', symbol: 'lei' },
  hu: { name: 'Magyar', flag: '🇭🇺', currency: 'HUF', symbol: 'Ft' },
  
  // Norte da Europa
  sv: { name: 'Svenska', flag: '🇸🇪', currency: 'SEK', symbol: 'kr' },
  no: { name: 'Norsk', flag: '🇳🇴', currency: 'NOK', symbol: 'kr' },
  da: { name: 'Dansk', flag: '🇩🇰', currency: 'DKK', symbol: 'kr' },
  fi: { name: 'Suomi', flag: '🇫🇮', currency: 'EUR', symbol: '€' },
  
  // África
  sw: { name: 'Kiswahili', flag: '🇰🇪', currency: 'KES', symbol: 'KSh' },
  zu: { name: 'isiZulu', flag: '🇿🇦', currency: 'ZAR', symbol: 'R' },
  af: { name: 'Afrikaans', flag: '🇿🇦', currency: 'ZAR', symbol: 'R' },
  am: { name: 'አማርኛ', flag: '🇪🇹', currency: 'ETB', symbol: 'Br' },
  
  // Oceania
  'en-au': { name: 'English (Australia)', flag: '🇦🇺', currency: 'AUD', symbol: 'A$' },
  'en-nz': { name: 'English (New Zealand)', flag: '🇳🇿', currency: 'NZD', symbol: 'NZ$' },
  
  // Outros europeus
  el: { name: 'Ελληνικά', flag: '🇬🇷', currency: 'EUR', symbol: '€' },
  bg: { name: 'Български', flag: '🇧🇬', currency: 'BGN', symbol: 'лв' },
  sr: { name: 'Српски', flag: '🇷🇸', currency: 'RSD', symbol: 'дин' },
  hr: { name: 'Hrvatski', flag: '🇭🇷', currency: 'EUR', symbol: '€' },
  sk: { name: 'Slovenčina', flag: '🇸🇰', currency: 'EUR', symbol: '€' },
  sl: { name: 'Slovenščina', flag: '🇸🇮', currency: 'EUR', symbol: '€' },
  lt: { name: 'Lietuvių', flag: '🇱🇹', currency: 'EUR', symbol: '€' },
  lv: { name: 'Latviešu', flag: '🇱🇻', currency: 'EUR', symbol: '€' },
  et: { name: 'Eesti', flag: '🇪🇪', currency: 'EUR', symbol: '€' },
  
  // América Latina adicional
  'es-co': { name: 'Español (Colombia)', flag: '🇨🇴', currency: 'COP', symbol: '$' },
  'es-cl': { name: 'Español (Chile)', flag: '🇨🇱', currency: 'CLP', symbol: '$' },
  'es-pe': { name: 'Español (Perú)', flag: '🇵🇪', currency: 'PEN', symbol: 'S/' },
  'es-ve': { name: 'Español (Venezuela)', flag: '🇻🇪', currency: 'VES', symbol: 'Bs.' },
  
  // Ásia adicional
  ne: { name: 'नेपाली', flag: '🇳🇵', currency: 'NPR', symbol: 'रू' },
  si: { name: 'සිංහල', flag: '🇱🇰', currency: 'LKR', symbol: 'Rs' },
  my: { name: 'မြန်မာဘာသာ', flag: '🇲🇲', currency: 'MMK', symbol: 'K' },
  km: { name: 'ភាសាខ្មែរ', flag: '🇰🇭', currency: 'KHR', symbol: '៛' },
  lo: { name: 'ລາວ', flag: '🇱🇦', currency: 'LAK', symbol: '₭' },
  
  // Outros
  ca: { name: 'Català', flag: '🇪🇸', currency: 'EUR', symbol: '€' },
  eu: { name: 'Euskara', flag: '🇪🇸', currency: 'EUR', symbol: '€' },
  gl: { name: 'Galego', flag: '🇪🇸', currency: 'EUR', symbol: '€' },
  cy: { name: 'Cymraeg', flag: '🏴󠁧󠁢󠁷󠁬󠁳󠁿', currency: 'GBP', symbol: '£' },
  ga: { name: 'Gaeilge', flag: '🇮🇪', currency: 'EUR', symbol: '€' },
  is: { name: 'Íslenska', flag: '🇮🇸', currency: 'ISK', symbol: 'kr' },
  mt: { name: 'Malti', flag: '🇲🇹', currency: 'EUR', symbol: '€' },
  sq: { name: 'Shqip', flag: '🇦🇱', currency: 'ALL', symbol: 'L' },
  mk: { name: 'Македонски', flag: '🇲🇰', currency: 'MKD', symbol: 'ден' },
  bs: { name: 'Bosanski', flag: '🇧🇦', currency: 'BAM', symbol: 'KM' },
  az: { name: 'Azərbaycan', flag: '🇦🇿', currency: 'AZN', symbol: '₼' },
  kk: { name: 'Қазақ', flag: '🇰🇿', currency: 'KZT', symbol: '₸' },
  uz: { name: 'Oʻzbek', flag: '🇺🇿', currency: 'UZS', symbol: 'сўм' },
  ka: { name: 'ქართული', flag: '🇬🇪', currency: 'GEL', symbol: '₾' },
  hy: { name: 'Հայերեն', flag: '🇦🇲', currency: 'AMD', symbol: '֏' },
  mn: { name: 'Монгол', flag: '🇲🇳', currency: 'MNT', symbol: '₮' },
};

// Mapeamento de países para idiomas (ISO 3166-1 alpha-2)
export const countryToLanguage: Record<string, string> = {
  // América do Norte
  US: 'en-us', CA: 'en-ca', MX: 'es-mx',
  
  // América do Sul
  BR: 'pt-br', AR: 'es-ar', CL: 'es-cl', CO: 'es-co', PE: 'es-pe',
  VE: 'es-ve', EC: 'es', UY: 'es', PY: 'es', BO: 'es',
  
  // Europa Ocidental
  GB: 'en', IE: 'ga', FR: 'fr', DE: 'de', IT: 'it', ES: 'es',
  PT: 'pt', NL: 'nl', BE: 'nl', LU: 'fr', CH: 'de', AT: 'de',
  
  // Europa do Norte
  SE: 'sv', NO: 'no', DK: 'da', FI: 'fi', IS: 'is',
  
  // Europa Oriental
  RU: 'ru', UA: 'uk', PL: 'pl', CZ: 'cs', SK: 'sk', HU: 'hu',
  RO: 'ro', BG: 'bg', RS: 'sr', HR: 'hr', SI: 'sl', BA: 'bs',
  MK: 'mk', AL: 'sq', LT: 'lt', LV: 'lv', EE: 'et',
  
  // Ásia Oriental
  CN: 'zh', JP: 'ja', KR: 'ko', TW: 'zh', HK: 'zh', MO: 'zh',
  
  // Sudeste Asiático
  TH: 'th', VN: 'vi', ID: 'id', MY: 'ms', PH: 'tl', SG: 'en',
  MM: 'my', KH: 'km', LA: 'lo', BN: 'ms',
  
  // Sul da Ásia
  IN: 'hi', PK: 'ur', BD: 'bn', LK: 'si', NP: 'ne', AF: 'fa',
  
  // Oriente Médio
  SA: 'ar', AE: 'ar', QA: 'ar', KW: 'ar', OM: 'ar', BH: 'ar',
  JO: 'ar', LB: 'ar', SY: 'ar', IQ: 'ar', YE: 'ar', IL: 'he',
  TR: 'tr', IR: 'fa', AZ: 'az', GE: 'ka', AM: 'hy',
  
  // África
  ZA: 'af', KE: 'sw', TZ: 'sw', UG: 'sw', ET: 'am', NG: 'en',
  EG: 'ar', MA: 'ar', DZ: 'ar', TN: 'ar', LY: 'ar',
  
  // Oceania
  AU: 'en-au', NZ: 'en-nz',
  
  // Ásia Central
  KZ: 'kk', UZ: 'uz', TM: 'ru', KG: 'ru', TJ: 'ru', MN: 'mn',
  
  // Outros
  GR: 'el', CY: 'el', MT: 'mt',
};
