#!/bin/bash

echo "🔍 VERIFICAÇÃO DO SISTEMA DE PAGAMENTO"
echo "======================================"
echo ""

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Função para verificar arquivo
check_file() {
    if [ -f "$1" ]; then
        echo -e "${GREEN}✅${NC} $1 existe"
        return 0
    else
        echo -e "${RED}❌${NC} $1 NÃO existe"
        return 1
    fi
}

# Função para verificar conteúdo
check_content() {
    if grep -q "$2" "$1" 2>/dev/null; then
        echo -e "${GREEN}✅${NC} $1 contém: $2"
        return 0
    else
        echo -e "${RED}❌${NC} $1 NÃO contém: $2"
        return 1
    fi
}

echo "📦 1. VERIFICANDO ARQUIVOS PRINCIPAIS"
echo "--------------------------------------"
check_file ".env.local"
check_file ".gitignore"
check_file "next.config.js"
check_file "pages/api/create-payment-intent.js"
check_file "components/StripeCheckout.tsx"
check_file "package.json"
echo ""

echo "🔐 2. VERIFICANDO CHAVES STRIPE"
echo "--------------------------------"
if [ -f ".env.local" ]; then
    check_content ".env.local" "STRIPE_SECRET_KEY"
    check_content ".env.local" "STRIPE_PUBLISHABLE_KEY"
    
    # Verificar se chaves não estão vazias
    if grep -q "STRIPE_SECRET_KEY=sk_" ".env.local"; then
        echo -e "${GREEN}✅${NC} STRIPE_SECRET_KEY configurada corretamente"
    else
        echo -e "${RED}❌${NC} STRIPE_SECRET_KEY está vazia ou inválida"
    fi
else
    echo -e "${RED}❌${NC} .env.local não existe!"
    echo -e "${YELLOW}💡${NC} Crie o arquivo .env.local com as chaves Stripe"
fi
echo ""

echo "🛡️ 3. VERIFICANDO SEGURANÇA (.gitignore)"
echo "----------------------------------------"
if [ -f ".gitignore" ]; then
    check_content ".gitignore" ".env.local"
    check_content ".gitignore" "node_modules"
else
    echo -e "${RED}❌${NC} .gitignore não existe!"
fi
echo ""

echo "📦 4. VERIFICANDO DEPENDÊNCIAS"
echo "------------------------------"
if [ -f "package.json" ]; then
    check_content "package.json" "stripe"
    check_content "package.json" "@stripe/stripe-js"
    check_content "package.json" "@stripe/react-stripe-js"
    
    if [ -d "node_modules" ]; then
        echo -e "${GREEN}✅${NC} node_modules existe"
        
        if [ -d "node_modules/stripe" ]; then
            echo -e "${GREEN}✅${NC} Stripe instalado"
        else
            echo -e "${RED}❌${NC} Stripe NÃO instalado"
            echo -e "${YELLOW}💡${NC} Execute: npm install"
        fi
    else
        echo -e "${RED}❌${NC} node_modules NÃO existe"
        echo -e "${YELLOW}💡${NC} Execute: npm install"
    fi
else
    echo -e "${RED}❌${NC} package.json não existe!"
fi
echo ""

echo "🔧 5. VERIFICANDO BACKEND API"
echo "-----------------------------"
if [ -f "pages/api/create-payment-intent.js" ]; then
    check_content "pages/api/create-payment-intent.js" "Stripe"
    check_content "pages/api/create-payment-intent.js" "process.env.STRIPE_SECRET_KEY"
    check_content "pages/api/create-payment-intent.js" "paymentIntents.create"
else
    echo -e "${RED}❌${NC} API backend não existe!"
fi
echo ""

echo "🎨 6. VERIFICANDO FRONTEND"
echo "-------------------------"
if [ -f "components/StripeCheckout.tsx" ]; then
    check_content "components/StripeCheckout.tsx" "loadStripe"
    check_content "components/StripeCheckout.tsx" "PaymentElement"
    check_content "components/StripeCheckout.tsx" "create-payment-intent"
else
    echo -e "${RED}❌${NC} StripeCheckout não existe!"
fi
echo ""

echo "🌐 7. VERIFICANDO SERVIDOR"
echo "-------------------------"
if lsof -i:3000 >/dev/null 2>&1; then
    echo -e "${GREEN}✅${NC} Servidor rodando na porta 3000"
    
    # Testar API
    echo -e "${YELLOW}🔄${NC} Testando API..."
    response=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:3000/api/create-payment-intent \
        -H "Content-Type: application/json" \
        -d '{"amount":100,"currency":"brl","cryptoSymbol":"BTC","tokenAmount":"0.001"}' 2>/dev/null)
    
    if [ "$response" = "200" ] || [ "$response" = "400" ]; then
        echo -e "${GREEN}✅${NC} API respondendo (HTTP $response)"
    else
        echo -e "${RED}❌${NC} API não respondendo corretamente (HTTP $response)"
    fi
else
    echo -e "${RED}❌${NC} Servidor NÃO está rodando na porta 3000"
    echo -e "${YELLOW}💡${NC} Execute: npm run dev"
fi
echo ""

echo "📊 8. RESUMO"
echo "-----------"
errors=0

# Contar erros
if [ ! -f ".env.local" ]; then ((errors++)); fi
if [ ! -f "pages/api/create-payment-intent.js" ]; then ((errors++)); fi
if [ ! -f "components/StripeCheckout.tsx" ]; then ((errors++)); fi
if [ ! -d "node_modules" ]; then ((errors++)); fi

if [ $errors -eq 0 ]; then
    echo -e "${GREEN}✅ TUDO OK!${NC} Sistema pronto para processar pagamentos"
    echo ""
    echo "🚀 PRÓXIMO PASSO:"
    echo "   1. Se não está rodando: npm run dev"
    echo "   2. Abra: http://localhost:3000"
    echo "   3. Vá em 'Comprar Cripto'"
    echo "   4. Teste um pagamento!"
else
    echo -e "${RED}❌ ATENÇÃO!${NC} Encontrados $errors problemas"
    echo ""
    echo "🔧 CORREÇÕES NECESSÁRIAS:"
    
    if [ ! -f ".env.local" ]; then
        echo "   • Criar .env.local com chaves Stripe"
    fi
    
    if [ ! -d "node_modules" ]; then
        echo "   • Executar: npm install"
    fi
    
    if [ ! -f "pages/api/create-payment-intent.js" ]; then
        echo "   • Verificar arquivo de API backend"
    fi
fi

echo ""
echo "======================================"
echo "Verificação concluída!"
echo "======================================"
