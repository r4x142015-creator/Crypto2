# ⚡ COMANDOS PRONTOS - COPIAR E COLAR

## 🎯 ESCOLHA UMA OPÇÃO E COLE NO TERMINAL

---

## ✅ OPÇÃO 1: VERCEL (MAIS COMPLETO)

### **Passo 1: Instalar e Deploy**

Copie e cole no terminal:

```bash
npm install -g vercel && vercel
```

### **Passo 2: Baixar ZIP**

1. Acesse: https://vercel.com/dashboard
2. Clique no projeto **cryptosell**
3. Settings → Git → Visit Repository
4. No GitHub: **Code** → **Download ZIP**

---

## ✅ OPÇÃO 2: SCRIPT AUTOMÁTICO (MAIS RÁPIDO)

### **Linux/Mac:**

Copie e cole no terminal:

```bash
chmod +x create-zip.sh && ./create-zip.sh
```

### **Windows PowerShell:**

Copie e cole no PowerShell:

```powershell
.\create-zip.bat
```

---

## ✅ OPÇÃO 3: GIT BUNDLE

Copie e cole no terminal:

```bash
git init && git add . && git commit -m "CryptoSell completo" && git bundle create cryptosell.bundle --all
```

**Para extrair depois:**

```bash
git clone cryptosell.bundle cryptosell-extracted && cd cryptosell-extracted
```

---

## ✅ OPÇÃO 4: CRIAR ZIP MANUAL (SEM SCRIPTS)

### **Linux/Mac:**

```bash
zip -r cryptosell-$(date +%Y%m%d-%H%M%S).zip . -x "node_modules/*" ".git/*" ".next/*"
```

### **Windows PowerShell:**

```powershell
$date = Get-Date -Format "yyyyMMdd-HHmmss"
Compress-Archive -Path . -DestinationPath "cryptosell-$date.zip" -Force
```

---

## 📥 EXTRAIR O ZIP

### **Linux/Mac:**

```bash
unzip cryptosell-*.zip -d cryptosell-extracted && cd cryptosell-extracted
```

### **Windows PowerShell:**

```powershell
Expand-Archive -Path cryptosell-*.zip -DestinationPath cryptosell-extracted
cd cryptosell-extracted
```

---

## 🔧 CONFIGURAR .ENV.LOCAL

Copie e cole no terminal:

### **Linux/Mac:**

```bash
cat > .env.local << 'EOF'
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml
NEXT_PUBLIC_APP_URL=http://localhost:3000
EOF
```

### **Windows PowerShell:**

```powershell
@"
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml
NEXT_PUBLIC_APP_URL=http://localhost:3000
"@ | Out-File -FilePath .env.local -Encoding utf8
```

---

## 🚀 INSTALAR E RODAR

Copie e cole no terminal:

```bash
npm install && npm run dev
```

**Abrir:** http://localhost:3000

---

## 🔍 VERIFICAR SE ESTÁ COMPLETO

Copie e cole no terminal:

```bash
echo "📊 Verificando arquivos..." && \
echo "Arquivos principais:" && \
ls -la | grep -E '(package.json|App.tsx|.env.local)' && \
echo "" && \
echo "Componentes: $(ls components/*.tsx 2>/dev/null | wc -l)" && \
echo "Componentes UI: $(ls components/ui/*.tsx 2>/dev/null | wc -l)" && \
echo "Dados: $(ls data/*.ts 2>/dev/null | wc -l)" && \
echo "APIs: $(ls pages/api/*.js 2>/dev/null | wc -l)" && \
echo "" && \
echo "Total de arquivos: $(find . -type f -not -path '*/node_modules/*' -not -path '*/.git/*' | wc -l)"
```

---

## 📦 CRIAR BACKUP COMPLETO

Copie e cole no terminal:

```bash
echo "📦 Criando backup completo..." && \
BACKUP_NAME="cryptosell-backup-$(date +%Y%m%d-%H%M%S).tar.gz" && \
tar -czf $BACKUP_NAME \
  --exclude='node_modules' \
  --exclude='.next' \
  --exclude='.git' \
  --exclude='*.log' \
  . && \
echo "✅ Backup criado: $BACKUP_NAME" && \
ls -lh $BACKUP_NAME
```

---

## 🔄 ATUALIZAR DEPENDÊNCIAS

Copie e cole no terminal:

```bash
npm install && npm update && npm audit fix
```

---

## 🧪 TESTAR SE ESTÁ FUNCIONANDO

Copie e cole no terminal:

```bash
echo "🧪 Testando aplicação..." && \
npm run dev &
sleep 5 && \
curl http://localhost:3000 > /dev/null 2>&1 && \
echo "✅ Servidor funcionando em http://localhost:3000" || \
echo "❌ Erro ao iniciar servidor"
```

---

## 🌐 DEPLOY RÁPIDO

### **Vercel:**

```bash
npm i -g vercel && vercel --prod
```

### **Netlify:**

```bash
npm i -g netlify-cli && netlify deploy --prod
```

---

## 🗑️ LIMPAR PROJETO

Copie e cole no terminal:

```bash
rm -rf node_modules .next && npm install && npm run dev
```

---

## 📊 VER TAMANHO DO PROJETO

Copie e cole no terminal:

```bash
echo "📊 Tamanho do projeto:" && \
echo "" && \
echo "Código fonte (sem node_modules):" && \
du -sh --exclude=node_modules --exclude=.next . && \
echo "" && \
echo "node_modules:" && \
du -sh node_modules 2>/dev/null || echo "Não instalado" && \
echo "" && \
echo "Total de linhas de código:" && \
find . -name '*.tsx' -o -name '*.ts' -o -name '*.js' | \
  grep -v node_modules | \
  xargs wc -l | \
  tail -1
```

---

## 🔐 VERIFICAR SEGURANÇA

Copie e cole no terminal:

```bash
echo "🔐 Verificando segurança..." && \
echo "" && \
echo "✅ Verificando .gitignore:" && \
grep -q ".env.local" .gitignore && echo "✅ .env.local está protegido" || echo "❌ .env.local NÃO está protegido" && \
echo "" && \
echo "✅ Verificando .env.local:" && \
test -f .env.local && echo "✅ .env.local existe" || echo "❌ .env.local NÃO existe" && \
echo "" && \
echo "✅ Verificando chaves Stripe:" && \
grep -q "STRIPE_SECRET_KEY" .env.local && echo "✅ STRIPE_SECRET_KEY configurada" || echo "❌ STRIPE_SECRET_KEY NÃO configurada" && \
echo "" && \
npm audit
```

---

## 🎯 TUDO EM UM COMANDO

### **Setup Completo (Linux/Mac):**

```bash
echo "🚀 Setup completo do CryptoSell..." && \
npm install && \
cat > .env.local << 'EOF'
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml
NEXT_PUBLIC_APP_URL=http://localhost:3000
EOF
echo "✅ Setup completo!" && \
echo "🚀 Iniciando servidor..." && \
npm run dev
```

### **Setup Completo (Windows PowerShell):**

```powershell
Write-Host "🚀 Setup completo do CryptoSell..." -ForegroundColor Green
npm install
@"
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51SWaWl2LGS9T5sQaTfAcXt8sa1wcpVxEnyskC6UF7WwmdQM8XoUU2akTFZzaxiSrAM8iEI0EfNinjRi4KMeCgVn200b1K8v9Ml
NEXT_PUBLIC_APP_URL=http://localhost:3000
"@ | Out-File -FilePath .env.local -Encoding utf8
Write-Host "✅ Setup completo!" -ForegroundColor Green
Write-Host "🚀 Iniciando servidor..." -ForegroundColor Green
npm run dev
```

---

## 📋 CHECKLIST COMPLETO

Copie e cole no terminal:

```bash
echo "📋 Checklist de arquivos:" && \
echo "" && \
echo "Configuração:" && \
test -f package.json && echo "✅ package.json" || echo "❌ package.json" && \
test -f .env.local && echo "✅ .env.local" || echo "❌ .env.local" && \
test -f .gitignore && echo "✅ .gitignore" || echo "❌ .gitignore" && \
test -f tsconfig.json && echo "✅ tsconfig.json" || echo "❌ tsconfig.json" && \
echo "" && \
echo "Aplicação:" && \
test -f App.tsx && echo "✅ App.tsx" || echo "❌ App.tsx" && \
echo "" && \
echo "Backend:" && \
test -f pages/api/create-payment-intent.js && echo "✅ API Backend" || echo "❌ API Backend" && \
echo "" && \
echo "Componentes:" && \
test -f components/BuyCryptoV3.tsx && echo "✅ BuyCryptoV3" || echo "❌ BuyCryptoV3" && \
test -f components/StripeCheckout.tsx && echo "✅ StripeCheckout" || echo "❌ StripeCheckout" && \
echo "" && \
echo "Dados:" && \
test -f data/cryptoData.ts && echo "✅ cryptoData" || echo "❌ cryptoData" && \
test -f data/banks.ts && echo "✅ banks" || echo "❌ banks"
```

---

## 🎉 COMANDO FINAL

**Copie este comando para ter tudo funcionando:**

```bash
npm i -g vercel && vercel
```

**OU (se preferir local):**

```bash
npm install && npm run dev
```

---

## 📚 RESUMO DOS COMANDOS

| Ação | Comando |
|------|---------|
| **Criar ZIP** | `./create-zip.sh` |
| **Deploy Vercel** | `vercel` |
| **Instalar** | `npm install` |
| **Rodar** | `npm run dev` |
| **Setup Completo** | Ver "TUDO EM UM COMANDO" acima |
| **Verificar** | Ver "CHECKLIST COMPLETO" acima |
| **Backup** | Ver "CRIAR BACKUP COMPLETO" acima |

---

✅ **TODOS OS COMANDOS PRONTOS!**  
✅ **BASTA COPIAR E COLAR!**  
✅ **SEM EDITAR NADA!**

**Escolha um comando acima e execute agora!** 🚀
