# 📥 COMO BAIXAR O PROJETO CRYPTOSELL

## MÉTODO RÁPIDO: Botão Export do Figma Make

### Passo 1: Localize o Botão
Procure no **canto superior direito** da interface do Figma Make:
- 🔽 Botão "Export"
- 📥 Botão "Download" 
- ⚙️ Menu "..." → "Export project"
- 📦 "Download as ZIP"

### Passo 2: Clique e Baixe
1. Clique no botão
2. Aguarde o ZIP ser gerado
3. Salve o arquivo no seu computador
4. Extraia o ZIP

### Passo 3: Instale e Rode
```bash
cd cryptosell
npm install
npm run dev
```

---

## SE NÃO HOUVER BOTÃO DE EXPORT

### MÉTODO MANUAL: Copiar Arquivo por Arquivo

#### 1. Crie a estrutura de pastas:
```
cryptosell/
├── components/
│   ├── ui/
│   ├── AboutUs.tsx
│   ├── BuyCryptoPage.tsx
│   ├── CardPayment.tsx
│   ├── ContactSupport.tsx
│   ├── LanguageSelector.tsx
│   ├── PaymentMethodSelector.tsx
│   ├── PaymentOptions.tsx
│   ├── PixPayment.tsx
│   ├── QRCodeGenerator.tsx
│   ├── SecurityBadges.tsx
│   ├── StatsBar.tsx
│   └── StripePaymentLink.tsx
├── hooks/
│   └── useLocalization.ts
├── utils/
│   └── i18n/
│       ├── languages.ts
│       └── translations.ts
├── data/
│   ├── banks.ts
│   ├── bankLogos.ts
│   └── cryptoData.ts
├── styles/
│   └── globals.css
├── App.tsx
├── package.json
└── next.config.js
```

#### 2. Copie cada arquivo:
No painel lateral esquerdo do Figma Make:
1. Clique no arquivo
2. Selecione todo o código (Ctrl+A / Cmd+A)
3. Copie (Ctrl+C / Cmd+C)
4. Cole no seu editor de texto
5. Salve com o mesmo nome e extensão

#### 3. Arquivos ESSENCIAIS (28 no total):

**Arquivo Principal:**
- ✅ App.tsx

**Componentes (12):**
- ✅ components/AboutUs.tsx
- ✅ components/BuyCryptoPage.tsx
- ✅ components/CardPayment.tsx
- ✅ components/ContactSupport.tsx
- ✅ components/LanguageSelector.tsx
- ✅ components/PaymentMethodSelector.tsx
- ✅ components/PaymentOptions.tsx
- ✅ components/PixPayment.tsx
- ✅ components/QRCodeGenerator.tsx
- ✅ components/SecurityBadges.tsx
- ✅ components/StatsBar.tsx
- ✅ components/StripePaymentLink.tsx

**Componentes UI (10 principais):**
- ✅ components/ui/button.tsx
- ✅ components/ui/card.tsx
- ✅ components/ui/select.tsx
- ✅ components/ui/input.tsx
- ✅ components/ui/label.tsx
- ✅ components/ui/badge.tsx
- ✅ components/ui/progress.tsx
- ✅ components/ui/tooltip.tsx
- ✅ components/ui/dialog.tsx
- ✅ components/ui/sonner.tsx

**Internacionalização (3):**
- ✅ utils/i18n/languages.ts
- ✅ utils/i18n/translations.ts
- ✅ hooks/useLocalization.ts

**Estilos:**
- ✅ styles/globals.css

**Configuração:**
- ✅ package.json
- ✅ next.config.js (se existir)

---

## MÉTODO ALTERNATIVO: Deploy Online

Se você só precisa que o site funcione online:

### Opção 1: Deploy no Figma Make
- Clique em "Publish" ou "Deploy"
- Receba um link público
- Pronto! Sem precisar baixar

### Opção 2: Netlify Drop
1. Vá em [app.netlify.com/drop](https://app.netlify.com/drop)
2. Arraste a pasta do projeto
3. Deploy instantâneo e grátis

### Opção 3: Vercel
1. Vá em [vercel.com](https://vercel.com)
2. Clique em "Import Project"
3. Deploy grátis

---

## 📦 PACKAGE.JSON

Crie este arquivo na raiz do projeto:

```json
{
  "name": "cryptosell",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "next": "^14.0.0",
    "lucide-react": "latest",
    "qrcode.react": "latest",
    "sonner": "2.0.3",
    "tailwindcss": "^4.0.0",
    "class-variance-authority": "latest",
    "clsx": "latest",
    "tailwind-merge": "latest"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "typescript": "^5.0.0"
  }
}
```

---

## ⚡ COMANDOS APÓS BAIXAR

```bash
# 1. Entre na pasta do projeto
cd cryptosell

# 2. Instale as dependências
npm install

# 3. Rode em desenvolvimento
npm run dev

# 4. Acesse no navegador
http://localhost:3000
```

---

## ✅ CHECKLIST FINAL

- [ ] Todos os 28 arquivos copiados
- [ ] Estrutura de pastas criada corretamente
- [ ] package.json criado
- [ ] npm install executado
- [ ] npm run dev funcionando
- [ ] Site abrindo em http://localhost:3000

---

## 🆘 SUPORTE

Se tiver problemas:
1. Verifique se todos os arquivos foram copiados
2. Confirme que package.json está correto
3. Execute `npm install` novamente
4. Delete a pasta `node_modules` e tente novamente

**Seu CryptoSell está pronto para funcionar! 🚀**
