import { useState } from 'react';
import { Info, Globe, Clock, Shield, Users, TrendingUp, Lock, CheckCircle2, X } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Badge } from './ui/badge';

export default function AboutUs() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        variant="ghost"
        size="sm"
        className="text-gray-400 hover:text-white hover:bg-gray-800/50 transition-all"
      >
        <Info className="h-4 w-4 mr-2" />
        Sobre Nós
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-gray-900/95 to-gray-950/95 border-amber-500/20 backdrop-blur-xl">
          <DialogHeader>
            <div className="flex items-center justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full blur-xl opacity-50 animate-pulse" />
                <div className="h-16 w-16 rounded-xl bg-gradient-to-br from-amber-500 via-orange-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/50 relative z-10">
                  <Lock className="h-8 w-8 text-white" />
                </div>
              </div>
            </div>
            <DialogTitle className="text-center text-white text-3xl mb-2">Sobre a CryptoSell</DialogTitle>
            <DialogDescription className="text-center text-amber-400/80">
              Sua plataforma global de confiança para ativos digitais
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 mt-6">
            {/* Missão Principal */}
            <div className="p-6 bg-gradient-to-br from-gray-800/40 to-gray-900/40 border border-gray-700/50 rounded-xl backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-amber-500/30">
                  <TrendingUp className="h-5 w-5 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white mb-3">Quem Somos</h3>
                  <p className="text-gray-300 leading-relaxed">
                    Somos uma plataforma global especializada na compra e venda de ativos digitais, oferecendo soluções rápidas, seguras e acessíveis para clientes em mais de 200 países. Atuamos com múltiplas moedas, criptomoedas e ativos do mundo real, proporcionando uma experiência completa de conversão financeira internacional.
                  </p>
                </div>
              </div>
            </div>

            {/* Objetivo */}
            <div className="p-6 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-xl backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                  <Globe className="h-5 w-5 text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white mb-3">Nosso Objetivo</h3>
                  <p className="text-gray-300 leading-relaxed">
                    Entregar um sistema moderno, ágil e transparente, permitindo que investidores e parceiros realizem transações de criptoativos, pagamentos internacionais e liquidações com alta eficiência e liquidez.
                  </p>
                </div>
              </div>
            </div>

            {/* Cobertura Global */}
            <div className="p-6 bg-gradient-to-br from-gray-800/40 to-gray-900/40 border border-gray-700/50 rounded-xl backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-green-500/30">
                  <Globe className="h-5 w-5 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white mb-4">Cobertura Global</h3>
                  <p className="text-gray-300 mb-4 leading-relaxed">
                    Trabalhamos com operações em todos os continentes:
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {[
                      'América do Sul',
                      'América do Norte',
                      'Europa',
                      'África',
                      'Ásia',
                      'Oceania'
                    ].map((region) => (
                      <div key={region} className="flex items-center gap-2 p-3 bg-gray-800/50 rounded-lg border border-gray-700/30">
                        <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm text-gray-300">{region}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Prazos e Liquidez */}
            <div className="p-6 bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                  <Clock className="h-5 w-5 text-purple-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white mb-3">Prazos e Eficiência</h3>
                  <p className="text-gray-300 leading-relaxed mb-4">
                    Os prazos de liquidação variam conforme bancos e moedas locais, garantindo entregas entre <span className="text-amber-400">24 e 36 horas</span>, sempre respeitando processos de segurança e compliance dos parceiros financeiros.
                  </p>
                  <div className="flex items-center gap-2 p-3 bg-purple-500/10 rounded-lg border border-purple-500/20">
                    <TrendingUp className="h-5 w-5 text-purple-400" />
                    <span className="text-sm text-purple-300">Alta liquidez para nossos clientes, investidores e parceiros</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Segurança e Privacidade */}
            <div className="p-6 bg-gradient-to-br from-gray-800/40 to-gray-900/40 border border-amber-500/20 rounded-xl backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-amber-500/30">
                  <Shield className="h-5 w-5 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white mb-3">Segurança e Privacidade</h3>
                  <p className="text-gray-300 leading-relaxed mb-4">
                    Oferecemos um <span className="text-amber-400">modo anônimo</span> como diferencial, permitindo transações com maior privacidade e remoção automática de registros não essenciais.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="flex items-center gap-2 p-3 bg-gray-800/50 rounded-lg border border-gray-700/30">
                      <Lock className="h-4 w-4 text-amber-500" />
                      <span className="text-sm text-gray-300">Criptografia AES-256</span>
                    </div>
                    <div className="flex items-center gap-2 p-3 bg-gray-800/50 rounded-lg border border-gray-700/30">
                      <Shield className="h-4 w-4 text-green-500" />
                      <span className="text-sm text-gray-300">PCI DSS Compliant</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Call to Action */}
            <div className="p-6 bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-orange-600/20 border border-amber-500/30 rounded-xl backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-amber-500/30">
                  <Users className="h-5 w-5 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white mb-3">Junte-se a Nós</h3>
                  <p className="text-gray-300 leading-relaxed mb-4">
                    Somos comprometidos com <span className="text-amber-400">inovação, segurança e integração global</span>. Seja um cliente ou parceiro do nosso projeto e experimente um novo padrão em soluções de pagamento, compra e venda de ativos digitais e conversões internacionais.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                      Inovação
                    </Badge>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      Segurança
                    </Badge>
                    <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                      Global
                    </Badge>
                    <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                      Alta Liquidez
                    </Badge>
                  </div>
                </div>
              </div>
            </div>

            {/* Estatísticas */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700/50 text-center">
                <div className="text-2xl text-amber-500 mb-1">200+</div>
                <div className="text-xs text-gray-400">Países Atendidos</div>
              </div>
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700/50 text-center">
                <div className="text-2xl text-green-500 mb-1">50+</div>
                <div className="text-xs text-gray-400">Redes Blockchain</div>
              </div>
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700/50 text-center">
                <div className="text-2xl text-blue-500 mb-1">24-36h</div>
                <div className="text-xs text-gray-400">Tempo de Liquidação</div>
              </div>
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700/50 text-center">
                <div className="text-2xl text-purple-500 mb-1">24/7</div>
                <div className="text-xs text-gray-400">Suporte</div>
              </div>
            </div>
          </div>

          <div className="mt-6 flex justify-center">
            <Button
              onClick={() => setIsOpen(false)}
              className="bg-gradient-to-r from-amber-500 via-orange-500 to-orange-600 hover:from-amber-600 hover:via-orange-600 hover:to-orange-700 text-white shadow-lg shadow-amber-500/30 transition-all duration-300"
            >
              <X className="h-4 w-4 mr-2" />
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
