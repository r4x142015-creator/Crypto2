import { useState } from 'react';
import { Mail, Send, HelpCircle, Users, LifeBuoy, CheckCircle2, X, Copy } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { toast } from 'sonner@2.0.3';

export default function ContactSupport() {
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copied, setCopied] = useState('');

  const contactEmails = [
    {
      title: 'Ajuda & Suporte',
      email: 'cryptosell@help.com',
      description: 'Dúvidas gerais, problemas técnicos e assistência',
      icon: HelpCircle,
      color: 'blue',
      gradient: 'from-blue-500 to-cyan-600'
    },
    {
      title: 'Investidores',
      email: 'cryptosell@investing.com',
      description: 'Oportunidades de investimento e parcerias estratégicas',
      icon: Users,
      color: 'green',
      gradient: 'from-green-500 to-emerald-600'
    },
    {
      title: 'Suporte Técnico',
      email: 'cryptosell@suporte.com',
      description: 'Suporte prioritário para transações e contas',
      icon: LifeBuoy,
      color: 'amber',
      gradient: 'from-amber-500 to-orange-600'
    }
  ];

  const copyEmail = async (email: string) => {
    try {
      await navigator.clipboard.writeText(email);
      setCopied(email);
      toast.success('Email copiado!', {
        description: `${email} foi copiado para a área de transferência.`,
      });
      setTimeout(() => setCopied(''), 2000);
    } catch (err) {
      toast.error('Erro ao copiar', {
        description: 'Não foi possível copiar o email.',
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !reason) {
      toast.error('Campos obrigatórios', {
        description: 'Por favor, preencha todos os campos.',
      });
      return;
    }

    if (!email.includes('@') || !email.includes('.')) {
      toast.error('Email inválido', {
        description: 'Por favor, insira um email válido.',
      });
      return;
    }

    setIsSubmitting(true);

    // Simular envio
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success('Email enviado com sucesso!', {
        description: 'Nossa equipe entrará em contato em breve. Tempo médio de resposta: 2-4 horas.',
        duration: 5000,
      });
      
      // Limpar formulário
      setEmail('');
      setReason('');
    }, 1500);
  };

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        variant="ghost"
        size="sm"
        className="text-gray-400 hover:text-white hover:bg-gray-800/50 transition-all"
      >
        <Mail className="h-4 w-4 mr-2" />
        Suporte
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-gray-900/95 to-gray-950/95 border-amber-500/20 backdrop-blur-xl">
          <DialogHeader>
            <div className="flex items-center justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-full blur-xl opacity-50 animate-pulse" />
                <div className="h-16 w-16 rounded-xl bg-gradient-to-br from-blue-500 via-cyan-500 to-cyan-600 flex items-center justify-center shadow-lg shadow-blue-500/50 relative z-10">
                  <Mail className="h-8 w-8 text-white" />
                </div>
              </div>
            </div>
            <DialogTitle className="text-center text-white text-3xl mb-2">Suporte & Contato</DialogTitle>
            <DialogDescription className="text-center text-blue-400/80">
              Estamos aqui para ajudar você 24/7
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-8 mt-6">
            {/* Canais de Contato Direto */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Mail className="h-5 w-5 text-blue-400" />
                <h3 className="text-white text-xl">Contatos Diretos</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {contactEmails.map((contact) => {
                  const Icon = contact.icon;
                  return (
                    <div
                      key={contact.email}
                      className={`p-5 bg-gradient-to-br from-gray-800/40 to-gray-900/40 border border-${contact.color}-500/20 rounded-xl backdrop-blur-sm hover:border-${contact.color}-500/40 transition-all duration-300 hover:scale-[1.02]`}
                    >
                      <div className="flex items-start gap-3 mb-4">
                        <div className={`h-10 w-10 rounded-lg bg-gradient-to-br ${contact.gradient} flex items-center justify-center flex-shrink-0 shadow-lg shadow-${contact.color}-500/30`}>
                          <Icon className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-white mb-1">{contact.title}</h4>
                          <p className="text-xs text-gray-400 leading-relaxed">
                            {contact.description}
                          </p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className={`p-3 bg-gray-950/50 border border-${contact.color}-500/20 rounded-lg`}>
                          <p className="text-xs text-gray-500 mb-1">Email</p>
                          <p className={`text-sm text-${contact.color}-400 font-mono break-all`}>
                            {contact.email}
                          </p>
                        </div>

                        <div className="flex gap-2">
                          <a
                            href={`mailto:${contact.email}`}
                            className="flex-1"
                          >
                            <Button
                              size="sm"
                              className={`w-full bg-${contact.color}-500/20 text-${contact.color}-400 border border-${contact.color}-500/30 hover:bg-${contact.color}-500/30 transition-all`}
                            >
                              <Send className="h-3 w-3 mr-1" />
                              Enviar
                            </Button>
                          </a>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => copyEmail(contact.email)}
                            className={`border-${contact.color}-500/30 hover:bg-${contact.color}-500/10`}
                          >
                            {copied === contact.email ? (
                              <CheckCircle2 className="h-3 w-3 text-green-500" />
                            ) : (
                              <Copy className="h-3 w-3" />
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Divisor */}
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-800"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-gray-900 px-4 text-gray-500">ou</span>
              </div>
            </div>

            {/* Formulário de Contato */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Send className="h-5 w-5 text-amber-400" />
                <h3 className="text-white text-xl">Formulário de Contato</h3>
              </div>

              <div className="p-6 bg-gradient-to-br from-gray-800/40 to-gray-900/40 border border-amber-500/20 rounded-xl backdrop-blur-sm">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="contact-email" className="text-white flex items-center gap-2">
                      <Mail className="h-4 w-4 text-amber-500" />
                      Seu Email
                    </Label>
                    <Input
                      id="contact-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu.email@exemplo.com"
                      className="bg-gray-950/50 border-gray-700 text-white h-12 hover:border-amber-500/50 transition-colors focus:border-amber-500"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reason" className="text-white flex items-center gap-2">
                      <HelpCircle className="h-4 w-4 text-amber-500" />
                      Motivo do Contato
                    </Label>
                    <Textarea
                      id="reason"
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      placeholder="Descreva o motivo do seu contato, suas dúvidas ou como podemos ajudar..."
                      className="bg-gray-950/50 border-gray-700 text-white min-h-[120px] hover:border-amber-500/50 transition-colors focus:border-amber-500 resize-none"
                      required
                    />
                  </div>

                  <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-xl">
                    <div className="h-8 w-8 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                      <CheckCircle2 className="h-4 w-4 text-blue-400" />
                    </div>
                    <div className="text-sm text-blue-300">
                      <p className="font-semibold mb-1">Tempo de Resposta</p>
                      <p className="text-xs text-blue-200/80">
                        Nossa equipe responde em até 2-4 horas durante horário comercial (24/7 para casos urgentes)
                      </p>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full h-14 bg-gradient-to-r from-amber-500 via-orange-500 to-orange-600 hover:from-amber-600 hover:via-orange-600 hover:to-orange-700 text-white shadow-lg shadow-amber-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/40 hover:scale-[1.02] disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5 mr-2" />
                        Enviar Mensagem
                      </>
                    )}
                  </Button>
                </form>
              </div>
            </div>

            {/* Informações Adicionais */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700/50 text-center">
                <div className="text-2xl text-blue-500 mb-1">24/7</div>
                <div className="text-xs text-gray-400">Suporte Disponível</div>
              </div>
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700/50 text-center">
                <div className="text-2xl text-green-500 mb-1">2-4h</div>
                <div className="text-xs text-gray-400">Tempo de Resposta</div>
              </div>
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700/50 text-center">
                <div className="text-2xl text-amber-500 mb-1">200+</div>
                <div className="text-xs text-gray-400">Países Atendidos</div>
              </div>
            </div>

            {/* Políticas */}
            <div className="p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl">
              <div className="flex items-start gap-3">
                <div className="h-8 w-8 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                  <CheckCircle2 className="h-4 w-4 text-purple-400" />
                </div>
                <div className="text-sm text-purple-300">
                  <p className="font-semibold mb-1">Privacidade Garantida</p>
                  <p className="text-xs text-purple-200/80">
                    Todas as comunicações são criptografadas e mantidas confidenciais. Nunca compartilharemos suas informações.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 flex justify-center">
            <Button
              onClick={() => setIsOpen(false)}
              variant="outline"
              className="border-gray-700 text-gray-400 hover:bg-gray-800/50 hover:text-white transition-all"
            >
              <X className="h-4 w-4 mr-2" />
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
