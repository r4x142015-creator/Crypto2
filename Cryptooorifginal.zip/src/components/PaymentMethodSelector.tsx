import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { CreditCard, Zap, QrCode, Shield } from 'lucide-react';

interface PaymentMethodSelectorProps {
  onSelectMethod: (method: 'pix' | 'card') => void;
}

export default function PaymentMethodSelector({ onSelectMethod }: PaymentMethodSelectorProps) {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-white text-2xl font-bold">Como deseja pagar?</h2>
        <p className="text-gray-400 text-sm">Escolha o método de pagamento</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* PIX */}
        <Card 
          className="relative overflow-hidden border-2 border-teal-500/30 bg-gradient-to-br from-teal-500/10 to-cyan-500/10 hover:border-teal-500/60 transition-all duration-300 hover:scale-[1.02] cursor-pointer group"
          onClick={() => onSelectMethod('pix')}
        >
          <CardContent className="p-6 space-y-4">
            <div className="flex items-start justify-between">
              <div className="h-14 w-14 rounded-xl bg-teal-500/20 flex items-center justify-center flex-shrink-0">
                <QrCode className="h-8 w-8 text-teal-400" />
              </div>
              <Badge className="bg-teal-500/20 text-teal-400 border-teal-500/30">
                Instantâneo
              </Badge>
            </div>

            <div className="space-y-2">
              <h3 className="text-white text-xl font-bold flex items-center gap-2">
                PIX
                <Zap className="h-5 w-5 text-teal-400" />
              </h3>
              <p className="text-teal-200/80 text-sm">
                Pagamento instantâneo via QR Code ou Cópia e Cola
              </p>
            </div>

            <div className="space-y-2 pt-2 border-t border-teal-500/20">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">Processamento:</span>
                <span className="text-teal-400 font-semibold">Imediato</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">Taxa:</span>
                <span className="text-teal-400 font-semibold">0%</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">Disponível:</span>
                <span className="text-teal-400 font-semibold">24/7</span>
              </div>
            </div>

            <Button 
              className="w-full h-12 bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-600 hover:to-cyan-700 text-white shadow-lg shadow-teal-500/30 transition-all duration-300"
            >
              Pagar com PIX
            </Button>

            <div className="flex items-center justify-center gap-2 text-xs text-teal-300">
              <Shield className="h-3 w-3" />
              <span>Seguro e Verificado</span>
            </div>
          </CardContent>
        </Card>

        {/* Cartão de Crédito */}
        <Card 
          className="relative overflow-hidden border-2 border-blue-500/30 bg-gradient-to-br from-blue-500/10 to-indigo-500/10 hover:border-blue-500/60 transition-all duration-300 hover:scale-[1.02] cursor-pointer group"
          onClick={() => onSelectMethod('card')}
        >
          <CardContent className="p-6 space-y-4">
            <div className="flex items-start justify-between">
              <div className="h-14 w-14 rounded-xl bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                <CreditCard className="h-8 w-8 text-blue-400" />
              </div>
              <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                Global
              </Badge>
            </div>

            <div className="space-y-2">
              <h3 className="text-white text-xl font-bold flex items-center gap-2">
                Cartão de Crédito
              </h3>
              <p className="text-blue-200/80 text-sm">
                Visa, Mastercard, Amex e outros métodos
              </p>
            </div>

            <div className="space-y-2 pt-2 border-t border-blue-500/20">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">Processamento:</span>
                <span className="text-blue-400 font-semibold">1-3 dias</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">Parcelamento:</span>
                <span className="text-blue-400 font-semibold">Até 12x</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">Moedas:</span>
                <span className="text-blue-400 font-semibold">USD, EUR, BRL</span>
              </div>
            </div>

            <Button 
              className="w-full h-12 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-lg shadow-blue-500/30 transition-all duration-300"
            >
              Pagar com Cartão
            </Button>

            <div className="flex items-center justify-center gap-2 text-xs text-blue-300">
              <Shield className="h-3 w-3" />
              <span>Processado por Stripe</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Info */}
      <div className="p-4 bg-gray-900/50 border border-gray-700 rounded-xl">
        <div className="flex items-start gap-3">
          <Shield className="h-5 w-5 text-amber-400 flex-shrink-0 mt-0.5" />
          <div className="text-xs text-gray-300 space-y-1">
            <p className="font-semibold text-white">🔒 Pagamento 100% Seguro</p>
            <ul className="list-disc list-inside space-y-1 text-gray-400">
              <li>Criptografia SSL 256-bit em todas as transações</li>
              <li>Dados protegidos e nunca compartilhados</li>
              <li>Conformidade PCI DSS Level 1</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
