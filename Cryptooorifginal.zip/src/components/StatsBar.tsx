import { useEffect, useState } from 'react';
import { TrendingUp, Users, Zap, DollarSign } from 'lucide-react';

export default function StatsBar() {
  const [stats, setStats] = useState({
    transactions: 15234,
    users: 8456,
    volume: 2.4,
    uptime: 99.9
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        transactions: prev.transactions + Math.floor(Math.random() * 3),
        users: prev.users + Math.floor(Math.random() * 2),
        volume: prev.volume + (Math.random() * 0.1),
        uptime: 99.9
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const statItems = [
    {
      icon: TrendingUp,
      label: 'Transações Hoje',
      value: stats.transactions.toLocaleString('pt-BR'),
      color: 'text-green-400'
    },
    {
      icon: Users,
      label: 'Usuários Ativos',
      value: stats.users.toLocaleString('pt-BR'),
      color: 'text-blue-400'
    },
    {
      icon: DollarSign,
      label: 'Volume (M)',
      value: `R$ ${stats.volume.toFixed(1)}M`,
      color: 'text-amber-400'
    },
    {
      icon: Zap,
      label: 'Disponibilidade',
      value: `${stats.uptime}%`,
      color: 'text-purple-400'
    }
  ];

  return (
    <div className="bg-gray-950/50 border-b border-gray-800/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {statItems.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div
                key={index}
                className="flex items-center gap-3 p-3 bg-gray-900/30 rounded-lg border border-gray-800/50 hover:border-gray-700 transition-colors"
              >
                <div className={`h-10 w-10 rounded-lg bg-gray-800/50 flex items-center justify-center ${stat.color}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-gray-400">{stat.label}</p>
                  <p className={`font-semibold ${stat.color}`}>{stat.value}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
