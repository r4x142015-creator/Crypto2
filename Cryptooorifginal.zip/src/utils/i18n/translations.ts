// Sistema de traduções para todas as línguas
export const translations: Record<string, any> = {
  en: {
    header: {
      title: 'CryptoSell',
      subtitle: 'Premium Exchange • 500+ Cryptos',
      verified: 'Verified',
      secure: 'Secure',
      about: 'About Us',
      support: 'Support',
      info: '100% secure and verified platform'
    },
    navigation: {
      sell: 'Sell Crypto',
      buy: 'Buy Crypto'
    },
    steps: {
      chooseCrypto: 'Choose Crypto',
      chooseNetwork: 'Choose Network',
      finalize: 'Finalize'
    },
    crypto: {
      search: 'Search Cryptocurrency',
      searchPlaceholder: 'Type the cryptocurrency name...',
      available: 'available',
      selectCrypto: 'Cryptocurrency',
      continue: 'Continue to Next Step',
      secureTransaction: '100% Secure Transaction',
      secureDesc: 'All transactions are protected with end-to-end AES-256 encryption',
      fastProcessing: 'Fast Processing',
      networks: '50+ Networks',
      support247: '24/7 Support'
    },
    payment: {
      amount: 'Amount',
      enterAmount: 'Enter amount',
      paymentMethod: 'Payment Method',
      pix: 'PIX',
      card: 'Credit/Debit Card',
      bankBrazil: 'Brazilian Bank',
      bankInternational: 'International Bank',
      selectBank: 'Select Bank',
      selectRegion: 'Select Region',
      transactionId: 'Transaction ID',
      confirmSend: 'Confirm and Send Data',
      wallet: 'Wallet',
      copy: 'Copy',
      copied: 'Copied!',
      scanQR: 'Scan QR Code',
      minAmount: 'Minimum amount',
      countries: 'Countries'
    },
    footer: {
      premiumExchange: 'Premium Global Exchange',
      copyright: '© 2025 CryptoSell. All rights reserved. • Global platform for buying and selling digital assets.',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: '24h Volume',
      activeUsers: 'Active Users',
      transactions: 'Transactions Today',
      countries: 'Countries'
    }
  },
  
  'pt-br': {
    header: {
      title: 'CryptoSell',
      subtitle: 'Exchange Premium • 500+ Criptos',
      verified: 'Verificado',
      secure: 'Seguro',
      about: 'Sobre Nós',
      support: 'Suporte',
      info: 'Plataforma 100% segura e verificada'
    },
    navigation: {
      sell: 'Vender Cripto',
      buy: 'Comprar Cripto'
    },
    steps: {
      chooseCrypto: 'Escolher Cripto',
      chooseNetwork: 'Escolher Rede',
      finalize: 'Finalizar'
    },
    crypto: {
      search: 'Pesquisar Criptomoeda',
      searchPlaceholder: 'Digite o nome da criptomoeda...',
      available: 'disponíveis',
      selectCrypto: 'Criptomoeda',
      continue: 'Continuar para Próxima Etapa',
      secureTransaction: 'Transação 100% Segura',
      secureDesc: 'Todas as transações são protegidas com criptografia AES-256 de ponta a ponta',
      fastProcessing: 'Processamento Rápido',
      networks: '50+ Redes',
      support247: 'Suporte 24/7'
    },
    payment: {
      amount: 'Valor',
      enterAmount: 'Digite o valor',
      paymentMethod: 'Método de Pagamento',
      pix: 'PIX',
      card: 'Cartão de Crédito/Débito',
      bankBrazil: 'Banco Brasileiro',
      bankInternational: 'Banco Internacional',
      selectBank: 'Selecione o Banco',
      selectRegion: 'Selecione a Região',
      transactionId: 'ID da Transação',
      confirmSend: 'Confirmar e Enviar Dados',
      wallet: 'Carteira',
      copy: 'Copiar',
      copied: 'Copiado!',
      scanQR: 'Escanear QR Code',
      minAmount: 'Valor mínimo',
      countries: 'Países'
    },
    footer: {
      premiumExchange: 'Exchange Premium Global',
      copyright: '© 2025 CryptoSell. Todos os direitos reservados. • Plataforma global de compra e venda de ativos digitais.',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: 'Volume 24h',
      activeUsers: 'Usuários Ativos',
      transactions: 'Transações Hoje',
      countries: 'Países'
    }
  },
  
  es: {
    header: {
      title: 'CryptoSell',
      subtitle: 'Exchange Premium • 500+ Criptos',
      verified: 'Verificado',
      secure: 'Seguro',
      about: 'Sobre Nosotros',
      support: 'Soporte',
      info: 'Plataforma 100% segura y verificada'
    },
    navigation: {
      sell: 'Vender Cripto',
      buy: 'Comprar Cripto'
    },
    steps: {
      chooseCrypto: 'Elegir Cripto',
      chooseNetwork: 'Elegir Red',
      finalize: 'Finalizar'
    },
    crypto: {
      search: 'Buscar Criptomoneda',
      searchPlaceholder: 'Escribe el nombre de la criptomoneda...',
      available: 'disponibles',
      selectCrypto: 'Criptomoneda',
      continue: 'Continuar al Siguiente Paso',
      secureTransaction: 'Transacción 100% Segura',
      secureDesc: 'Todas las transacciones están protegidas con cifrado AES-256 de extremo a extremo',
      fastProcessing: 'Procesamiento Rápido',
      networks: '50+ Redes',
      support247: 'Soporte 24/7'
    },
    payment: {
      amount: 'Cantidad',
      enterAmount: 'Ingrese la cantidad',
      paymentMethod: 'Método de Pago',
      pix: 'PIX',
      card: 'Tarjeta de Crédito/Débito',
      bankBrazil: 'Banco Brasileño',
      bankInternational: 'Banco Internacional',
      selectBank: 'Seleccione el Banco',
      selectRegion: 'Seleccione la Región',
      transactionId: 'ID de Transacción',
      confirmSend: 'Confirmar y Enviar Datos',
      wallet: 'Billetera',
      copy: 'Copiar',
      copied: '¡Copiado!',
      scanQR: 'Escanear Código QR',
      minAmount: 'Cantidad mínima',
      countries: 'Países'
    },
    footer: {
      premiumExchange: 'Exchange Premium Global',
      copyright: '© 2025 CryptoSell. Todos los derechos reservados. • Plataforma global para comprar y vender activos digitales.',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: 'Volumen 24h',
      activeUsers: 'Usuarios Activos',
      transactions: 'Transacciones Hoy',
      countries: 'Países'
    }
  },
  
  fr: {
    header: {
      title: 'CryptoSell',
      subtitle: 'Exchange Premium • 500+ Cryptos',
      verified: 'Vérifié',
      secure: 'Sécurisé',
      about: 'À Propos',
      support: 'Support',
      info: 'Plateforme 100% sécurisée et vérifiée'
    },
    navigation: {
      sell: 'Vendre Crypto',
      buy: 'Acheter Crypto'
    },
    steps: {
      chooseCrypto: 'Choisir Crypto',
      chooseNetwork: 'Choisir Réseau',
      finalize: 'Finaliser'
    },
    crypto: {
      search: 'Rechercher Cryptomonnaie',
      searchPlaceholder: 'Tapez le nom de la cryptomonnaie...',
      available: 'disponibles',
      selectCrypto: 'Cryptomonnaie',
      continue: 'Continuer vers l\'Étape Suivante',
      secureTransaction: 'Transaction 100% Sécurisée',
      secureDesc: 'Toutes les transactions sont protégées par un chiffrement AES-256 de bout en bout',
      fastProcessing: 'Traitement Rapide',
      networks: '50+ Réseaux',
      support247: 'Support 24/7'
    },
    payment: {
      amount: 'Montant',
      enterAmount: 'Entrez le montant',
      paymentMethod: 'Méthode de Paiement',
      pix: 'PIX',
      card: 'Carte de Crédit/Débit',
      bankBrazil: 'Banque Brésilienne',
      bankInternational: 'Banque Internationale',
      selectBank: 'Sélectionnez la Banque',
      selectRegion: 'Sélectionnez la Région',
      transactionId: 'ID de Transaction',
      confirmSend: 'Confirmer et Envoyer les Données',
      wallet: 'Portefeuille',
      copy: 'Copier',
      copied: 'Copié!',
      scanQR: 'Scanner le Code QR',
      minAmount: 'Montant minimum',
      countries: 'Pays'
    },
    footer: {
      premiumExchange: 'Exchange Premium Global',
      copyright: '© 2025 CryptoSell. Tous droits réservés. • Plateforme mondiale d\'achat et de vente d\'actifs numériques.',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: 'Volume 24h',
      activeUsers: 'Utilisateurs Actifs',
      transactions: 'Transactions Aujourd\'hui',
      countries: 'Pays'
    }
  },
  
  de: {
    header: {
      title: 'CryptoSell',
      subtitle: 'Premium Exchange • 500+ Kryptos',
      verified: 'Verifiziert',
      secure: 'Sicher',
      about: 'Über Uns',
      support: 'Support',
      info: '100% sichere und verifizierte Plattform'
    },
    navigation: {
      sell: 'Krypto Verkaufen',
      buy: 'Krypto Kaufen'
    },
    steps: {
      chooseCrypto: 'Krypto Wählen',
      chooseNetwork: 'Netzwerk Wählen',
      finalize: 'Abschließen'
    },
    crypto: {
      search: 'Kryptowährung Suchen',
      searchPlaceholder: 'Geben Sie den Namen der Kryptowährung ein...',
      available: 'verfügbar',
      selectCrypto: 'Kryptowährung',
      continue: 'Weiter zum Nächsten Schritt',
      secureTransaction: '100% Sichere Transaktion',
      secureDesc: 'Alle Transaktionen sind mit End-to-End AES-256-Verschlüsselung geschützt',
      fastProcessing: 'Schnelle Verarbeitung',
      networks: '50+ Netzwerke',
      support247: '24/7 Support'
    },
    payment: {
      amount: 'Betrag',
      enterAmount: 'Betrag eingeben',
      paymentMethod: 'Zahlungsmethode',
      pix: 'PIX',
      card: 'Kredit-/Debitkarte',
      bankBrazil: 'Brasilianische Bank',
      bankInternational: 'Internationale Bank',
      selectBank: 'Bank Auswählen',
      selectRegion: 'Region Auswählen',
      transactionId: 'Transaktions-ID',
      confirmSend: 'Bestätigen und Daten Senden',
      wallet: 'Wallet',
      copy: 'Kopieren',
      copied: 'Kopiert!',
      scanQR: 'QR-Code Scannen',
      minAmount: 'Mindestbetrag',
      countries: 'Länder'
    },
    footer: {
      premiumExchange: 'Globaler Premium Exchange',
      copyright: '© 2025 CryptoSell. Alle Rechte vorbehalten. • Globale Plattform für den Kauf und Verkauf digitaler Vermögenswerte.',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: '24h Volumen',
      activeUsers: 'Aktive Benutzer',
      transactions: 'Transaktionen Heute',
      countries: 'Länder'
    }
  },
  
  zh: {
    header: {
      title: 'CryptoSell',
      subtitle: '高级交易所 • 500+ 加密货币',
      verified: '已验证',
      secure: '安全',
      about: '关于我们',
      support: '支持',
      info: '100% 安全且经过验证的平台'
    },
    navigation: {
      sell: '出售加密货币',
      buy: '购买加密货币'
    },
    steps: {
      chooseCrypto: '选择加密货币',
      chooseNetwork: '选择网络',
      finalize: '完成'
    },
    crypto: {
      search: '搜索加密货币',
      searchPlaceholder: '输入加密货币名称...',
      available: '可用',
      selectCrypto: '加密货币',
      continue: '继续下一步',
      secureTransaction: '100% 安全交易',
      secureDesc: '所有交易均受端到端 AES-256 加密保护',
      fastProcessing: '快速处理',
      networks: '50+ 网络',
      support247: '24/7 支持'
    },
    payment: {
      amount: '金额',
      enterAmount: '输入金额',
      paymentMethod: '付款方式',
      pix: 'PIX',
      card: '信用卡/借记卡',
      bankBrazil: '巴西银行',
      bankInternational: '国际银行',
      selectBank: '选择银行',
      selectRegion: '选择地区',
      transactionId: '交易ID',
      confirmSend: '确认并发送数据',
      wallet: '钱包',
      copy: '复制',
      copied: '已复制！',
      scanQR: '扫描二维码',
      minAmount: '最低金额',
      countries: '国家'
    },
    footer: {
      premiumExchange: '全球高级交易所',
      copyright: '© 2025 CryptoSell. 版权所有。• 买卖数字资产的全球平台。',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: '24小时交易量',
      activeUsers: '活跃用户',
      transactions: '今日交易',
      countries: '国家'
    }
  },
  
  ja: {
    header: {
      title: 'CryptoSell',
      subtitle: 'プレミアム取引所 • 500以上の暗号通貨',
      verified: '検証済み',
      secure: '安全',
      about: '私たちについて',
      support: 'サポート',
      info: '100%安全で検証されたプラットフォーム'
    },
    navigation: {
      sell: '暗号通貨を売る',
      buy: '暗号通貨を買う'
    },
    steps: {
      chooseCrypto: '暗号通貨を選択',
      chooseNetwork: 'ネットワークを選択',
      finalize: '完了'
    },
    crypto: {
      search: '暗号通貨を検索',
      searchPlaceholder: '暗号通貨名を入力...',
      available: '利用可能',
      selectCrypto: '暗号通貨',
      continue: '次のステップへ',
      secureTransaction: '100%安全な取引',
      secureDesc: 'すべての取引はエンドツーエンドAES-256暗号化で保護されています',
      fastProcessing: '高速処理',
      networks: '50以上のネットワーク',
      support247: '24時間365日サポート'
    },
    payment: {
      amount: '金額',
      enterAmount: '金額を入力',
      paymentMethod: '支払い方法',
      pix: 'PIX',
      card: 'クレジット/デビットカード',
      bankBrazil: 'ブラジルの銀行',
      bankInternational: '国際銀行',
      selectBank: '銀行を選択',
      selectRegion: '地域を選択',
      transactionId: '取引ID',
      confirmSend: '確認してデータを送信',
      wallet: 'ウォレット',
      copy: 'コピー',
      copied: 'コピーしました！',
      scanQR: 'QRコードをスキャン',
      minAmount: '最小金額',
      countries: '国'
    },
    footer: {
      premiumExchange: 'グローバルプレミアム取引所',
      copyright: '© 2025 CryptoSell. 無断複写・転載を禁じます。• デジタル資産の売買のためのグローバルプラットフォーム。',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: '24時間取引量',
      activeUsers: 'アクティブユーザー',
      transactions: '本日の取引',
      countries: '国'
    }
  },
  
  ru: {
    header: {
      title: 'CryptoSell',
      subtitle: 'Премиум Биржа • 500+ Крипто',
      verified: 'Проверено',
      secure: 'Безопасно',
      about: 'О Нас',
      support: 'Поддержка',
      info: '100% безопасная и проверенная платформа'
    },
    navigation: {
      sell: 'Продать Крипто',
      buy: 'Купить Крипто'
    },
    steps: {
      chooseCrypto: 'Выбрать Крипто',
      chooseNetwork: 'Выбрать Сеть',
      finalize: 'Завершить'
    },
    crypto: {
      search: 'Поиск Криптовалюты',
      searchPlaceholder: 'Введите название криптовалюты...',
      available: 'доступно',
      selectCrypto: 'Криптовалюта',
      continue: 'Продолжить к Следующему Шагу',
      secureTransaction: '100% Безопасная Транзакция',
      secureDesc: 'Все транзакции защищены сквозным шифрованием AES-256',
      fastProcessing: 'Быстрая Обработка',
      networks: '50+ Сетей',
      support247: 'Поддержка 24/7'
    },
    payment: {
      amount: 'Сумма',
      enterAmount: 'Введите сумму',
      paymentMethod: 'Способ Оплаты',
      pix: 'PIX',
      card: 'Кредитная/Дебетовая Карта',
      bankBrazil: 'Бразильский Банк',
      bankInternational: 'Международный Банк',
      selectBank: 'Выберите Банк',
      selectRegion: 'Выберите Регион',
      transactionId: 'ID Транзакции',
      confirmSend: 'Подтвердить и Отправить Данные',
      wallet: 'Кошелек',
      copy: 'Копировать',
      copied: 'Скопировано!',
      scanQR: 'Сканировать QR-Код',
      minAmount: 'Минимальная сумма',
      countries: 'Страны'
    },
    footer: {
      premiumExchange: 'Глобальная Премиум Биржа',
      copyright: '© 2025 CryptoSell. Все права защищены. • Глобальная платформа для покупки и продажи цифровых активов.',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: 'Объем 24ч',
      activeUsers: 'Активные Пользователи',
      transactions: 'Транзакции Сегодня',
      countries: 'Страны'
    }
  },
  
  ar: {
    header: {
      title: 'CryptoSell',
      subtitle: 'بورصة بريميوم • أكثر من 500 عملة مشفرة',
      verified: 'موثق',
      secure: 'آمن',
      about: 'عنا',
      support: 'الدعم',
      info: 'منصة آمنة وموثقة 100٪'
    },
    navigation: {
      sell: 'بيع العملات المشفرة',
      buy: 'شراء العملات المشفرة'
    },
    steps: {
      chooseCrypto: 'اختر العملة المشفرة',
      chooseNetwork: 'اختر الشبكة',
      finalize: 'إنهاء'
    },
    crypto: {
      search: 'البحث عن العملة المشفرة',
      searchPlaceholder: 'اكتب اسم العملة المشفرة...',
      available: 'متاح',
      selectCrypto: 'العملة المشفرة',
      continue: 'الانتقال إلى الخطوة التالية',
      secureTransaction: 'معاملة آمنة 100٪',
      secureDesc: 'جميع المعاملات محمية بتشفير AES-256 من طرف إلى طرف',
      fastProcessing: 'معالجة سريعة',
      networks: 'أكثر من 50 شبكة',
      support247: 'دعم على مدار الساعة'
    },
    payment: {
      amount: 'المبلغ',
      enterAmount: 'أدخل المبلغ',
      paymentMethod: 'طريقة الدفع',
      pix: 'PIX',
      card: 'بطاقة ائتمان/خصم',
      bankBrazil: 'بنك برازيلي',
      bankInternational: 'بنك دولي',
      selectBank: 'اختر البنك',
      selectRegion: 'اختر المنطقة',
      transactionId: 'معرف المعاملة',
      confirmSend: 'تأكيد وإرسال البيانات',
      wallet: 'المحفظة',
      copy: 'نسخ',
      copied: 'تم النسخ!',
      scanQR: 'مسح رمز الاستجابة السريعة',
      minAmount: 'الحد الأدنى للمبلغ',
      countries: 'الدول'
    },
    footer: {
      premiumExchange: 'بورصة بريميوم عالمية',
      copyright: '© 2025 CryptoSell. جميع الحقوق محفوظة. • منصة عالمية لشراء وبيع الأصول الرقمية.',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: 'الحجم 24 ساعة',
      activeUsers: 'المستخدمون النشطون',
      transactions: 'المعاملات اليوم',
      countries: 'الدول'
    }
  },
  
  hi: {
    header: {
      title: 'CryptoSell',
      subtitle: 'प्रीमियम एक्सचेंज • 500+ क्रिप्टो',
      verified: 'सत्यापित',
      secure: 'सुरक्षित',
      about: 'हमारे बारे में',
      support: 'सहायता',
      info: '100% सुरक्षित और सत्यापित प्लेटफ़ॉर्म'
    },
    navigation: {
      sell: 'क्रिप्टो बेचें',
      buy: 'क्रिप्टो खरीदें'
    },
    steps: {
      chooseCrypto: 'क्रिप्टो चुनें',
      chooseNetwork: 'नेटवर्क चुनें',
      finalize: 'अंतिम रूप दें'
    },
    crypto: {
      search: 'क्रिप्टोकरेंसी खोजें',
      searchPlaceholder: 'क्रिप्टोकरेंसी का नाम टाइप करें...',
      available: 'उपलब्ध',
      selectCrypto: 'क्रिप्टोकरेंसी',
      continue: 'अगले चरण पर जारी रखें',
      secureTransaction: '100% सुरक्षित लेनदेन',
      secureDesc: 'सभी लेनदेन एंड-टू-एंड AES-256 एन्क्रिप्शन से सुरक्षित हैं',
      fastProcessing: 'तेज़ प्रोसेसिंग',
      networks: '50+ नेटवर्क',
      support247: '24/7 सहायता'
    },
    payment: {
      amount: 'राशि',
      enterAmount: 'राशि दर्ज करें',
      paymentMethod: 'भुगतान विधि',
      pix: 'PIX',
      card: 'क्रेडिट/डेबिट कार्ड',
      bankBrazil: 'ब्राज़ीलियाई बैंक',
      bankInternational: 'अंतर्राष्ट्रीय बैंक',
      selectBank: 'बैंक चुनें',
      selectRegion: 'क्षेत्र चुनें',
      transactionId: 'लेनदेन आईडी',
      confirmSend: 'पुष्टि करें और डेटा भेजें',
      wallet: 'वॉलेट',
      copy: 'कॉपी करें',
      copied: 'कॉपी हो गया!',
      scanQR: 'QR कोड स्कैन करें',
      minAmount: 'न्यूनतम राशि',
      countries: 'देश'
    },
    footer: {
      premiumExchange: 'वैश्विक प्रीमियम एक्सचेंज',
      copyright: '© 2025 CryptoSell. सर्वाधिकार सुरक्षित। • डिजिटल संपत्तियों को खरीदने और बेचने के लिए वैश्विक प्लेटफ़ॉर्म।',
      pciCompliant: 'PCI DSS'
    },
    stats: {
      volume24h: '24 घंटे की मात्रा',
      activeUsers: 'सक्रिय उपयोगकर्ता',
      transactions: 'आज के लेनदेन',
      countries: 'देश'
    }
  },
};

// Função auxiliar para obter tradução
export function getTranslation(lang: string, key: string): string {
  const keys = key.split('.');
  let value: any = translations[lang] || translations.en;
  
  for (const k of keys) {
    value = value?.[k];
    if (!value) break;
  }
  
  return value || key;
}
