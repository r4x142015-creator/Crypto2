#!/bin/bash

# Script de Verificação do Sistema CryptoSell
# Verifica se tudo está configurado corretamente

echo "================================================"
echo "🔍 VERIFICANDO SISTEMA CRYPTOSELL"
echo "================================================"
echo ""

# Verificar Node.js
echo "📦 Verificando Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    echo "✅ Node.js instalado: $NODE_VERSION"
else
    echo "❌ Node.js não encontrado! Instale em: https://nodejs.org"
    exit 1
fi
echo ""

# Verificar npm
echo "📦 Verificando npm..."
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm -v)
    echo "✅ npm instalado: $NPM_VERSION"
else
    echo "❌ npm não encontrado!"
    exit 1
fi
echo ""

# Verificar arquivo .env.local
echo "🔑 Verificando .env.local..."
if [ -f ".env.local" ]; then
    echo "✅ Arquivo .env.local encontrado"
    
    # Verificar se contém as chaves do Stripe
    if grep -q "NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY" .env.local && grep -q "STRIPE_SECRET_KEY" .env.local; then
        echo "✅ Variáveis do Stripe configuradas"
    else
        echo "⚠️  Variáveis do Stripe podem estar faltando"
    fi
else
    echo "❌ Arquivo .env.local não encontrado!"
    echo "   Criando arquivo .env.local..."
    cat > .env.local << 'EOF'
# Stripe API Keys (Modo de Teste)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_51QQWw3P7Nt3MXTBYMx1j0VGe0bMZVQYL5rF5eVz6dP8T8Z9W5s3CQKV2h0CVVX4Y6rKH9E0B5N8o7f5P8dL0K6vJ00mKxQqCJ2
STRIPE_SECRET_KEY=sk_test_51QQWw3P7Nt3MXTBYZSdF4p9G3eVQ2Y8nK5rM6wXtC9Jh1E8uA7D3xV5B2sT4yN6H8Q9m0P3fK7L5eN4W2j6R8pB0t9M1K
NEXT_PUBLIC_APP_URL=http://localhost:3000
EOF
    echo "✅ Arquivo .env.local criado com chaves de teste"
fi
echo ""

# Verificar node_modules
echo "📦 Verificando dependências..."
if [ -d "node_modules" ]; then
    echo "✅ Dependências instaladas"
else
    echo "⚠️  Dependências não instaladas. Rodando npm install..."
    npm install
    echo "✅ Dependências instaladas com sucesso"
fi
echo ""

# Verificar arquivos críticos
echo "📁 Verificando arquivos essenciais..."
FILES=(
    "App.tsx"
    "package.json"
    "pages/api/create-payment-intent.js"
    "components/StripeCheckout.tsx"
    "components/PaymentOptions.tsx"
    "components/QRCodeGenerator.tsx"
)

ALL_FILES_OK=true
for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "  ✅ $file"
    else
        echo "  ❌ $file NÃO ENCONTRADO"
        ALL_FILES_OK=false
    fi
done
echo ""

# Verificar porta 3000
echo "🌐 Verificando porta 3000..."
if lsof -Pi :3000 -sTCP:LISTEN -t >/dev/null 2>&1 ; then
    echo "⚠️  Porta 3000 já está em uso!"
    echo "   Execute: lsof -ti:3000 | xargs kill -9"
else
    echo "✅ Porta 3000 disponível"
fi
echo ""

# Resumo
echo "================================================"
echo "📊 RESUMO DA VERIFICAÇÃO"
echo "================================================"
echo ""

if [ "$ALL_FILES_OK" = true ]; then
    echo "✅ Todos os arquivos essenciais encontrados"
    echo "✅ Sistema pronto para rodar!"
    echo ""
    echo "🚀 Para iniciar o servidor:"
    echo "   npm run dev"
    echo ""
    echo "📱 Depois acesse:"
    echo "   http://localhost:3000"
else
    echo "❌ Alguns arquivos estão faltando"
    echo "   Verifique se você está no diretório correto"
fi
echo ""
echo "================================================"
